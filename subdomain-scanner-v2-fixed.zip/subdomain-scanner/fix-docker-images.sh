#!/bin/bash

# Docker Image Fix Script
# Fixes common Docker image issues

echo "================================"
echo "  Docker Image Fix Tool"
echo "================================"
echo ""

# Check if docker-compose is available
if ! command -v docker-compose &> /dev/null; then
    echo "❌ docker-compose not found. Please install it first."
    exit 1
fi

echo "[*] Checking Docker images..."
echo ""

# List of images that need custom build
CUSTOM_BUILDS=(
    "assetfinder"
    "massdns"
    "altdns"
    "findomain"
)

echo "[*] Building custom Docker images..."
echo ""

# Build Assetfinder
echo "Building Assetfinder..."
docker build -t subdomain-scanner-assetfinder -f dockerfiles/Dockerfile.assetfinder ./dockerfiles/ || echo "⚠️ Assetfinder build failed"

# Build MassDNS
echo "Building MassDNS..."
docker build -t subdomain-scanner-massdns -f dockerfiles/Dockerfile.massdns ./dockerfiles/ || echo "⚠️ MassDNS build failed"

# Build Altdns
echo "Building Altdns..."
docker build -t subdomain-scanner-altdns -f dockerfiles/Dockerfile.altdns ./dockerfiles/ || echo "⚠️ Altdns build failed"

# Build Findomain
echo "Building Findomain..."
docker build -t subdomain-scanner-findomain -f dockerfiles/Dockerfile.findomain ./dockerfiles/ || echo "⚠️ Findomain build failed"

echo ""
echo "[*] Pulling official images..."
echo ""

# Pull official images
docker-compose pull subfinder || echo "⚠️ Subfinder pull failed (will retry)"
docker-compose pull amass || echo "⚠️ Amass pull failed (will retry)"
docker-compose pull dnsx || echo "⚠️ DNSx pull failed (will retry)"
docker-compose pull httpx || echo "⚠️ HTTPx pull failed (will retry)"
docker-compose pull nuclei || echo "⚠️ Nuclei pull failed (will retry)"
docker-compose pull chaos || echo "⚠️ Chaos pull failed (will retry)"
docker-compose pull redis || echo "⚠️ Redis pull failed (will retry)"
docker-compose pull postgres || echo "⚠️ Postgres pull failed (will retry)"
docker-compose pull adminer || echo "⚠️ Adminer pull failed (will retry)"

echo ""
echo "[*] Building API service..."
docker-compose build scanner-api || echo "⚠️ API build failed"

echo ""
echo "================================"
echo "  Image Status"
echo "================================"

# Check which images are available
echo ""
echo "Custom builds:"
docker images | grep "subdomain-scanner" || echo "No custom images found"

echo ""
echo "Official images:"
docker images | grep -E "projectdiscovery|caffix|redis|postgres|adminer" || echo "No official images found"

echo ""
echo "================================"
echo "  Recommendations"
echo "================================"
echo ""
echo "1. If builds failed, check internet connection"
echo "2. Some images are large (1-2GB), be patient"
echo "3. Run: docker-compose build --no-cache (if issues persist)"
echo "4. Run: docker-compose up -d (to start services)"
echo ""

# Test if we can run a simple command
echo "[*] Testing Subfinder..."
if docker-compose run --rm subfinder --version > /dev/null 2>&1; then
    echo "✅ Subfinder is working"
else
    echo "❌ Subfinder test failed"
fi

echo ""
echo "✅ Fix script completed!"
echo ""
echo "Next steps:"
echo "  1. docker-compose up -d"
echo "  2. Check: docker-compose ps"
echo "  3. Run: ./scan.sh example.com"
