#!/usr/bin/env python3

"""
CLI Tool for Subdomain Scanner
Usage: python cli.py scan example.com
"""

import argparse
import requests
import time
import sys
from datetime import datetime

API_URL = "http://localhost:8080/api"

def start_scan(domain, options):
    """Start a new scan"""
    print(f"[*] Starting scan for: {domain}")
    
    payload = {
        "domain": domain,
        "options": options
    }
    
    try:
        response = requests.post(f"{API_URL}/scan", json=payload)
        response.raise_for_status()
        data = response.json()
        
        scan_id = data['scan_id']
        print(f"[+] Scan started: {scan_id}")
        
        return scan_id
        
    except requests.exceptions.RequestException as e:
        print(f"[-] Error starting scan: {e}")
        sys.exit(1)

def monitor_scan(scan_id):
    """Monitor scan progress"""
    print(f"[*] Monitoring scan: {scan_id}")
    
    while True:
        try:
            response = requests.get(f"{API_URL}/scan/{scan_id}")
            response.raise_for_status()
            data = response.json()
            
            status = data['status']
            progress = data.get('progress', 0)
            phase = data.get('phase', 'Unknown')
            
            # Clear line and print status
            sys.stdout.write(f"\r[*] Status: {status} | Progress: {progress}% | Phase: {phase}     ")
            sys.stdout.flush()
            
            if status == 'completed':
                print("\n[+] Scan completed!")
                return data
            elif status == 'failed':
                print("\n[-] Scan failed!")
                return data
            
            time.sleep(2)
            
        except requests.exceptions.RequestException as e:
            print(f"\n[-] Error monitoring scan: {e}")
            sys.exit(1)

def get_results(scan_id):
    """Get scan results"""
    print(f"[*] Fetching results for: {scan_id}")
    
    try:
        response = requests.get(f"{API_URL}/scan/{scan_id}/results")
        response.raise_for_status()
        data = response.json()
        
        print(f"\n{'='*60}")
        print(f"Scan Results: {data['domain']}")
        print(f"{'='*60}")
        print(f"Status: {data['status']}")
        print(f"Total Subdomains: {len(data['subdomains'])}")
        
        live_count = sum(1 for s in data['subdomains'] if s['is_live'])
        print(f"Live Hosts: {live_count}")
        
        print(f"\n{'Subdomain':<50} {'Status':<10}")
        print(f"{'-'*60}")
        
        for subdomain in data['subdomains'][:50]:  # Show first 50
            status = "LIVE" if subdomain['is_live'] else "DEAD"
            print(f"{subdomain['subdomain']:<50} {status:<10}")
        
        if len(data['subdomains']) > 50:
            print(f"\n... and {len(data['subdomains']) - 50} more")
        
    except requests.exceptions.RequestException as e:
        print(f"[-] Error fetching results: {e}")
        sys.exit(1)

def list_scans():
    """List all scans"""
    try:
        response = requests.get(f"{API_URL}/scans")
        response.raise_for_status()
        data = response.json()
        
        print(f"\n{'='*100}")
        print(f"Recent Scans")
        print(f"{'='*100}")
        print(f"{'Domain':<30} {'Status':<15} {'Started':<20} {'Subdomains':<15} {'Live':<10}")
        print(f"{'-'*100}")
        
        for scan in data['scans']:
            started = datetime.fromisoformat(scan['started_at']).strftime('%Y-%m-%d %H:%M')
            print(f"{scan['domain']:<30} {scan['status']:<15} {started:<20} {scan['total_subdomains']:<15} {scan['live_hosts']:<10}")
        
    except requests.exceptions.RequestException as e:
        print(f"[-] Error listing scans: {e}")
        sys.exit(1)

def main():
    parser = argparse.ArgumentParser(description='Subdomain Scanner CLI')
    subparsers = parser.add_subparsers(dest='command', help='Commands')
    
    # Scan command
    scan_parser = subparsers.add_parser('scan', help='Start a new scan')
    scan_parser.add_argument('domain', help='Target domain')
    scan_parser.add_argument('--no-monitor', action='store_true', help='Don\'t monitor progress')
    scan_parser.add_argument('--subfinder', action='store_true', default=True, help='Use Subfinder')
    scan_parser.add_argument('--amass', action='store_true', default=True, help='Use Amass')
    scan_parser.add_argument('--assetfinder', action='store_true', default=True, help='Use Assetfinder')
    scan_parser.add_argument('--findomain', action='store_true', default=True, help='Use Findomain')
    scan_parser.add_argument('--dnsx', action='store_true', default=True, help='Use DNSx')
    scan_parser.add_argument('--httpx', action='store_true', default=True, help='Use HTTPx')
    scan_parser.add_argument('--nuclei', action='store_true', help='Use Nuclei')
    
    # Results command
    results_parser = subparsers.add_parser('results', help='Get scan results')
    results_parser.add_argument('scan_id', help='Scan ID')
    
    # Status command
    status_parser = subparsers.add_parser('status', help='Get scan status')
    status_parser.add_argument('scan_id', help='Scan ID')
    
    # List command
    subparsers.add_parser('list', help='List all scans')
    
    args = parser.parse_args()
    
    if args.command == 'scan':
        options = {
            'subfinder': args.subfinder,
            'amass': args.amass,
            'assetfinder': args.assetfinder,
            'findomain': args.findomain,
            'dnsx': args.dnsx,
            'httpx': args.httpx,
            'nuclei': args.nuclei
        }
        
        scan_id = start_scan(args.domain, options)
        
        if not args.no_monitor:
            data = monitor_scan(scan_id)
            get_results(scan_id)
        else:
            print(f"[*] Scan ID: {scan_id}")
            print("[*] Use 'python cli.py status {scan_id}' to check progress")
    
    elif args.command == 'results':
        get_results(args.scan_id)
    
    elif args.command == 'status':
        data = monitor_scan(args.scan_id)
    
    elif args.command == 'list':
        list_scans()
    
    else:
        parser.print_help()

if __name__ == '__main__':
    main()
