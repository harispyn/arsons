# 🔧 Troubleshooting Guide

## Common Docker Issues

### 1. Image Pull Access Denied

**Error:**
```
Error response from daemon: pull access denied for findomain/findomain, 
repository does not exist or may require 'docker login'
```

**Solution:**

#### Option A: Use Fix Script (Recommended)
```bash
chmod +x fix-docker-images.sh
./fix-docker-images.sh
```

#### Option B: Manual Fix
```bash
# Build Findomain manually
docker build -t subdomain-scanner-findomain -f dockerfiles/Dockerfile.findomain ./dockerfiles/

# Rebuild all services
docker-compose build --no-cache

# Start services
docker-compose up -d
```

#### Option C: Disable Findomain (Quick Fix)
If you don't need Findomain, comment it out in `docker-compose.yml`:
```yaml
# findomain:
#   build:
#     context: ./dockerfiles
#     dockerfile: Dockerfile.findomain
#   ...
```

---

### 2. Network Issues / Slow Pull

**Symptoms:**
- Docker pull timeout
- Connection refused
- Slow image downloads

**Solutions:**

#### Use Docker Mirror (China/Asia)
Edit `/etc/docker/daemon.json`:
```json
{
  "registry-mirrors": [
    "https://docker.mirrors.ustc.edu.cn",
    "https://hub-mirror.c.163.com"
  ]
}
```

Restart Docker:
```bash
sudo systemctl restart docker
```

#### Pull Images One by One
```bash
docker pull projectdiscovery/subfinder:latest
docker pull caffix/amass:latest
docker pull projectdiscovery/dnsx:latest
docker pull projectdiscovery/httpx:latest
docker pull projectdiscovery/nuclei:latest
docker pull projectdiscovery/chaos-client:latest
docker pull redis:7-alpine
docker pull postgres:15-alpine
docker pull adminer:latest
```

#### Use Pre-built Images
Download from alternative registry:
```bash
# Use quay.io instead
docker pull quay.io/projectdiscovery/subfinder:latest
docker tag quay.io/projectdiscovery/subfinder:latest projectdiscovery/subfinder:latest
```

---

### 3. Build Failures

**Error:**
```
ERROR: failed to solve: process "/bin/sh -c cargo install findomain" 
did not complete successfully
```

**Solutions:**

#### Increase Build Resources
Edit `/etc/docker/daemon.json`:
```json
{
  "default-runtime": "runc",
  "max-concurrent-downloads": 3,
  "max-concurrent-uploads": 3
}
```

#### Build with More Memory
```bash
docker build --memory=4g -t subdomain-scanner-findomain -f dockerfiles/Dockerfile.findomain ./dockerfiles/
```

#### Use Pre-compiled Binaries
Update Dockerfile to download binaries instead of compiling:
```dockerfile
FROM debian:bookworm-slim
RUN apt-get update && apt-get install -y wget ca-certificates
RUN wget -O /usr/local/bin/findomain https://github.com/findomain/findomain/releases/download/9.0.0/findomain-linux-i386.zip
RUN chmod +x /usr/local/bin/findomain
ENTRYPOINT ["findomain"]
```

---

### 4. Port Already in Use

**Error:**
```
Error starting userland proxy: listen tcp 0.0.0.0:8080: 
bind: address already in use
```

**Solutions:**

#### Find Process Using Port
```bash
# Linux
sudo lsof -i :8080
sudo netstat -tulpn | grep :8080

# Kill process
sudo kill -9 <PID>
```

#### Change Port in docker-compose.yml
```yaml
scanner-api:
  ports:
    - "8081:8080"  # Change 8080 to 8081
```

---

### 5. Volume Permission Issues

**Error:**
```
Permission denied: './results'
```

**Solutions:**

#### Fix Permissions
```bash
sudo chown -R $USER:$USER .
chmod -R 755 results/ config/ wordlists/
```

#### Use Docker as Root (Not Recommended)
```bash
sudo docker-compose up -d
```

#### Add User to Docker Group
```bash
sudo usermod -aG docker $USER
newgrp docker
```

---

### 6. Service Won't Start

**Error:**
```
ERROR: for scanner-api  Cannot start service scanner-api
```

**Solutions:**

#### Check Logs
```bash
docker-compose logs scanner-api
docker-compose logs postgres
docker-compose logs redis
```

#### Restart Services
```bash
docker-compose down
docker-compose up -d
```

#### Rebuild Containers
```bash
docker-compose down -v
docker-compose build --no-cache
docker-compose up -d
```

#### Check Service Status
```bash
docker-compose ps
docker ps -a
```

---

### 7. Database Connection Failed

**Error:**
```
psycopg2.OperationalError: could not connect to server
```

**Solutions:**

#### Wait for Database
```bash
# Database takes 10-20 seconds to start
sleep 20
docker-compose restart scanner-api
```

#### Check Database
```bash
docker-compose exec postgres pg_isready -U scanner
docker-compose exec postgres psql -U scanner -d subdomain_scanner -c "SELECT 1;"
```

#### Reset Database
```bash
docker-compose down -v
docker-compose up -d postgres
sleep 20
docker-compose up -d
```

---

### 8. Redis Connection Failed

**Error:**
```
redis.exceptions.ConnectionError: Error connecting to Redis
```

**Solutions:**

#### Check Redis
```bash
docker-compose exec redis redis-cli ping
# Should return: PONG
```

#### Restart Redis
```bash
docker-compose restart redis
docker-compose restart scanner-api
```

---

## Quick Diagnostics

### Health Check Script
```bash
#!/bin/bash

echo "=== Docker Status ==="
docker --version
docker-compose --version

echo ""
echo "=== Services Status ==="
docker-compose ps

echo ""
echo "=== Port Listening ==="
sudo netstat -tulpn | grep -E "8080|8081|5432|6379"

echo ""
echo "=== API Health ==="
curl http://localhost:8080/api/health

echo ""
echo "=== Database Check ==="
docker-compose exec -T postgres pg_isready -U scanner

echo ""
echo "=== Redis Check ==="
docker-compose exec -T redis redis-cli ping

echo ""
echo "=== Disk Space ==="
df -h | grep -E "Filesystem|/$"

echo ""
echo "=== Recent Logs ==="
docker-compose logs --tail=20 scanner-api
```

Save as `health-check.sh` and run:
```bash
chmod +x health-check.sh
./health-check.sh
```

---

## Environment-Specific Issues

### Low Memory System

**Symptoms:**
- Build failures
- Container crashes
- Slow performance

**Solutions:**

#### Check Memory
```bash
free -h
docker stats
```

#### Reduce Resource Usage
Edit `docker-compose.yml`:
```yaml
services:
  scanner-api:
    deploy:
      resources:
        limits:
          memory: 512M
        reservations:
          memory: 256M
```

#### Disable Heavy Tools
Comment out Amass (slowest):
```yaml
# amass:
#   image: caffix/amass:latest
#   ...
```

### Slow Internet

**Solutions:**

#### Use Quick Scan Only
```bash
./quick-scan.sh example.com  # Uses only Subfinder
```

#### Download Images Separately
```bash
# Download overnight
docker pull projectdiscovery/subfinder:latest &
docker pull caffix/amass:latest &
wait
```

---

## Alternative Solutions

### 1. Use Minimal Setup

Create `docker-compose.minimal.yml`:
```yaml
version: '3.8'

services:
  subfinder:
    image: projectdiscovery/subfinder:latest
    volumes:
      - ./results:/results
    networks:
      - scanner-network

  dnsx:
    image: projectdiscovery/dnsx:latest
    volumes:
      - ./results:/results
    networks:
      - scanner-network

  httpx:
    image: projectdiscovery/httpx:latest
    volumes:
      - ./results:/results
    networks:
      - scanner-network

networks:
  scanner-network:
    driver: bridge
```

Use it:
```bash
docker-compose -f docker-compose.minimal.yml run --rm subfinder -d example.com
```

### 2. Run Tools Natively

Install tools locally (without Docker):
```bash
# Subfinder
go install github.com/projectdiscovery/subfinder/v2/cmd/subfinder@latest

# DNSx
go install github.com/projectdiscovery/dnsx/cmd/dnsx@latest

# HTTPx
go install github.com/projectdiscovery/httpx/cmd/httpx@latest

# Run
subfinder -d example.com -o subdomains.txt
cat subdomains.txt | dnsx -silent | httpx -silent
```

---

## Getting Help

### Collect Debug Info
```bash
# System info
uname -a
cat /etc/os-release

# Docker info
docker version
docker info

# Logs
docker-compose logs > debug.log

# Services
docker-compose ps > services.txt
```

### Support Channels
- GitHub Issues: Report with debug.log
- Stack Overflow: Tag [docker-compose]
- Docker Forums: https://forums.docker.com/

---

## Prevention Tips

✅ Always pull latest images regularly:
```bash
docker-compose pull
```

✅ Clean up unused resources:
```bash
docker system prune -a
```

✅ Monitor resource usage:
```bash
docker stats
```

✅ Keep Docker updated:
```bash
sudo apt update && sudo apt upgrade docker-ce
```

✅ Use stable versions in production:
```yaml
image: projectdiscovery/subfinder:v2.6.3  # Fixed version
```

---

**Still having issues?**

1. Run: `./fix-docker-images.sh`
2. Check: `docker-compose logs`
3. Report: Create GitHub issue with logs

**Emergency Contact:**
- Quick fix: Use minimal setup
- Alternative: Run tools natively without Docker
