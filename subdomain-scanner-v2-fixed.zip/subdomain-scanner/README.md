# Subdomain Scanner

Comprehensive subdomain discovery and reconnaissance platform using Docker Compose with multiple industry-standard tools.

## 🚀 Features

- **Multiple Discovery Tools**: Subfinder, Amass, Assetfinder, Findomain, Chaos
- **DNS Verification**: DNSx for accurate subdomain validation
- **HTTP Probing**: HTTPx for live host detection
- **Vulnerability Scanning**: Nuclei integration
- **REST API**: Flask-based API for automation
- **Web Dashboard**: Beautiful real-time UI with live monitoring
- **📥 Export Functionality**: Export results in TXT, JSON, CSV formats
- **⚡ Real-time Process Monitor**: Live tool execution tracking with color-coded logs
- **📊 Live Statistics**: Real-time counters and progress tracking
- **Database Storage**: PostgreSQL for persistent results
- **Queue Management**: Redis for background processing

## 📋 Prerequisites

- Docker & Docker Compose
- 4GB+ RAM recommended
- Linux/macOS/Windows with WSL2

## 🛠️ Installation

1. Clone the repository:
```bash
git clone <repository-url>
cd subdomain-scanner
```

2. Create necessary directories:
```bash
mkdir -p config results wordlists nuclei-templates
```

3. Build and start services:
```bash
docker-compose build
docker-compose up -d
```

4. Verify services are running:
```bash
docker-compose ps
```

## 📖 Usage

### Web Dashboard

Access the dashboard at: `http://localhost:8080`

1. Enter target domain
2. Select scanning options
3. Click "Start Scan"
4. Monitor progress in real-time

### Command Line (Shell Script)

Full scan with all tools:
```bash
chmod +x scan.sh
./scan.sh example.com
```

Quick scan (fast):
```bash
chmod +x quick-scan.sh
./quick-scan.sh example.com
```

### REST API

#### Start a scan:
```bash
curl -X POST http://localhost:8080/api/scan \
  -H "Content-Type: application/json" \
  -d '{
    "domain": "example.com",
    "options": {
      "subfinder": true,
      "amass": true,
      "dnsx": true,
      "httpx": true,
      "nuclei": false
    }
  }'
```

#### Check scan status:
```bash
curl http://localhost:8080/api/scan/{scan_id}
```

#### Get scan results:
```bash
curl http://localhost:8080/api/scan/{scan_id}/results
```

#### Export results:
```bash
# Export all subdomains
curl http://localhost:8080/api/scan/{scan_id}/export/all > subdomains.txt

# Export live hosts only
curl http://localhost:8080/api/scan/{scan_id}/export/live > live_hosts.txt

# Export as JSON
curl http://localhost:8080/api/scan/{scan_id}/export/json > results.json

# Export as CSV
curl http://localhost:8080/api/scan/{scan_id}/export/csv > results.csv
```

#### List all scans:
```bash
curl http://localhost:8080/api/scans
```

### Individual Tools

Run tools individually:

```bash
# Subfinder
docker-compose run --rm subfinder -d example.com

# Amass
docker-compose run --rm amass enum -d example.com

# DNSx
echo "sub.example.com" | docker-compose run --rm dnsx

# HTTPx
echo "https://example.com" | docker-compose run --rm httpx

# Nuclei
docker-compose run --rm nuclei -u https://example.com
```

## 🔧 Configuration

### API Keys (Optional but Recommended)

Create configuration files for better results:

**Subfinder** (`config/subfinder/provider-config.yaml`):
```yaml
virustotal:
  - YOUR_VT_API_KEY
shodan:
  - YOUR_SHODAN_API_KEY
securitytrails:
  - YOUR_ST_API_KEY
```

**Amass** (`config/amass/config.ini`):
```ini
[data_sources.VirusTotal]
[data_sources.VirusTotal.Credentials]
apikey = YOUR_VT_API_KEY

[data_sources.Shodan]
[data_sources.Shodan.Credentials]
apikey = YOUR_SHODAN_API_KEY
```

**Chaos** (`config/chaos/config.yaml`):
```yaml
api-key: YOUR_CHAOS_API_KEY
```

### Environment Variables

Edit `docker-compose.yml` or create `.env` file:

```env
POSTGRES_DB=subdomain_scanner
POSTGRES_USER=scanner
POSTGRES_PASSWORD=scanner123
REDIS_HOST=redis
```

## 📊 Database Schema

Access database with Adminer at: `http://localhost:8081`

**Tables:**
- `scans`: Scan metadata and status
- `subdomains`: Discovered subdomains
- `vulnerabilities`: Nuclei findings

## 🎯 Scanning Workflow

1. **Discovery Phase**: Multiple tools discover subdomains
2. **Merge & Deduplicate**: Combine results from all tools
3. **DNS Verification**: Verify with DNSx
4. **HTTP Probing**: Check live hosts with HTTPx
5. **Vulnerability Scanning**: Optional Nuclei scan
6. **Results Storage**: Save to PostgreSQL
7. **Report Generation**: Generate summary

## 📁 Results Structure

```
results/
├── example.com_20240101_120000/
│   ├── subfinder.txt
│   ├── amass.txt
│   ├── assetfinder.txt
│   ├── findomain.txt
│   ├── chaos.txt
│   ├── all_subdomains.txt
│   ├── verified.txt
│   ├── httpx.txt
│   ├── nuclei.txt
│   └── summary.txt
```

## 🔒 Security Notes

- Run in isolated environment
- Use API keys for better results
- Respect rate limits
- Only scan authorized domains
- Follow responsible disclosure

## 🛡️ Tools Included

| Tool | Purpose | Speed |
|------|---------|-------|
| **Subfinder** | Passive subdomain discovery | Fast |
| **Amass** | Comprehensive enumeration | Slow |
| **Assetfinder** | Quick discovery | Fast |
| **Findomain** | Multi-source discovery | Fast |
| **Chaos** | ProjectDiscovery dataset | Fast |
| **DNSx** | DNS verification | Medium |
| **HTTPx** | HTTP probing | Medium |
| **Nuclei** | Vulnerability scanning | Slow |
| **MassDNS** | High-performance DNS | Fast |
| **Altdns** | Subdomain permutation | Medium |

## 🔄 Service Management

```bash
# Start all services
docker-compose up -d

# Stop all services
docker-compose down

# View logs
docker-compose logs -f

# Restart service
docker-compose restart scanner-api

# Rebuild services
docker-compose build --no-cache

# Scale workers (future)
docker-compose up -d --scale worker=3
```

## 📈 Performance Tips

1. **Use API Keys**: Significantly improves results
2. **Parallel Scanning**: Tools run independently
3. **Resource Allocation**: Increase Docker memory limit
4. **Selective Tools**: Disable slow tools for quick scans
5. **Wordlists**: Add custom wordlists to `/wordlists`

## 🐛 Troubleshooting

**Services won't start:**
```bash
docker-compose down -v
docker-compose up -d --force-recreate
```

**Database connection issues:**
```bash
docker-compose restart postgres
docker-compose logs postgres
```

**API not responding:**
```bash
docker-compose logs scanner-api
docker-compose restart scanner-api
```

**Permission errors:**
```bash
sudo chown -R $USER:$USER results/ config/
chmod +x *.sh
```

## 📝 API Endpoints

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/api/scan` | POST | Start new scan |
| `/api/scan/{id}` | GET | Get scan status |
| `/api/scan/{id}/results` | GET | Get scan results |
| `/api/scans` | GET | List all scans |
| `/api/health` | GET | Health check |

## 🎨 Web Dashboard Features

- Real-time progress tracking
- Live subdomain count
- Status monitoring
- Results visualization
- Scan history
- Export capabilities

## 🤝 Contributing

Contributions welcome! Please:
1. Fork the repository
2. Create feature branch
3. Commit changes
4. Push to branch
5. Open pull request

## 📄 License

MIT License - feel free to use for personal and commercial projects

## 🙏 Credits

Thanks to the creators of:
- ProjectDiscovery (Subfinder, DNSx, HTTPx, Nuclei, Chaos)
- OWASP Amass
- Findomain
- Assetfinder

## 📞 Support

For issues and questions:
- GitHub Issues
- Documentation wiki
- Community Discord

## 🔮 Roadmap

- [ ] Certificate Transparency logs
- [ ] Wayback Machine integration
- [ ] GitHub/GitLab scraping
- [ ] S3 bucket discovery
- [ ] Takeover detection
- [ ] Screenshot capture
- [ ] Report generation (PDF/HTML)
- [ ] Slack/Discord notifications
- [ ] CI/CD integration
- [ ] Kubernetes deployment

---

**⚠️ Disclaimer**: Only use on domains you own or have permission to test. Unauthorized scanning may be illegal.
