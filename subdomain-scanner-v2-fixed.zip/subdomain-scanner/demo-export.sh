#!/bin/bash

# Demo script for export functionality
# This demonstrates all export features

API_URL="http://localhost:8080/api"
DOMAIN=${1:-"example.com"}

echo "================================"
echo "  Export Features Demo"
echo "================================"
echo ""

# Check if scan exists
echo "[*] Looking for recent scans of domain: $DOMAIN"
SCANS=$(curl -s ${API_URL}/scans | jq -r ".scans[] | select(.domain == \"${DOMAIN}\") | .scan_id" | head -1)

if [ -z "$SCANS" ]; then
    echo "[-] No scans found for $DOMAIN"
    echo "[*] Please run a scan first:"
    echo "    ./scan.sh $DOMAIN"
    exit 1
fi

SCAN_ID=$SCANS
echo "[+] Found scan: $SCAN_ID"
echo ""

# Create export directory
EXPORT_DIR="./exports/${SCAN_ID}"
mkdir -p "${EXPORT_DIR}"

echo "[*] Exporting results to: ${EXPORT_DIR}"
echo ""

# 1. Export all subdomains
echo "[1/4] Exporting all subdomains..."
curl -s "${API_URL}/scan/${SCAN_ID}/export/all" -o "${EXPORT_DIR}/all_subdomains.txt"
ALL_COUNT=$(wc -l < "${EXPORT_DIR}/all_subdomains.txt")
echo "      ✓ Exported ${ALL_COUNT} subdomains"
echo "      📁 ${EXPORT_DIR}/all_subdomains.txt"
echo ""

# 2. Export live hosts
echo "[2/4] Exporting live hosts only..."
curl -s "${API_URL}/scan/${SCAN_ID}/export/live" -o "${EXPORT_DIR}/live_hosts.txt"
LIVE_COUNT=$(wc -l < "${EXPORT_DIR}/live_hosts.txt")
echo "      ✓ Exported ${LIVE_COUNT} live hosts"
echo "      📁 ${EXPORT_DIR}/live_hosts.txt"
echo ""

# 3. Export JSON
echo "[3/4] Exporting complete results as JSON..."
curl -s "${API_URL}/scan/${SCAN_ID}/export/json" -o "${EXPORT_DIR}/results.json"
echo "      ✓ Exported complete scan data"
echo "      📁 ${EXPORT_DIR}/results.json"
echo ""

# 4. Export CSV
echo "[4/4] Exporting results as CSV..."
curl -s "${API_URL}/scan/${SCAN_ID}/export/csv" -o "${EXPORT_DIR}/results.csv"
CSV_COUNT=$(wc -l < "${EXPORT_DIR}/results.csv")
echo "      ✓ Exported ${CSV_COUNT} entries (including header)"
echo "      📁 ${EXPORT_DIR}/results.csv"
echo ""

# Display statistics
echo "================================"
echo "  Export Summary"
echo "================================"
echo "Domain: $(jq -r '.domain' ${EXPORT_DIR}/results.json)"
echo "Scan ID: $(jq -r '.scan_id' ${EXPORT_DIR}/results.json)"
echo "Status: $(jq -r '.status' ${EXPORT_DIR}/results.json)"
echo ""
echo "Results:"
echo "  - Total Subdomains: $(jq -r '.total_subdomains' ${EXPORT_DIR}/results.json)"
echo "  - Verified: $(jq -r '.verified_subdomains' ${EXPORT_DIR}/results.json)"
echo "  - Live Hosts: $(jq -r '.live_hosts' ${EXPORT_DIR}/results.json)"
echo ""
echo "Files:"
echo "  - all_subdomains.txt (${ALL_COUNT} lines)"
echo "  - live_hosts.txt (${LIVE_COUNT} lines)"
echo "  - results.json (complete data)"
echo "  - results.csv (spreadsheet format)"
echo ""

# Preview samples
echo "================================"
echo "  Sample Data"
echo "================================"
echo ""
echo "Top 5 subdomains:"
head -5 "${EXPORT_DIR}/all_subdomains.txt"
echo ""
echo "Live hosts:"
head -5 "${EXPORT_DIR}/live_hosts.txt"
echo ""

# Integration examples
echo "================================"
echo "  Integration Examples"
echo "================================"
echo ""
echo "1. Feed to other tools:"
echo "   cat ${EXPORT_DIR}/live_hosts.txt | httpx -title -tech-detect"
echo ""
echo "2. Scan for vulnerabilities:"
echo "   nuclei -l ${EXPORT_DIR}/live_hosts.txt -t cves/"
echo ""
echo "3. Screenshot capture:"
echo "   gowitness file -f ${EXPORT_DIR}/live_hosts.txt"
echo ""
echo "4. Port scanning:"
echo "   nmap -iL ${EXPORT_DIR}/live_hosts.txt -p 80,443,8080"
echo ""
echo "5. Compare with previous scan:"
echo "   diff old_scan.txt ${EXPORT_DIR}/all_subdomains.txt"
echo ""

echo "✅ Export demo completed!"
echo "📂 All files saved to: ${EXPORT_DIR}"
