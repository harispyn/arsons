# 🚀 Quick Start for Server (root@srv1221129)

## Error Yang Anda Alami:
```
Error response from daemon: pull access denied for findomain/findomain
```

## Solusi Cepat (3 Menit):

### Opsi 1: Gunakan Quick Fix (Recommended)
```bash
# Di server Anda
cd /root/subdomain-scanner

# Jalankan quick fix
chmod +x quickfix.sh
./quickfix.sh

# Akan otomatis:
# - Fix Findomain error
# - Build semua images
# - Start services
# - Test connection
```

### Opsi 2: Manual Fix
```bash
cd /root/subdomain-scanner

# Build Findomain dengan binary pre-built (cepat!)
docker build -t subdomain-scanner-findomain \
  -f dockerfiles/Dockerfile.findomain.fast \
  ./dockerfiles/

# Build images lainnya
docker-compose build

# Start services
docker-compose up -d

# Check status
docker-compose ps
```

### Opsi 3: Skip Findomain (Paling Cepat)
```bash
cd /root/subdomain-scanner

# Comment out Findomain
sed -i '/^  findomain:/,/^  [a-z-]/ {/^  findomain:/!{/^  [a-z-]/!s/^/#/}}' docker-compose.yml

# Start services
docker-compose up -d
```

---

## Verifikasi Instalasi:

### 1. Check Services
```bash
docker-compose ps

# Harus menampilkan:
# scanner-api     running
# postgres        running  
# redis           running
```

### 2. Test API
```bash
curl http://localhost:8080/api/health

# Output: {"status":"healthy","timestamp":"..."}
```

### 3. Test Scan
```bash
# Quick test
./quick-scan.sh example.com
```

---

## Access Dashboard:

### Dari Server Lokal:
```
http://localhost:8080
```

### Dari Browser Eksternal:
```
http://YOUR_SERVER_IP:8080
```

**Note:** Pastikan firewall mengizinkan port 8080!

```bash
# Buka port (Ubuntu/Debian)
sudo ufw allow 8080

# Atau (CentOS/RHEL)
sudo firewall-cmd --permanent --add-port=8080/tcp
sudo firewall-cmd --reload
```

---

## Jika Masih Error:

### Check Logs:
```bash
docker-compose logs scanner-api
docker-compose logs postgres
docker-compose logs redis
```

### Restart Services:
```bash
docker-compose down
docker-compose up -d
```

### Complete Rebuild:
```bash
docker-compose down -v
docker-compose build --no-cache
docker-compose up -d
```

---

## System Requirements:

✅ Minimum:
- RAM: 2GB
- Disk: 10GB free
- CPU: 2 cores

✅ Recommended:
- RAM: 4GB+
- Disk: 20GB+ free
- CPU: 4+ cores

### Check Your System:
```bash
# Memory
free -h

# Disk
df -h

# CPU
nproc
```

---

## Common Issues:

### "Port 8080 already in use"
```bash
# Find process
sudo lsof -i :8080

# Kill it
sudo kill -9 <PID>

# Or change port in docker-compose.yml
sed -i 's/8080:8080/8081:8080/' docker-compose.yml
```

### "Cannot connect to Docker daemon"
```bash
sudo systemctl start docker
sudo systemctl enable docker
```

### "Permission denied"
```bash
sudo chown -R $USER:$USER .
sudo chmod -R 755 .
```

---

## Performance Tips:

### 1. Use Quick Scan for Testing
```bash
./quick-scan.sh example.com  # Fast (~5 min)
```

### 2. Full Scan for Complete Results
```bash
./scan.sh example.com  # Comprehensive (~30 min)
```

### 3. Disable Heavy Tools
Edit scan scripts, comment out:
```bash
# amass (slowest, skip if not needed)
```

---

## Next Steps:

1. ✅ Fix Findomain error (quickfix.sh)
2. ✅ Start services (docker-compose up -d)
3. ✅ Access dashboard (http://YOUR_IP:8080)
4. ✅ Run test scan (./quick-scan.sh example.com)
5. ✅ Export results (use dashboard buttons)

---

## Support:

**Check Documentation:**
- `README.md` - Main guide
- `TROUBLESHOOTING.md` - Detailed solutions
- `USAGE.md` - Usage examples

**Still Stuck?**
1. Run: `./fix-docker-images.sh`
2. Check: `docker-compose logs`
3. Report: Create GitHub issue

---

## Success Checklist:

- [ ] Findomain error fixed
- [ ] All services running (docker-compose ps)
- [ ] API responding (curl test)
- [ ] Dashboard accessible (browser)
- [ ] Test scan completed
- [ ] Export working

**All checked?** 🎉 You're ready to scan!

---

**Quick Reference Card:**

```bash
# Start
docker-compose up -d

# Stop  
docker-compose down

# Status
docker-compose ps

# Logs
docker-compose logs -f

# Scan
./scan.sh example.com

# Dashboard
http://YOUR_IP:8080
```

Save this! 📌
