-- Create scans table
CREATE TABLE IF NOT EXISTS scans (
    id VARCHAR(255) PRIMARY KEY,
    domain VARCHAR(255) NOT NULL,
    status VARCHAR(50) NOT NULL,
    started_at TIMESTAMP,
    completed_at TIMESTAMP,
    total_subdomains INTEGER DEFAULT 0,
    verified_subdomains INTEGER DEFAULT 0,
    live_hosts INTEGER DEFAULT 0,
    options JSONB,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create subdomains table
CREATE TABLE IF NOT EXISTS subdomains (
    id SERIAL PRIMARY KEY,
    scan_id VARCHAR(255) REFERENCES scans(id) ON DELETE CASCADE,
    subdomain VARCHAR(255) NOT NULL,
    is_live BOOLEAN DEFAULT FALSE,
    ip_address VARCHAR(50),
    http_status INTEGER,
    title TEXT,
    technologies TEXT[],
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(scan_id, subdomain)
);

-- Create vulnerabilities table
CREATE TABLE IF NOT EXISTS vulnerabilities (
    id SERIAL PRIMARY KEY,
    scan_id VARCHAR(255) REFERENCES scans(id) ON DELETE CASCADE,
    subdomain VARCHAR(255),
    vulnerability_name VARCHAR(255),
    severity VARCHAR(50),
    description TEXT,
    matched_at VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create indexes
CREATE INDEX idx_scans_domain ON scans(domain);
CREATE INDEX idx_scans_status ON scans(status);
CREATE INDEX idx_scans_started_at ON scans(started_at DESC);
CREATE INDEX idx_subdomains_scan_id ON subdomains(scan_id);
CREATE INDEX idx_subdomains_is_live ON subdomains(is_live);
CREATE INDEX idx_vulnerabilities_scan_id ON vulnerabilities(scan_id);
CREATE INDEX idx_vulnerabilities_severity ON vulnerabilities(severity);
