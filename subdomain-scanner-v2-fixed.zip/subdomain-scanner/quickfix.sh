#!/bin/bash

# Quick Fix for Findomain Error
# Run this on your server: root@srv1221129:~/subdomain-scanner#

echo "================================"
echo "  Quick Fix - Findomain Error"
echo "================================"
echo ""

# Step 1: Build Findomain manually
echo "[1/4] Building Findomain (may take 5-10 minutes)..."
docker build -t subdomain-scanner-findomain -f dockerfiles/Dockerfile.findomain ./dockerfiles/

if [ $? -ne 0 ]; then
    echo ""
    echo "❌ Findomain build failed!"
    echo ""
    echo "Options:"
    echo "  A) Use Findomain alternative (quick)"
    echo "  B) Download pre-built binary (medium)"
    echo "  C) Skip Findomain (continue without it)"
    echo ""
    read -p "Choose option [A/B/C]: " -n 1 -r
    echo ""
    
    case $REPLY in
        [Aa]* )
            echo "Creating alternative Findomain with downloaded binary..."
            cat > dockerfiles/Dockerfile.findomain.quick << 'EOF'
FROM debian:bookworm-slim

RUN apt-get update && \
    apt-get install -y wget unzip ca-certificates && \
    wget https://github.com/Findomain/Findomain/releases/download/9.0.4/findomain-linux-i386.zip && \
    unzip findomain-linux-i386.zip && \
    mv findomain /usr/local/bin/ && \
    chmod +x /usr/local/bin/findomain && \
    rm -rf findomain-linux-i386.zip && \
    apt-get remove -y wget unzip && \
    apt-get autoremove -y && \
    rm -rf /var/lib/apt/lists/*

WORKDIR /data
ENTRYPOINT ["findomain"]
CMD ["--help"]
EOF
            docker build -t subdomain-scanner-findomain -f dockerfiles/Dockerfile.findomain.quick ./dockerfiles/
            ;;
        [Bb]* )
            echo "Option B not implemented yet. Using option A..."
            ;;
        [Cc]* )
            echo "Commenting out Findomain in docker-compose.yml..."
            sed -i '/^  findomain:/,/^  [a-z]/ s/^/#/' docker-compose.yml
            echo "✅ Findomain disabled"
            ;;
        * )
            echo "Invalid option"
            exit 1
            ;;
    esac
fi

echo ""
echo "[2/4] Building other custom images..."
docker build -t subdomain-scanner-assetfinder -f dockerfiles/Dockerfile.assetfinder ./dockerfiles/
docker build -t subdomain-scanner-massdns -f dockerfiles/Dockerfile.massdns ./dockerfiles/
docker build -t subdomain-scanner-altdns -f dockerfiles/Dockerfile.altdns ./dockerfiles/

echo ""
echo "[3/4] Pulling official images..."
docker-compose pull subfinder amass dnsx httpx nuclei chaos redis postgres adminer 2>&1 | grep -v "Pulling fs layer"

echo ""
echo "[4/4] Building API service..."
docker-compose build scanner-api

echo ""
echo "================================"
echo "  Fix Summary"
echo "================================"

# Check what's ready
echo ""
echo "Image Status:"
docker images | grep -E "subdomain-scanner|projectdiscovery|caffix" | awk '{print $1":"$2 " - " $7}'

echo ""
echo "================================"
echo "  Next Steps"
echo "================================"
echo ""
echo "1. Start services:"
echo "   docker-compose up -d"
echo ""
echo "2. Check status:"
echo "   docker-compose ps"
echo ""
echo "3. Test scan:"
echo "   ./quick-scan.sh example.com"
echo ""
echo "4. If still errors:"
echo "   docker-compose logs scanner-api"
echo ""

# Offer to start services
read -p "Start services now? [Y/n]: " -n 1 -r
echo ""
if [[ ! $REPLY =~ ^[Nn]$ ]]; then
    echo "Starting services..."
    docker-compose up -d
    
    echo ""
    echo "Waiting for services to start..."
    sleep 10
    
    echo ""
    docker-compose ps
    
    echo ""
    echo "✅ Services started!"
    echo ""
    echo "Access dashboard: http://YOUR_SERVER_IP:8080"
    echo ""
fi

echo "Done! 🎉"
