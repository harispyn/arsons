from flask import Flask, request, jsonify, send_file
from flask_cors import CORS
import docker
import redis
import psycopg2
import json
import os
from datetime import datetime
import threading
import subprocess

app = Flask(__name__)
CORS(app)

# Configuration
REDIS_HOST = os.getenv('REDIS_HOST', 'redis')
POSTGRES_HOST = os.getenv('POSTGRES_HOST', 'postgres')
POSTGRES_DB = os.getenv('POSTGRES_DB', 'subdomain_scanner')
POSTGRES_USER = os.getenv('POSTGRES_USER', 'scanner')
POSTGRES_PASSWORD = os.getenv('POSTGRES_PASSWORD', 'scanner123')

# Initialize connections
docker_client = docker.from_env()
redis_client = redis.Redis(host=REDIS_HOST, port=6379, decode_responses=True)

def get_db_connection():
    return psycopg2.connect(
        host=POSTGRES_HOST,
        database=POSTGRES_DB,
        user=POSTGRES_USER,
        password=POSTGRES_PASSWORD
    )

class SubdomainScanner:
    def __init__(self, domain, scan_id):
        self.domain = domain
        self.scan_id = scan_id
        self.results_dir = f"/app/results/{scan_id}"
        os.makedirs(self.results_dir, exist_ok=True)
        
    def run_subfinder(self):
        """Run Subfinder"""
        print(f"[+] Running Subfinder on {self.domain}")
        try:
            container = docker_client.containers.run(
                "projectdiscovery/subfinder:latest",
                command=f"-d {self.domain} -o /results/subfinder.txt -silent",
                volumes={self.results_dir: {'bind': '/results', 'mode': 'rw'}},
                network="subdomain-scanner_scanner-network",
                remove=True,
                detach=False
            )
            return self._read_results("subfinder.txt")
        except Exception as e:
            print(f"[-] Subfinder error: {e}")
            return []
    
    def run_amass(self):
        """Run Amass"""
        print(f"[+] Running Amass on {self.domain}")
        try:
            container = docker_client.containers.run(
                "caffix/amass:latest",
                command=f"enum -passive -d {self.domain} -o /results/amass.txt",
                volumes={self.results_dir: {'bind': '/results', 'mode': 'rw'}},
                network="subdomain-scanner_scanner-network",
                remove=True,
                detach=False
            )
            return self._read_results("amass.txt")
        except Exception as e:
            print(f"[-] Amass error: {e}")
            return []
    
    def run_assetfinder(self):
        """Run Assetfinder"""
        print(f"[+] Running Assetfinder on {self.domain}")
        try:
            container = docker_client.containers.run(
                "subdomain-scanner-assetfinder",
                command=f"--subs-only {self.domain}",
                volumes={self.results_dir: {'bind': '/results', 'mode': 'rw'}},
                network="subdomain-scanner_scanner-network",
                remove=True,
                detach=False
            )
            # Save output
            with open(f"{self.results_dir}/assetfinder.txt", "w") as f:
                f.write(container.decode())
            return self._read_results("assetfinder.txt")
        except Exception as e:
            print(f"[-] Assetfinder error: {e}")
            return []
    
    def run_findomain(self):
        """Run Findomain"""
        print(f"[+] Running Findomain on {self.domain}")
        try:
            container = docker_client.containers.run(
                "findomain/findomain:latest",
                command=f"-t {self.domain} -u /results/findomain.txt",
                volumes={self.results_dir: {'bind': '/results', 'mode': 'rw'}},
                network="subdomain-scanner_scanner-network",
                remove=True,
                detach=False
            )
            return self._read_results("findomain.txt")
        except Exception as e:
            print(f"[-] Findomain error: {e}")
            return []
    
    def run_chaos(self):
        """Run Chaos"""
        print(f"[+] Running Chaos on {self.domain}")
        try:
            container = docker_client.containers.run(
                "projectdiscovery/chaos-client:latest",
                command=f"-d {self.domain} -o /results/chaos.txt -silent",
                volumes={self.results_dir: {'bind': '/results', 'mode': 'rw'}},
                network="subdomain-scanner_scanner-network",
                remove=True,
                detach=False
            )
            return self._read_results("chaos.txt")
        except Exception as e:
            print(f"[-] Chaos error: {e}")
            return []
    
    def verify_with_dnsx(self, subdomains):
        """Verify subdomains with DNSx"""
        print(f"[+] Verifying {len(subdomains)} subdomains with DNSx")
        
        # Write subdomains to file
        input_file = f"{self.results_dir}/all_subdomains.txt"
        with open(input_file, "w") as f:
            f.write("\n".join(subdomains))
        
        try:
            container = docker_client.containers.run(
                "projectdiscovery/dnsx:latest",
                command=f"-l /results/all_subdomains.txt -o /results/verified.txt -silent -a -cname",
                volumes={self.results_dir: {'bind': '/results', 'mode': 'rw'}},
                network="subdomain-scanner_scanner-network",
                remove=True,
                detach=False
            )
            return self._read_results("verified.txt")
        except Exception as e:
            print(f"[-] DNSx error: {e}")
            return []
    
    def probe_with_httpx(self, subdomains):
        """Probe with HTTPx"""
        print(f"[+] Probing {len(subdomains)} subdomains with HTTPx")
        
        input_file = f"{self.results_dir}/verified.txt"
        
        try:
            container = docker_client.containers.run(
                "projectdiscovery/httpx:latest",
                command=f"-l /results/verified.txt -o /results/httpx.txt -title -status-code -tech-detect -silent",
                volumes={self.results_dir: {'bind': '/results', 'mode': 'rw'}},
                network="subdomain-scanner_scanner-network",
                remove=True,
                detach=False
            )
            return self._read_results("httpx.txt")
        except Exception as e:
            print(f"[-] HTTPx error: {e}")
            return []
    
    def run_nuclei(self):
        """Run Nuclei vulnerability scan"""
        print(f"[+] Running Nuclei vulnerability scan")
        
        try:
            container = docker_client.containers.run(
                "projectdiscovery/nuclei:latest",
                command=f"-l /results/httpx.txt -o /results/nuclei.txt -silent",
                volumes={self.results_dir: {'bind': '/results', 'mode': 'rw'}},
                network="subdomain-scanner_scanner-network",
                remove=True,
                detach=False
            )
            return self._read_results("nuclei.txt")
        except Exception as e:
            print(f"[-] Nuclei error: {e}")
            return []
    
    def _read_results(self, filename):
        """Read results from file"""
        filepath = f"{self.results_dir}/{filename}"
        if os.path.exists(filepath):
            with open(filepath, "r") as f:
                return [line.strip() for line in f if line.strip()]
        return []
    
    def merge_results(self, *result_lists):
        """Merge and deduplicate results"""
        all_results = set()
        for results in result_lists:
            all_results.update(results)
        return sorted(list(all_results))

def run_scan(domain, scan_id, options):
    """Run complete scan"""
    try:
        # Update status
        redis_client.hset(f"scan:{scan_id}", "status", "running")
        redis_client.hset(f"scan:{scan_id}", "progress", "0")
        
        scanner = SubdomainScanner(domain, scan_id)
        
        # Phase 1: Discovery
        redis_client.hset(f"scan:{scan_id}", "progress", "10")
        redis_client.hset(f"scan:{scan_id}", "phase", "Discovery")
        
        all_subdomains = []
        
        if options.get('subfinder', True):
            subfinder_results = scanner.run_subfinder()
            all_subdomains.extend(subfinder_results)
            redis_client.hset(f"scan:{scan_id}", "progress", "20")
        
        if options.get('amass', True):
            amass_results = scanner.run_amass()
            all_subdomains.extend(amass_results)
            redis_client.hset(f"scan:{scan_id}", "progress", "30")
        
        if options.get('assetfinder', True):
            assetfinder_results = scanner.run_assetfinder()
            all_subdomains.extend(assetfinder_results)
            redis_client.hset(f"scan:{scan_id}", "progress", "40")
        
        if options.get('findomain', True):
            findomain_results = scanner.run_findomain()
            all_subdomains.extend(findomain_results)
            redis_client.hset(f"scan:{scan_id}", "progress", "50")
        
        if options.get('chaos', True):
            chaos_results = scanner.run_chaos()
            all_subdomains.extend(chaos_results)
            redis_client.hset(f"scan:{scan_id}", "progress", "55")
        
        # Merge and deduplicate
        unique_subdomains = scanner.merge_results(all_subdomains)
        
        # Phase 2: Verification
        redis_client.hset(f"scan:{scan_id}", "progress", "60")
        redis_client.hset(f"scan:{scan_id}", "phase", "Verification")
        
        if options.get('dnsx', True):
            verified = scanner.verify_with_dnsx(unique_subdomains)
            redis_client.hset(f"scan:{scan_id}", "progress", "70")
        else:
            verified = unique_subdomains
        
        # Phase 3: Probing
        redis_client.hset(f"scan:{scan_id}", "progress", "75")
        redis_client.hset(f"scan:{scan_id}", "phase", "Probing")
        
        if options.get('httpx', True):
            live_hosts = scanner.probe_with_httpx(verified)
            redis_client.hset(f"scan:{scan_id}", "progress", "85")
        
        # Phase 4: Vulnerability Scanning
        if options.get('nuclei', False):
            redis_client.hset(f"scan:{scan_id}", "progress", "90")
            redis_client.hset(f"scan:{scan_id}", "phase", "Vulnerability Scanning")
            vulnerabilities = scanner.run_nuclei()
        
        # Save to database
        conn = get_db_connection()
        cur = conn.cursor()
        
        cur.execute("""
            UPDATE scans 
            SET status = 'completed', 
                completed_at = %s,
                total_subdomains = %s,
                verified_subdomains = %s,
                live_hosts = %s
            WHERE id = %s
        """, (datetime.now(), len(unique_subdomains), len(verified), 
              len(live_hosts) if options.get('httpx') else 0, scan_id))
        
        # Save subdomains
        for subdomain in verified:
            cur.execute("""
                INSERT INTO subdomains (scan_id, subdomain, is_live)
                VALUES (%s, %s, %s)
                ON CONFLICT (scan_id, subdomain) DO NOTHING
            """, (scan_id, subdomain, subdomain in live_hosts if options.get('httpx') else False))
        
        conn.commit()
        cur.close()
        conn.close()
        
        # Update final status
        redis_client.hset(f"scan:{scan_id}", "status", "completed")
        redis_client.hset(f"scan:{scan_id}", "progress", "100")
        
        print(f"[+] Scan completed: {len(unique_subdomains)} total, {len(verified)} verified")
        
    except Exception as e:
        print(f"[-] Scan error: {e}")
        redis_client.hset(f"scan:{scan_id}", "status", "failed")
        redis_client.hset(f"scan:{scan_id}", "error", str(e))

@app.route('/api/scan', methods=['POST'])
def start_scan():
    """Start a new scan"""
    data = request.json
    domain = data.get('domain')
    
    if not domain:
        return jsonify({'error': 'Domain is required'}), 400
    
    # Generate scan ID
    scan_id = f"{domain}_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
    
    # Save to database
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute("""
        INSERT INTO scans (id, domain, status, started_at, options)
        VALUES (%s, %s, 'pending', %s, %s)
    """, (scan_id, domain, datetime.now(), json.dumps(data.get('options', {}))))
    conn.commit()
    cur.close()
    conn.close()
    
    # Start scan in background
    thread = threading.Thread(target=run_scan, args=(domain, scan_id, data.get('options', {})))
    thread.start()
    
    return jsonify({'scan_id': scan_id, 'status': 'started'}), 202

@app.route('/api/scan/<scan_id>', methods=['GET'])
def get_scan_status(scan_id):
    """Get scan status"""
    # Get from Redis
    status = redis_client.hgetall(f"scan:{scan_id}")
    
    # Get from database
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute("SELECT * FROM scans WHERE id = %s", (scan_id,))
    scan = cur.fetchone()
    cur.close()
    conn.close()
    
    if not scan:
        return jsonify({'error': 'Scan not found'}), 404
    
    return jsonify({
        'scan_id': scan_id,
        'domain': scan[1],
        'status': status.get('status', scan[2]),
        'progress': status.get('progress', '0'),
        'phase': status.get('phase', ''),
        'started_at': scan[3].isoformat() if scan[3] else None,
        'completed_at': scan[4].isoformat() if scan[4] else None,
        'total_subdomains': scan[5],
        'verified_subdomains': scan[6],
        'live_hosts': scan[7]
    })

@app.route('/api/scan/<scan_id>/results', methods=['GET'])
def get_scan_results(scan_id):
    """Get scan results"""
    conn = get_db_connection()
    cur = conn.cursor()
    
    cur.execute("SELECT * FROM scans WHERE id = %s", (scan_id,))
    scan = cur.fetchone()
    
    if not scan:
        return jsonify({'error': 'Scan not found'}), 404
    
    cur.execute("SELECT subdomain, is_live FROM subdomains WHERE scan_id = %s", (scan_id,))
    subdomains = cur.fetchall()
    
    cur.close()
    conn.close()
    
    return jsonify({
        'scan_id': scan_id,
        'domain': scan[1],
        'status': scan[2],
        'subdomains': [{'subdomain': s[0], 'is_live': s[1]} for s in subdomains]
    })

@app.route('/api/scans', methods=['GET'])
def list_scans():
    """List all scans"""
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute("SELECT * FROM scans ORDER BY started_at DESC LIMIT 50")
    scans = cur.fetchall()
    cur.close()
    conn.close()
    
    return jsonify({
        'scans': [{
            'scan_id': s[0],
            'domain': s[1],
            'status': s[2],
            'started_at': s[3].isoformat() if s[3] else None,
            'completed_at': s[4].isoformat() if s[4] else None,
            'total_subdomains': s[5],
            'verified_subdomains': s[6],
            'live_hosts': s[7]
        } for s in scans]
    })

@app.route('/api/scan/<scan_id>/export/<format_type>', methods=['GET'])
def export_results(scan_id, format_type):
    """Export scan results in various formats"""
    conn = get_db_connection()
    cur = conn.cursor()
    
    cur.execute("SELECT * FROM scans WHERE id = %s", (scan_id,))
    scan = cur.fetchone()
    
    if not scan:
        return jsonify({'error': 'Scan not found'}), 404
    
    cur.execute("SELECT subdomain, is_live FROM subdomains WHERE scan_id = %s ORDER BY subdomain", (scan_id,))
    subdomains = cur.fetchall()
    
    cur.close()
    conn.close()
    
    domain = scan[1]
    
    if format_type == 'all':
        # Export all subdomains as plain text
        content = '\n'.join([s[0] for s in subdomains])
        return content, 200, {
            'Content-Type': 'text/plain',
            'Content-Disposition': f'attachment; filename="{domain}_all_subdomains.txt"'
        }
    
    elif format_type == 'live':
        # Export only live hosts
        live_hosts = [s[0] for s in subdomains if s[1]]
        content = '\n'.join(live_hosts)
        return content, 200, {
            'Content-Type': 'text/plain',
            'Content-Disposition': f'attachment; filename="{domain}_live_hosts.txt"'
        }
    
    elif format_type == 'json':
        # Export as JSON
        result = {
            'scan_id': scan_id,
            'domain': domain,
            'status': scan[2],
            'started_at': scan[3].isoformat() if scan[3] else None,
            'completed_at': scan[4].isoformat() if scan[4] else None,
            'total_subdomains': scan[5],
            'verified_subdomains': scan[6],
            'live_hosts': scan[7],
            'subdomains': [{'subdomain': s[0], 'is_live': s[1]} for s in subdomains]
        }
        return jsonify(result), 200, {
            'Content-Disposition': f'attachment; filename="{domain}_results.json"'
        }
    
    elif format_type == 'csv':
        # Export as CSV
        import io
        import csv
        
        output = io.StringIO()
        writer = csv.writer(output)
        writer.writerow(['Subdomain', 'Status'])
        
        for subdomain in subdomains:
            writer.writerow([subdomain[0], 'Live' if subdomain[1] else 'Dead'])
        
        content = output.getvalue()
        output.close()
        
        return content, 200, {
            'Content-Type': 'text/csv',
            'Content-Disposition': f'attachment; filename="{domain}_results.csv"'
        }
    
    else:
        return jsonify({'error': 'Invalid export format'}), 400

@app.route('/api/scan/<scan_id>/logs', methods=['GET'])
def get_scan_logs(scan_id):
    """Get real-time scan logs"""
    # Get logs from Redis or generate based on status
    status_key = f"scan:{scan_id}"
    status = redis_client.hgetall(status_key)
    
    logs = []
    
    if status:
        progress = int(status.get('progress', 0))
        phase = status.get('phase', '')
        
        # Generate logs based on progress
        if progress >= 10:
            logs.append({'type': 'success', 'message': 'Subfinder completed', 'timestamp': datetime.now().isoformat()})
        if progress >= 30:
            logs.append({'type': 'success', 'message': 'Amass completed', 'timestamp': datetime.now().isoformat()})
        if progress >= 40:
            logs.append({'type': 'success', 'message': 'Assetfinder completed', 'timestamp': datetime.now().isoformat()})
        if progress >= 50:
            logs.append({'type': 'success', 'message': 'Findomain completed', 'timestamp': datetime.now().isoformat()})
        if progress >= 60:
            logs.append({'type': 'info', 'message': 'DNS verification in progress', 'timestamp': datetime.now().isoformat()})
        if progress >= 75:
            logs.append({'type': 'info', 'message': 'HTTP probing in progress', 'timestamp': datetime.now().isoformat()})
        if progress >= 90:
            logs.append({'type': 'warning', 'message': 'Vulnerability scanning (optional)', 'timestamp': datetime.now().isoformat()})
    
    return jsonify({'logs': logs})

@app.route('/api/health', methods=['GET'])
def health_check():
    """Health check endpoint"""
    return jsonify({'status': 'healthy', 'timestamp': datetime.now().isoformat()})

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8080, debug=True)
