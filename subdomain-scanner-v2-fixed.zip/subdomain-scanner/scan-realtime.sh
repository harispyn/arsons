#!/bin/bash

# Enhanced scan script with real-time logging to Redis
# Usage: ./scan-realtime.sh <domain>

set -e

DOMAIN=$1
SCAN_ID="${DOMAIN}_$(date +%Y%m%d_%H%M%S)"
RESULTS_DIR="./results/${SCAN_ID}"

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Redis logging function
log_to_redis() {
    local message=$1
    local type=$2
    local timestamp=$(date '+%Y-%m-%d %H:%M:%S')
    
    # Try to log to Redis if available
    docker-compose exec -T redis redis-cli RPUSH "scan:${SCAN_ID}:logs" "{\"type\":\"${type}\",\"message\":\"${message}\",\"timestamp\":\"${timestamp}\"}" > /dev/null 2>&1 || true
}

# Create results directory
mkdir -p "${RESULTS_DIR}"

echo -e "${BLUE}================================${NC}"
echo -e "${BLUE}  Subdomain Scanner v1.0${NC}"
echo -e "${BLUE}================================${NC}"
echo -e "${GREEN}Target Domain: ${DOMAIN}${NC}"
echo -e "${GREEN}Scan ID: ${SCAN_ID}${NC}"
echo -e "${BLUE}================================${NC}\n"

log_to_redis "Scan started for domain: ${DOMAIN}" "info"

# Function to print status
print_status() {
    echo -e "${YELLOW}[*] $1${NC}"
    log_to_redis "$1" "info"
}

print_success() {
    echo -e "${GREEN}[+] $1${NC}"
    log_to_redis "$1" "success"
}

print_error() {
    echo -e "${RED}[-] $1${NC}"
    log_to_redis "$1" "error"
}

print_warning() {
    echo -e "${YELLOW}[!] $1${NC}"
    log_to_redis "$1" "warning"
}

# Update Redis progress
update_progress() {
    local progress=$1
    local phase=$2
    docker-compose exec -T redis redis-cli HSET "scan:${SCAN_ID}" "progress" "${progress}" > /dev/null 2>&1 || true
    docker-compose exec -T redis redis-cli HSET "scan:${SCAN_ID}" "phase" "${phase}" > /dev/null 2>&1 || true
}

# Phase 1: Subdomain Discovery
print_status "Phase 1: Subdomain Discovery"
update_progress 5 "Discovery Phase"

# Subfinder
print_status "Running Subfinder..."
update_progress 10 "Subfinder Discovery"
docker-compose run --rm subfinder \
    -d "${DOMAIN}" \
    -o "/results/subfinder.txt" \
    -silent \
    -all > /dev/null 2>&1 || print_warning "Subfinder failed"
SUBFINDER_COUNT=$(wc -l < "${RESULTS_DIR}/subfinder.txt" 2>/dev/null || echo 0)
print_success "Subfinder completed: ${SUBFINDER_COUNT} subdomains"
update_progress 20 "Subfinder Complete"

# Amass
print_status "Running Amass (passive)..."
update_progress 25 "Amass Enumeration"
docker-compose run --rm amass \
    enum -passive \
    -d "${DOMAIN}" \
    -o "/results/amass.txt" > /dev/null 2>&1 || print_warning "Amass failed"
AMASS_COUNT=$(wc -l < "${RESULTS_DIR}/amass.txt" 2>/dev/null || echo 0)
print_success "Amass completed: ${AMASS_COUNT} subdomains"
update_progress 30 "Amass Complete"

# Assetfinder
print_status "Running Assetfinder..."
update_progress 35 "Assetfinder Scan"
docker-compose run --rm assetfinder \
    --subs-only "${DOMAIN}" > "${RESULTS_DIR}/assetfinder.txt" 2>/dev/null || print_warning "Assetfinder failed"
ASSETFINDER_COUNT=$(wc -l < "${RESULTS_DIR}/assetfinder.txt" 2>/dev/null || echo 0)
print_success "Assetfinder completed: ${ASSETFINDER_COUNT} subdomains"
update_progress 40 "Assetfinder Complete"

# Findomain
print_status "Running Findomain..."
update_progress 45 "Findomain Discovery"
docker-compose run --rm findomain \
    -t "${DOMAIN}" \
    -u "/results/findomain.txt" > /dev/null 2>&1 || print_warning "Findomain failed"
FINDOMAIN_COUNT=$(wc -l < "${RESULTS_DIR}/findomain.txt" 2>/dev/null || echo 0)
print_success "Findomain completed: ${FINDOMAIN_COUNT} subdomains"
update_progress 50 "Findomain Complete"

# Chaos
print_status "Running Chaos..."
update_progress 53 "Chaos Dataset"
docker-compose run --rm chaos \
    -d "${DOMAIN}" \
    -o "/results/chaos.txt" \
    -silent > /dev/null 2>&1 || print_warning "Chaos failed (API key required)"
CHAOS_COUNT=$(wc -l < "${RESULTS_DIR}/chaos.txt" 2>/dev/null || echo 0)
if [ ${CHAOS_COUNT} -gt 0 ]; then
    print_success "Chaos completed: ${CHAOS_COUNT} subdomains"
else
    print_warning "Chaos requires API key for results"
fi

# Merge results
print_status "Merging results..."
update_progress 55 "Merging Results"
cat "${RESULTS_DIR}"/*.txt 2>/dev/null | sort -u > "${RESULTS_DIR}/all_subdomains.txt"
TOTAL_SUBDOMAINS=$(wc -l < "${RESULTS_DIR}/all_subdomains.txt")
print_success "Found ${TOTAL_SUBDOMAINS} unique subdomains"
update_progress 60 "Merge Complete"

# Phase 2: DNS Verification
print_status "\nPhase 2: DNS Verification"
update_progress 65 "DNS Verification"
docker-compose run --rm dnsx \
    -l "/results/all_subdomains.txt" \
    -o "/results/verified.txt" \
    -json \
    -a -cname -resp \
    -silent > /dev/null 2>&1 || print_warning "DNSx failed"

VERIFIED=$(wc -l < "${RESULTS_DIR}/verified.txt" 2>/dev/null || echo 0)
print_success "Verified ${VERIFIED} subdomains"
update_progress 70 "Verification Complete"

# Phase 3: HTTP Probing
print_status "\nPhase 3: HTTP Probing"
update_progress 75 "HTTP Probing"
docker-compose run --rm httpx \
    -l "/results/verified.txt" \
    -o "/results/httpx.txt" \
    -json \
    -title -status-code -tech-detect \
    -follow-redirects \
    -silent > /dev/null 2>&1 || print_warning "HTTPx failed"

LIVE_HOSTS=$(wc -l < "${RESULTS_DIR}/httpx.txt" 2>/dev/null || echo 0)
print_success "Found ${LIVE_HOSTS} live hosts"
update_progress 85 "Probing Complete"

# Phase 4: Vulnerability Scanning (optional)
read -p "$(echo -e ${YELLOW}Do you want to run vulnerability scanning with Nuclei? [y/N]: ${NC})" -n 1 -r
echo
if [[ $REPLY =~ ^[Yy]$ ]]; then
    print_status "\nPhase 4: Vulnerability Scanning"
    update_progress 90 "Vulnerability Scanning"
    docker-compose run --rm nuclei \
        -l "/results/httpx.txt" \
        -o "/results/nuclei.txt" \
        -severity low,medium,high,critical \
        -silent > /dev/null 2>&1 || print_warning "Nuclei failed"
    NUCLEI_COUNT=$(wc -l < "${RESULTS_DIR}/nuclei.txt" 2>/dev/null || echo 0)
    print_success "Nuclei scan completed: ${NUCLEI_COUNT} findings"
fi

# Generate summary report
print_status "\nGenerating summary report..."
update_progress 95 "Generating Report"

cat > "${RESULTS_DIR}/summary.txt" << EOF
Subdomain Scan Summary
======================
Domain: ${DOMAIN}
Scan ID: ${SCAN_ID}
Timestamp: $(date)

Results:
--------
Total Subdomains Found: ${TOTAL_SUBDOMAINS}
Verified Subdomains: ${VERIFIED}
Live HTTP/HTTPS Hosts: ${LIVE_HOSTS}

Tool Results:
-------------
- Subfinder: ${SUBFINDER_COUNT}
- Amass: ${AMASS_COUNT}
- Assetfinder: ${ASSETFINDER_COUNT}
- Findomain: ${FINDOMAIN_COUNT}
- Chaos: ${CHAOS_COUNT}

Files Generated:
----------------
- all_subdomains.txt: All discovered subdomains
- verified.txt: DNS verified subdomains
- httpx.txt: Live hosts with HTTP info
- nuclei.txt: Vulnerability scan results (if run)

Top 20 Subdomains:
------------------
$(head -20 "${RESULTS_DIR}/verified.txt" 2>/dev/null || echo "No verified subdomains")

EOF

print_success "Summary report generated: ${RESULTS_DIR}/summary.txt"
update_progress 100 "Scan Complete"

# Display summary
echo -e "\n${BLUE}================================${NC}"
echo -e "${BLUE}  Scan Summary${NC}"
echo -e "${BLUE}================================${NC}"
cat "${RESULTS_DIR}/summary.txt"

log_to_redis "Scan completed successfully!" "success"
log_to_redis "Total: ${TOTAL_SUBDOMAINS}, Verified: ${VERIFIED}, Live: ${LIVE_HOSTS}" "info"

echo -e "\n${GREEN}Scan completed successfully!${NC}"
echo -e "${GREEN}Results saved to: ${RESULTS_DIR}${NC}\n"

# Mark as completed in Redis
docker-compose exec -T redis redis-cli HSET "scan:${SCAN_ID}" "status" "completed" > /dev/null 2>&1 || true
