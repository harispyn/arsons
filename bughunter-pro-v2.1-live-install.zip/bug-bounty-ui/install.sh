#!/bin/bash
# ═══════════════════════════════════════════════════════════════
# BugHunter Pro v2.1 – Live Installation Script
# Setiap langkah dicetak secara real-time ke terminal.
# Usage:  chmod +x install.sh && sudo ./install.sh
# ═══════════════════════════════════════════════════════════════

# ── Warna ──────────────────────────────────────────────────────
RED='\033[0;31m'; GREEN='\033[0;32m'; CYAN='\033[0;36m'
YELLOW='\033[1;33m'; BLUE='\033[0;34m'; MAGENTA='\033[0;35m'
BOLD='\033[1m'; DIM='\033[2m'; NC='\033[0m'

# ── Konfigurasi ────────────────────────────────────────────────
INSTALL_DIR="/opt/bughunter-pro"
SERVICE_USER="bughunter"
NGINX_CONF="/etc/nginx/sites-available/bughunter"
LOG_FILE="/tmp/bughunter-install-$(date +%s).log"
TOTAL_STEPS=9
CURRENT_STEP=0

# ── Helper: progress bar ───────────────────────────────────────
progress_bar() {
  local pct=$1 width=40
  local filled=$(( pct * width / 100 ))
  local empty=$(( width - filled ))
  local bar=""
  for ((i=0; i<filled; i++)); do bar+="█"; done
  for ((i=0; i<empty;  i++)); do bar+="░"; done
  printf "\r  ${CYAN}[%s]${NC} ${BOLD}%3d%%${NC}" "$bar" "$pct"
}

# ── Helper: step header ────────────────────────────────────────
step() {
  CURRENT_STEP=$(( CURRENT_STEP + 1 ))
  local pct=$(( CURRENT_STEP * 100 / TOTAL_STEPS ))
  echo ""
  echo -e "${BLUE}┌─────────────────────────────────────────────────────────┐${NC}"
  echo -e "${BLUE}│${NC} ${BOLD}[${CURRENT_STEP}/${TOTAL_STEPS}] $1${NC}"
  echo -e "${BLUE}└─────────────────────────────────────────────────────────┘${NC}"
  progress_bar $pct
  echo ""
}

# ── Helper: log helper ─────────────────────────────────────────
log_ok()   { echo -e "  ${GREEN}  ✔${NC}  $1"; }
log_info() { echo -e "  ${CYAN}  ℹ${NC}  $1"; }
log_warn() { echo -e "  ${YELLOW}  ⚠${NC}  $1"; }
log_err()  { echo -e "  ${RED}  ✘${NC}  $1"; }

# ── Helper: spinner untuk long tasks ──────────────────────────
run_live() {
  # run_live "label" cmd [args...]
  local label="$1"; shift
  local spin=('⠋' '⠙' '⠹' '⠸' '⠼' '⠴' '⠦' '⠧' '⠇' '⠏')
  local i=0
  "$@" >> "$LOG_FILE" 2>&1 &
  local pid=$!
  while kill -0 $pid 2>/dev/null; do
    printf "\r  ${CYAN}  %s${NC}  %-52s" "${spin[$i]}" "$label"
    i=$(( (i+1) % 10 ))
    sleep 0.1
  done
  wait $pid
  local rc=$?
  if [[ $rc -eq 0 ]]; then
    printf "\r  ${GREEN}  ✔${NC}  %-52s\n" "$label"
  else
    printf "\r  ${RED}  ✘${NC}  %-52s\n" "$label (exit $rc)"
  fi
  return $rc
}

# ── Splash ─────────────────────────────────────────────────────
clear
echo -e "${CYAN}${BOLD}"
cat << 'BANNER'

  ╔══════════════════════════════════════════════════════════╗
  ║                                                          ║
  ║        ██████╗ ██╗   ██╗ ██████╗                        ║
  ║        ██╔══██╗██║   ██║██╔════╝                        ║
  ║        ██████╔╝██║   ██║██║  ███╗                       ║
  ║        ██╔══██╗██║   ██║██║   ██║                       ║
  ║        ██████╔╝╚██████╔╝╚██████╔╝                       ║
  ║        ╚═════╝  ╚═════╝  ╚═════╝                        ║
  ║                                                          ║
  ║      H U N T E R   P R O   v 2 . 1                      ║
  ║      Professional Bug Bounty Platform                    ║
  ║                                                          ║
  ╚══════════════════════════════════════════════════════════╝

BANNER
echo -e "${NC}"
echo -e "  ${DIM}Log: $LOG_FILE${NC}"
echo -e "  ${YELLOW}⚠  Untuk penggunaan pada target yang diizinkan saja!${NC}"
echo ""
sleep 1

# ── Root check ────────────────────────────────────────────────
if [[ $EUID -ne 0 ]]; then
  echo -e "${RED}[✗] Jalankan sebagai root: sudo ./install.sh${NC}"
  exit 1
fi

# ── Deteksi OS ────────────────────────────────────────────────
OS_NAME=$(grep -oP '(?<=^ID=).+' /etc/os-release 2>/dev/null | tr -d '"' || uname -s)
OS_VER=$(grep -oP '(?<=^VERSION_ID=).+' /etc/os-release 2>/dev/null | tr -d '"' || echo "unknown")
ARCH=$(uname -m)
log_info "OS    : ${BOLD}${OS_NAME} ${OS_VER} (${ARCH})${NC}"
log_info "Kernel: ${BOLD}$(uname -r)${NC}"
log_info "Waktu : ${BOLD}$(date '+%Y-%m-%d %H:%M:%S')${NC}"
echo ""

# ══════════════════════════════════════════════════════════════
# STEP 1 – Paket sistem
# ══════════════════════════════════════════════════════════════
step "Memperbarui paket sistem"

if command -v apt-get &>/dev/null; then
  echo -ne "  ${DIM}apt update ...${NC}"
  apt-get update -qq >> "$LOG_FILE" 2>&1
  echo -e "\r  ${GREEN}✔${NC}  apt-get update selesai"

  PKGS=(python3 python3-pip python3-venv nginx curl wget git jq
        golang-go nodejs npm nmap dnsutils whois
        libssl-dev build-essential net-tools)
  echo ""
  echo -e "  ${DIM}Menginstall ${#PKGS[@]} paket:${NC}"
  for pkg in "${PKGS[@]}"; do
    run_live "  apt install: $pkg" apt-get install -y -qq "$pkg"
  done

elif command -v yum &>/dev/null; then
  run_live "yum update" yum update -y -q
  PKGS=(python3 python3-pip nginx curl wget git jq golang nodejs npm nmap bind-utils openssl-devel)
  for pkg in "${PKGS[@]}"; do
    run_live "  yum install: $pkg" yum install -y -q "$pkg"
  done
else
  log_warn "Package manager tidak dikenali – lewati"
fi
log_ok "Semua paket sistem terinstall"

# ══════════════════════════════════════════════════════════════
# STEP 2 – Buat user & direktori
# ══════════════════════════════════════════════════════════════
step "Menyiapkan user & struktur direktori"

run_live "Membuat service user '$SERVICE_USER'" \
  bash -c "useradd -r -s /bin/false $SERVICE_USER 2>/dev/null; true"

for dir in "" findings reports recon wordlists logs static/css static/js; do
  run_live "mkdir $INSTALL_DIR/$dir" mkdir -p "$INSTALL_DIR/$dir"
done

run_live "Menyalin file aplikasi → $INSTALL_DIR" \
  bash -c "cp -r ./* $INSTALL_DIR/ 2>/dev/null; true"
run_live "Set kepemilikan $SERVICE_USER" \
  chown -R $SERVICE_USER:$SERVICE_USER "$INSTALL_DIR"
run_live "Set permission direktori" chmod 750 "$INSTALL_DIR"

log_ok "Direktori: $INSTALL_DIR"

# ══════════════════════════════════════════════════════════════
# STEP 3 – Python virtual environment
# ══════════════════════════════════════════════════════════════
step "Menyiapkan Python virtual environment"

cd "$INSTALL_DIR" || exit 1
run_live "Membuat venv" python3 -m venv venv
source venv/bin/activate

run_live "Upgrade pip" pip install --quiet --upgrade pip

echo ""
echo -e "  ${DIM}Menginstall Python dependencies dari requirements.txt:${NC}"
# Baca requirements dan install satu per satu agar live output terlihat
if [[ -f requirements.txt ]]; then
  while IFS= read -r pkg || [[ -n "$pkg" ]]; do
    [[ -z "$pkg" || "$pkg" =~ ^# ]] && continue
    run_live "  pip install: $pkg" pip install --quiet "$pkg"
  done < requirements.txt
fi
log_ok "Python environment siap di $INSTALL_DIR/venv"

# ══════════════════════════════════════════════════════════════
# STEP 4 – Go security tools
# ══════════════════════════════════════════════════════════════
step "Menginstall Go security tools"

export GOPATH="$HOME/go"
export PATH="$PATH:$GOPATH/bin"

GO_TOOLS=(
  "subfinder|github.com/projectdiscovery/subfinder/v2/cmd/subfinder@latest"
  "httpx|github.com/projectdiscovery/httpx/cmd/httpx@latest"
  "dnsx|github.com/projectdiscovery/dnsx/cmd/dnsx@latest"
  "nuclei|github.com/projectdiscovery/nuclei/v3/cmd/nuclei@latest"
  "katana|github.com/projectdiscovery/katana/cmd/katana@latest"
  "waybackurls|github.com/tomnomnom/waybackurls@latest"
  "gau|github.com/lc/gau/v2/cmd/gau@latest"
  "anew|github.com/tomnomnom/anew@latest"
  "dalfox|github.com/hahwul/dalfox/v2@latest"
  "ffuf|github.com/ffuf/ffuf/v2@latest"
  "assetfinder|github.com/tomnomnom/assetfinder@latest"
  "naabu|github.com/projectdiscovery/naabu/v2/cmd/naabu@latest"
)

echo ""
for entry in "${GO_TOOLS[@]}"; do
  name="${entry%%|*}"
  pkg="${entry##*|}"
  if command -v go &>/dev/null; then
    run_live "  go install: $name" go install "$pkg"
  else
    log_warn "  go tidak ditemukan – lewati $name"
    break
  fi
done

# Update nuclei templates
if command -v nuclei &>/dev/null; then
  run_live "Memperbarui nuclei templates" nuclei -update-templates -silent
  log_ok "Nuclei templates diperbarui"
else
  log_warn "nuclei tidak ditemukan – lewati update templates"
fi

# ══════════════════════════════════════════════════════════════
# STEP 5 – SSL Certificate
# ══════════════════════════════════════════════════════════════
step "Membuat sertifikat SSL self-signed"

mkdir -p /etc/ssl/bughunter

if [[ ! -f /etc/ssl/bughunter/cert.pem ]]; then
  run_live "Membuat private key RSA-2048" \
    openssl genrsa -out /etc/ssl/bughunter/key.pem 2048

  run_live "Membuat certificate self-signed (365 hari)" \
    openssl req -x509 -nodes -days 365 \
      -key /etc/ssl/bughunter/key.pem \
      -out /etc/ssl/bughunter/cert.pem \
      -subj "/C=ID/ST=Security/L=BugBounty/O=BugHunterPro/CN=bughunter.local"

  run_live "Membuat DH parameters 2048-bit (butuh ~30 detik)" \
    openssl dhparam -out /etc/ssl/bughunter/dhparam.pem 2048

  chmod 600 /etc/ssl/bughunter/*.pem
  log_ok "SSL certificates tersimpan di /etc/ssl/bughunter/"
else
  log_info "SSL certificate sudah ada – dilewati"
fi

# ══════════════════════════════════════════════════════════════
# STEP 6 – Konfigurasi Nginx
# ══════════════════════════════════════════════════════════════
step "Mengkonfigurasi Nginx reverse proxy"

run_live "Menyalin nginx.conf" \
  bash -c "cp $INSTALL_DIR/nginx.conf $NGINX_CONF 2>/dev/null; true"
run_live "Membuat symlink sites-enabled" \
  bash -c "ln -sf $NGINX_CONF /etc/nginx/sites-enabled/bughunter 2>/dev/null; true"
run_live "Menghapus default site" \
  bash -c "rm -f /etc/nginx/sites-enabled/default 2>/dev/null; true"

echo -ne "  ${DIM}Menguji konfigurasi nginx ...${NC}"
if nginx -t >> "$LOG_FILE" 2>&1; then
  echo -e "\r  ${GREEN}✔${NC}  Nginx config valid"
  run_live "Restart Nginx" systemctl restart nginx
  run_live "Enable Nginx autostart" systemctl enable nginx
else
  echo -e "\r  ${YELLOW}⚠${NC}  Nginx config test gagal – cek: nginx -t"
fi
log_ok "Nginx reverse proxy aktif"

# ══════════════════════════════════════════════════════════════
# STEP 7 – Systemd service
# ══════════════════════════════════════════════════════════════
step "Membuat & mengaktifkan systemd service"

log_info "Menulis /etc/systemd/system/bughunter-pro.service ..."

cat > /etc/systemd/system/bughunter-pro.service << UNIT
[Unit]
Description=BugHunter Pro - Professional Bug Bounty Platform v2.1
Documentation=https://github.com/shuvonsec/claude-bug-bounty
After=network.target nginx.service
Wants=network-online.target

[Service]
Type=simple
User=${SERVICE_USER}
Group=${SERVICE_USER}
WorkingDirectory=${INSTALL_DIR}
ExecStart=${INSTALL_DIR}/venv/bin/python ${INSTALL_DIR}/app.py
Restart=on-failure
RestartSec=5
StartLimitInterval=60
StartLimitBurst=5

# Logging
StandardOutput=append:${INSTALL_DIR}/logs/app.log
StandardError=append:${INSTALL_DIR}/logs/error.log

# Security hardening
NoNewPrivileges=yes
PrivateTmp=yes
ProtectSystem=strict
ReadWritePaths=${INSTALL_DIR}
ProtectHome=yes
CapabilityBoundingSet=

# Environment
Environment="PYTHONPATH=${INSTALL_DIR}"
Environment="FLASK_ENV=production"
Environment="HOST=127.0.0.1"
Environment="PORT=5000"

[Install]
WantedBy=multi-user.target
UNIT

run_live "systemctl daemon-reload" systemctl daemon-reload
run_live "Enable bughunter-pro service" systemctl enable bughunter-pro
run_live "Start bughunter-pro service" systemctl start bughunter-pro

# Tunggu service ready
echo -ne "  ${DIM}Menunggu service siap ...${NC}"
for i in {1..10}; do
  if systemctl is-active --quiet bughunter-pro; then
    echo -e "\r  ${GREEN}✔${NC}  Service aktif (${i}s)"
    break
  fi
  sleep 1
done
if ! systemctl is-active --quiet bughunter-pro; then
  echo -e "\r  ${YELLOW}⚠${NC}  Service belum aktif – cek: journalctl -u bughunter-pro"
fi

# ══════════════════════════════════════════════════════════════
# STEP 8 – Firewall
# ══════════════════════════════════════════════════════════════
step "Mengkonfigurasi firewall"

if command -v ufw &>/dev/null; then
  run_live "UFW allow port 80 (HTTP)"  bash -c "ufw allow 80/tcp comment 'BugHunter HTTP' 2>/dev/null; true"
  run_live "UFW allow port 443 (HTTPS)" bash -c "ufw allow 443/tcp comment 'BugHunter HTTPS' 2>/dev/null; true"
  run_live "UFW enable" bash -c "ufw --force enable 2>/dev/null; true"
  log_ok "UFW rules diterapkan"
elif command -v firewall-cmd &>/dev/null; then
  run_live "firewalld allow HTTP" bash -c "firewall-cmd --permanent --add-service=http 2>/dev/null; true"
  run_live "firewalld allow HTTPS" bash -c "firewall-cmd --permanent --add-service=https 2>/dev/null; true"
  run_live "firewalld reload" bash -c "firewall-cmd --reload 2>/dev/null; true"
  log_ok "Firewalld rules diterapkan"
else
  log_warn "Tidak ada UFW/firewalld – lewati konfigurasi firewall"
fi

# ══════════════════════════════════════════════════════════════
# STEP 9 – Verifikasi akhir
# ══════════════════════════════════════════════════════════════
step "Verifikasi instalasi"

echo ""
echo -e "  ${DIM}Memeriksa komponen sistem ...${NC}"
echo ""

check_item() {
  local label="$1" cmd="$2"
  if eval "$cmd" >> "$LOG_FILE" 2>&1; then
    log_ok "$label"
  else
    log_warn "$label (tidak ditemukan)"
  fi
}

check_item "Python venv"          "[[ -f $INSTALL_DIR/venv/bin/python ]]"
check_item "app.py"               "[[ -f $INSTALL_DIR/app.py ]]"
check_item "nginx service"        "systemctl is-active nginx --quiet"
check_item "bughunter-pro service" "systemctl is-active bughunter-pro --quiet"
check_item "SSL certificate"      "[[ -f /etc/ssl/bughunter/cert.pem ]]"
check_item "subfinder"            "command -v subfinder"
check_item "httpx"                "command -v httpx"
check_item "nuclei"               "command -v nuclei"
check_item "ffuf"                 "command -v ffuf"
check_item "nmap"                 "command -v nmap"

# HTTP health check
sleep 1
echo ""
echo -ne "  ${DIM}Health check HTTP ...${NC}"
if curl -sk http://127.0.0.1:5000/health | grep -q '"status":"ok"'; then
  echo -e "\r  ${GREEN}✔${NC}  Health check: ${BOLD}OK${NC}"
else
  echo -e "\r  ${YELLOW}⚠${NC}  Health check gagal – app mungkin masih booting"
fi

# ══════════════════════════════════════════════════════════════
# SELESAI
# ══════════════════════════════════════════════════════════════
progress_bar 100
echo ""
echo ""
echo -e "${GREEN}${BOLD}"
cat << 'DONE'
  ╔══════════════════════════════════════════════════════════╗
  ║                                                          ║
  ║   ✅  INSTALASI SELESAI!  BugHunter Pro v2.1 siap!      ║
  ║                                                          ║
  ╚══════════════════════════════════════════════════════════╝
DONE
echo -e "${NC}"

LOCAL_IP=$(hostname -I 2>/dev/null | awk '{print $1}' || echo "127.0.0.1")

echo -e "  ${BOLD}🌐 Akses Web UI:${NC}"
echo -e "     ${CYAN}https://${LOCAL_IP}${NC}       (LAN)"
echo -e "     ${CYAN}https://localhost${NC}         (lokal)"
echo -e "     ${CYAN}http://${LOCAL_IP}${NC}        (redirect → HTTPS)"
echo ""
echo -e "  ${BOLD}🔧 Manajemen Service:${NC}"
echo -e "     ${DIM}systemctl status   bughunter-pro${NC}"
echo -e "     ${DIM}systemctl restart  bughunter-pro${NC}"
echo -e "     ${DIM}journalctl -fu     bughunter-pro${NC}"
echo ""
echo -e "  ${BOLD}📁 Direktori:${NC}"
echo -e "     ${DIM}App   : $INSTALL_DIR${NC}"
echo -e "     ${DIM}Logs  : $INSTALL_DIR/logs/app.log${NC}"
echo -e "     ${DIM}Nginx : /var/log/nginx/bughunter_access.log${NC}"
echo -e "     ${DIM}SSL   : /etc/ssl/bughunter/${NC}"
echo ""
echo -e "  ${BOLD}📋 Install log:${NC}  ${DIM}$LOG_FILE${NC}"
echo ""
echo -e "  ${YELLOW}⚠  Terima peringatan SSL di browser (self-signed certificate)${NC}"
echo -e "  ${RED}⚠  GUNAKAN HANYA PADA TARGET YANG MEMILIKI IZIN EKSPLISIT!${NC}"
echo ""
