# Quick Start Guide

## 🚀 Getting Started

### 1. Initial Setup

```bash
# Clone and setup
git clone <repository-url>
cd subdomain-scanner

# Run setup script
chmod +x setup.sh
./setup.sh
```

### 2. Start Services

```bash
docker-compose up -d
```

### 3. Verify Services

```bash
docker-compose ps
```

## 📖 Usage Examples

### Web Interface (Recommended)

1. Open browser: `http://localhost:8080`
2. Enter domain: `example.com`
3. Select tools (all enabled by default)
4. Click "Start Scan"
5. Monitor real-time progress

### Command Line - Full Scan

```bash
./scan.sh example.com
```

This runs:
- ✅ Subfinder
- ✅ Amass (passive)
- ✅ Assetfinder
- ✅ Findomain
- ✅ Chaos
- ✅ DNSx verification
- ✅ HTTPx probing
- ⚠️ Nuclei (asks for confirmation)

**Output**: `./results/example.com_YYYYMMDD_HHMMSS/`

### Command Line - Quick Scan

```bash
./quick-scan.sh example.com
```

Fast scan using only:
- ✅ Subfinder
- ✅ DNSx
- ✅ HTTPx

**Output**: `./results/example.com_quick/`

### Python CLI

```bash
# Start scan
python3 cli.py scan example.com

# Start scan without monitoring
python3 cli.py scan example.com --no-monitor

# Check status
python3 cli.py status example.com_20240101_120000

# Get results
python3 cli.py results example.com_20240101_120000

# List all scans
python3 cli.py list
```

### Mass Scanning

```bash
# Create domains file
cat > domains.txt << 'DOMAINS'
example.com
test.com
demo.com
DOMAINS

# Run mass scan
./mass-scan.sh domains.txt
```

### REST API

```bash
# Start scan
curl -X POST http://localhost:8080/api/scan \
  -H "Content-Type: application/json" \
  -d '{
    "domain": "example.com",
    "options": {
      "subfinder": true,
      "amass": true,
      "dnsx": true,
      "httpx": true,
      "nuclei": false
    }
  }'

# Response: {"scan_id": "example.com_20240101_120000", "status": "started"}

# Check status
curl http://localhost:8080/api/scan/example.com_20240101_120000

# Get results
curl http://localhost:8080/api/scan/example.com_20240101_120000/results

# List scans
curl http://localhost:8080/api/scans
```

### Individual Tools

```bash
# Subfinder
docker-compose run --rm subfinder -d example.com

# Amass
docker-compose run --rm amass enum -d example.com

# Assetfinder
docker-compose run --rm assetfinder --subs-only example.com

# Findomain
docker-compose run --rm findomain -t example.com

# DNSx
echo "sub.example.com" | docker-compose run --rm dnsx

# HTTPx
echo "https://example.com" | docker-compose run --rm httpx -title -status-code

# Nuclei
docker-compose run --rm nuclei -u https://example.com
```

## 🎯 Scan Scenarios

### Scenario 1: Quick Discovery (5-10 min)

```bash
./quick-scan.sh example.com
```

**Use when**: Need fast results, initial reconnaissance

### Scenario 2: Comprehensive Scan (30-60 min)

```bash
./scan.sh example.com
```

**Use when**: Thorough enumeration needed, time available

### Scenario 3: Vulnerability Assessment

```bash
# Edit scan.sh and enable Nuclei by default, or:
python3 cli.py scan example.com --nuclei
```

**Use when**: Security audit, vulnerability research

### Scenario 4: Continuous Monitoring

```bash
# Create cron job
0 2 * * * cd /path/to/subdomain-scanner && ./scan.sh example.com
```

**Use when**: Regular monitoring, change detection

## 🔧 Configuration

### API Keys (Recommended)

#### Subfinder

Create `config/subfinder/provider-config.yaml`:

```yaml
virustotal:
  - YOUR_VIRUSTOTAL_API_KEY
shodan:
  - YOUR_SHODAN_API_KEY
censys:
  - YOUR_CENSYS_API_ID:YOUR_CENSYS_SECRET
securitytrails:
  - YOUR_SECURITYTRAILS_API_KEY
```

#### Amass

Create `config/amass/config.ini`:

```ini
[data_sources.VirusTotal]
[data_sources.VirusTotal.Credentials]
apikey = YOUR_VIRUSTOTAL_API_KEY

[data_sources.Shodan]
[data_sources.Shodan.Credentials]
apikey = YOUR_SHODAN_API_KEY
```

#### Chaos

Create `config/chaos/config.yaml`:

```yaml
api-key: YOUR_CHAOS_API_KEY
```

### Custom Wordlists

```bash
# Add wordlists
cp your-wordlist.txt wordlists/

# Use with tools
docker-compose run --rm subfinder -d example.com -w /wordlists/your-wordlist.txt
```

## 📊 Understanding Results

### File Structure

```
results/example.com_20240101_120000/
├── subfinder.txt       # Subfinder results
├── amass.txt          # Amass results
├── assetfinder.txt    # Assetfinder results
├── findomain.txt      # Findomain results
├── chaos.txt          # Chaos results
├── all_subdomains.txt # Merged results
├── verified.txt       # DNS verified
├── httpx.txt          # Live hosts
├── nuclei.txt         # Vulnerabilities
└── summary.txt        # Summary report
```

### Result Formats

**all_subdomains.txt**: Plain list
```
sub1.example.com
sub2.example.com
```

**verified.txt**: DNSx JSON
```json
{"host":"sub1.example.com","a":["1.2.3.4"],"cname":["cdn.example.com"]}
```

**httpx.txt**: HTTPx JSON
```json
{"url":"https://sub1.example.com","status-code":200,"title":"Example"}
```

## 🐛 Troubleshooting

### Services won't start

```bash
docker-compose down -v
docker-compose up -d --force-recreate
```

### Permission errors

```bash
sudo chown -R $USER:$USER .
chmod +x *.sh
```

### API not responding

```bash
docker-compose logs scanner-api
docker-compose restart scanner-api
```

### Out of memory

Edit `docker-compose.yml`:
```yaml
services:
  scanner-api:
    deploy:
      resources:
        limits:
          memory: 2G
```

### Slow scans

- Disable Amass (slowest)
- Use quick-scan.sh
- Add API keys for better rate limits

## 📈 Performance

| Scan Type | Duration | Subdomains | Tools Used |
|-----------|----------|------------|------------|
| Quick | 5-10 min | 50-200 | Subfinder, DNSx, HTTPx |
| Full | 30-60 min | 200-1000 | All except Nuclei |
| Deep | 1-3 hours | 500-2000 | All including Nuclei |

## 🔐 Best Practices

1. **Always get permission** before scanning
2. **Use API keys** for better results
3. **Start with quick scan** to validate
4. **Monitor resource usage** (RAM, disk)
5. **Regular backups** of results
6. **Update tools** regularly
7. **Rate limit** in production

## 🚨 Common Mistakes

❌ Scanning without permission  
❌ No API keys (limited results)  
❌ Running Nuclei on production  
❌ Not monitoring disk space  
❌ Ignoring rate limits  

✅ Get authorization first  
✅ Configure API keys  
✅ Test on staging/dev  
✅ Monitor resources  
✅ Respect rate limits  

