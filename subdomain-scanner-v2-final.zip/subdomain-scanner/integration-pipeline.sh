#!/bin/bash

# Integration pipeline example
# This shows how to use exported results with other security tools

set -e

SCAN_ID=$1

if [ -z "$SCAN_ID" ]; then
    echo "Usage: ./integration-pipeline.sh <scan_id>"
    echo "Example: ./integration-pipeline.sh example.com_20240101_120000"
    exit 1
fi

API_URL="http://localhost:8080/api"
PIPELINE_DIR="./pipeline/${SCAN_ID}"
mkdir -p "${PIPELINE_DIR}"

echo "================================"
echo "  Security Pipeline"
echo "================================"
echo "Scan ID: $SCAN_ID"
echo "Output: $PIPELINE_DIR"
echo "================================"
echo ""

# Step 1: Export live hosts
echo "[Step 1] Exporting live hosts..."
curl -s "${API_URL}/scan/${SCAN_ID}/export/live" -o "${PIPELINE_DIR}/targets.txt"
TARGETS=$(wc -l < "${PIPELINE_DIR}/targets.txt")
echo "✓ Got ${TARGETS} live targets"
echo ""

# Step 2: Advanced HTTP probing with HTTPx
echo "[Step 2] Advanced HTTP probing..."
if command -v httpx &> /dev/null; then
    cat "${PIPELINE_DIR}/targets.txt" | httpx \
        -title \
        -status-code \
        -tech-detect \
        -web-server \
        -content-length \
        -follow-redirects \
        -json \
        -silent \
        -o "${PIPELINE_DIR}/httpx_detailed.json"
    echo "✓ HTTP probing completed"
else
    echo "⚠ HTTPx not found, using Docker..."
    docker-compose run --rm httpx \
        -l "${PIPELINE_DIR}/targets.txt" \
        -title -status-code -tech-detect \
        -json -silent \
        -o "${PIPELINE_DIR}/httpx_detailed.json"
fi
echo ""

# Step 3: Screenshot with Gowitness
echo "[Step 3] Capturing screenshots..."
if command -v gowitness &> /dev/null; then
    mkdir -p "${PIPELINE_DIR}/screenshots"
    gowitness file \
        -f "${PIPELINE_DIR}/targets.txt" \
        -P "${PIPELINE_DIR}/screenshots" \
        --disable-logging
    echo "✓ Screenshots saved to ${PIPELINE_DIR}/screenshots"
else
    echo "⚠ Gowitness not installed, skipping..."
fi
echo ""

# Step 4: Vulnerability scanning with Nuclei
echo "[Step 4] Vulnerability scanning..."
if command -v nuclei &> /dev/null; then
    nuclei \
        -l "${PIPELINE_DIR}/targets.txt" \
        -severity low,medium,high,critical \
        -json \
        -silent \
        -o "${PIPELINE_DIR}/nuclei_findings.json"
    
    VULNS=$(jq -s 'length' "${PIPELINE_DIR}/nuclei_findings.json" 2>/dev/null || echo 0)
    echo "✓ Found ${VULNS} potential vulnerabilities"
else
    echo "⚠ Nuclei not found, using Docker..."
    docker-compose run --rm nuclei \
        -l "${PIPELINE_DIR}/targets.txt" \
        -severity low,medium,high,critical \
        -json -silent \
        -o "${PIPELINE_DIR}/nuclei_findings.json"
fi
echo ""

# Step 5: Port scanning (top ports)
echo "[Step 5] Port scanning (top 100 ports)..."
if command -v nmap &> /dev/null; then
    echo "⚠ This may take a while..."
    nmap \
        -iL "${PIPELINE_DIR}/targets.txt" \
        --top-ports 100 \
        -T4 \
        -oN "${PIPELINE_DIR}/nmap_scan.txt" \
        -oX "${PIPELINE_DIR}/nmap_scan.xml" \
        > /dev/null 2>&1
    echo "✓ Port scan completed"
else
    echo "⚠ Nmap not installed, skipping..."
fi
echo ""

# Step 6: Technology detection
echo "[Step 6] Analyzing technologies..."
if [ -f "${PIPELINE_DIR}/httpx_detailed.json" ]; then
    jq -r '.tech[]' "${PIPELINE_DIR}/httpx_detailed.json" 2>/dev/null | \
        sort | uniq -c | sort -rn > "${PIPELINE_DIR}/technologies.txt"
    echo "✓ Technology analysis completed"
fi
echo ""

# Step 7: Extract interesting endpoints
echo "[Step 7] Extracting interesting patterns..."

# Find admin panels
grep -i "admin\|login\|dashboard\|panel" "${PIPELINE_DIR}/targets.txt" > "${PIPELINE_DIR}/admin_panels.txt" 2>/dev/null || true

# Find API endpoints
grep -i "api\|graphql\|rest\|v1\|v2" "${PIPELINE_DIR}/targets.txt" > "${PIPELINE_DIR}/api_endpoints.txt" 2>/dev/null || true

# Find development/staging
grep -i "dev\|test\|stage\|staging\|uat\|preprod" "${PIPELINE_DIR}/targets.txt" > "${PIPELINE_DIR}/dev_staging.txt" 2>/dev/null || true

echo "✓ Pattern extraction completed"
echo ""

# Step 8: Generate HTML report
echo "[Step 8] Generating HTML report..."

cat > "${PIPELINE_DIR}/report.html" << 'EOF'
<!DOCTYPE html>
<html>
<head>
    <title>Security Pipeline Report</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 40px; background: #f5f5f5; }
        .header { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); 
                  color: white; padding: 30px; border-radius: 10px; margin-bottom: 30px; }
        .section { background: white; padding: 20px; margin-bottom: 20px; 
                   border-radius: 10px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
        .stat { display: inline-block; margin: 10px 20px; }
        .stat-number { font-size: 2em; font-weight: bold; color: #667eea; }
        .stat-label { color: #666; }
        table { width: 100%; border-collapse: collapse; }
        th { background: #667eea; color: white; padding: 10px; text-align: left; }
        td { padding: 10px; border-bottom: 1px solid #ddd; }
        .critical { color: #dc3545; font-weight: bold; }
        .high { color: #fd7e14; font-weight: bold; }
        .medium { color: #ffc107; font-weight: bold; }
        .low { color: #28a745; font-weight: bold; }
    </style>
</head>
<body>
    <div class="header">
        <h1>🔒 Security Pipeline Report</h1>
        <p>Scan ID: SCAN_ID_PLACEHOLDER</p>
        <p>Generated: TIMESTAMP_PLACEHOLDER</p>
    </div>
    
    <div class="section">
        <h2>📊 Statistics</h2>
        <div class="stat">
            <div class="stat-number">TARGETS_COUNT</div>
            <div class="stat-label">Total Targets</div>
        </div>
        <div class="stat">
            <div class="stat-number">VULNS_COUNT</div>
            <div class="stat-label">Vulnerabilities</div>
        </div>
        <div class="stat">
            <div class="stat-number">ADMIN_COUNT</div>
            <div class="stat-label">Admin Panels</div>
        </div>
        <div class="stat">
            <div class="stat-number">API_COUNT</div>
            <div class="stat-label">API Endpoints</div>
        </div>
    </div>
    
    <div class="section">
        <h2>🎯 High-Value Targets</h2>
        <h3>Admin Panels</h3>
        <ul>ADMIN_LIST</ul>
        
        <h3>API Endpoints</h3>
        <ul>API_LIST</ul>
        
        <h3>Dev/Staging Environments</h3>
        <ul>DEV_LIST</ul>
    </div>
    
    <div class="section">
        <h2>🛡️ Vulnerabilities</h2>
        VULN_TABLE
    </div>
    
    <div class="section">
        <h2>💻 Technologies Detected</h2>
        TECH_LIST
    </div>
</body>
</html>
EOF

# Populate report
sed -i "s/SCAN_ID_PLACEHOLDER/${SCAN_ID}/g" "${PIPELINE_DIR}/report.html"
sed -i "s/TIMESTAMP_PLACEHOLDER/$(date)/g" "${PIPELINE_DIR}/report.html"
sed -i "s/TARGETS_COUNT/${TARGETS}/g" "${PIPELINE_DIR}/report.html"

ADMIN_COUNT=$(wc -l < "${PIPELINE_DIR}/admin_panels.txt" 2>/dev/null || echo 0)
API_COUNT=$(wc -l < "${PIPELINE_DIR}/api_endpoints.txt" 2>/dev/null || echo 0)
VULNS_COUNT=$(jq -s 'length' "${PIPELINE_DIR}/nuclei_findings.json" 2>/dev/null || echo 0)

sed -i "s/ADMIN_COUNT/${ADMIN_COUNT}/g" "${PIPELINE_DIR}/report.html"
sed -i "s/API_COUNT/${API_COUNT}/g" "${PIPELINE_DIR}/report.html"
sed -i "s/VULNS_COUNT/${VULNS_COUNT}/g" "${PIPELINE_DIR}/report.html"

echo "✓ HTML report generated"
echo ""

# Summary
echo "================================"
echo "  Pipeline Summary"
echo "================================"
echo "Total Targets: ${TARGETS}"
echo "Admin Panels: ${ADMIN_COUNT}"
echo "API Endpoints: ${API_COUNT}"
echo "Dev/Staging: $(wc -l < ${PIPELINE_DIR}/dev_staging.txt 2>/dev/null || echo 0)"
echo "Vulnerabilities: ${VULNS_COUNT}"
echo ""
echo "📂 Results saved to: ${PIPELINE_DIR}"
echo "📄 HTML Report: ${PIPELINE_DIR}/report.html"
echo ""
echo "Next Steps:"
echo "1. Review vulnerabilities in: ${PIPELINE_DIR}/nuclei_findings.json"
echo "2. Check admin panels: ${PIPELINE_DIR}/admin_panels.txt"
echo "3. Examine API endpoints: ${PIPELINE_DIR}/api_endpoints.txt"
echo "4. View screenshots: ${PIPELINE_DIR}/screenshots/"
echo "5. Open HTML report: firefox ${PIPELINE_DIR}/report.html"
echo ""
echo "✅ Pipeline completed!"
