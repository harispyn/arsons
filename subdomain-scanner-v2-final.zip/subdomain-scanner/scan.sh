#!/bin/bash

# Subdomain Scanner - Main Script
# Usage: ./scan.sh <domain> [options]

set -e

DOMAIN=$1
SCAN_ID="${DOMAIN}_$(date +%Y%m%d_%H%M%S)"
RESULTS_DIR="./results/${SCAN_ID}"

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Create results directory
mkdir -p "${RESULTS_DIR}"

echo -e "${BLUE}================================${NC}"
echo -e "${BLUE}  Subdomain Scanner v1.0${NC}"
echo -e "${BLUE}================================${NC}"
echo -e "${GREEN}Target Domain: ${DOMAIN}${NC}"
echo -e "${GREEN}Scan ID: ${SCAN_ID}${NC}"
echo -e "${BLUE}================================${NC}\n"

# Function to print status
print_status() {
    echo -e "${YELLOW}[*] $1${NC}"
}

print_success() {
    echo -e "${GREEN}[+] $1${NC}"
}

print_error() {
    echo -e "${RED}[-] $1${NC}"
}

# Phase 1: Subdomain Discovery
print_status "Phase 1: Subdomain Discovery"

# Subfinder
print_status "Running Subfinder..."
docker-compose run --rm subfinder \
    -d "${DOMAIN}" \
    -o "/results/subfinder.txt" \
    -silent \
    -all
print_success "Subfinder completed"

# Amass
print_status "Running Amass (passive)..."
docker-compose run --rm amass \
    enum -passive \
    -d "${DOMAIN}" \
    -o "/results/amass.txt"
print_success "Amass completed"

# Assetfinder
print_status "Running Assetfinder..."
docker-compose run --rm assetfinder \
    --subs-only "${DOMAIN}" > "${RESULTS_DIR}/assetfinder.txt"
print_success "Assetfinder completed"

# Findomain
print_status "Running Findomain..."
docker-compose run --rm findomain \
    -t "${DOMAIN}" \
    -u "/results/findomain.txt"
print_success "Findomain completed"

# Chaos
print_status "Running Chaos..."
docker-compose run --rm chaos \
    -d "${DOMAIN}" \
    -o "/results/chaos.txt" \
    -silent || print_error "Chaos failed (API key required)"

# Merge results
print_status "Merging results..."
cat "${RESULTS_DIR}"/*.txt 2>/dev/null | sort -u > "${RESULTS_DIR}/all_subdomains.txt"
TOTAL_SUBDOMAINS=$(wc -l < "${RESULTS_DIR}/all_subdomains.txt")
print_success "Found ${TOTAL_SUBDOMAINS} unique subdomains"

# Phase 2: DNS Verification
print_status "\nPhase 2: DNS Verification"
docker-compose run --rm dnsx \
    -l "/results/all_subdomains.txt" \
    -o "/results/verified.txt" \
    -json \
    -a -cname -resp \
    -silent

VERIFIED=$(wc -l < "${RESULTS_DIR}/verified.txt")
print_success "Verified ${VERIFIED} subdomains"

# Phase 3: HTTP Probing
print_status "\nPhase 3: HTTP Probing"
docker-compose run --rm httpx \
    -l "/results/verified.txt" \
    -o "/results/httpx.txt" \
    -json \
    -title -status-code -tech-detect \
    -follow-redirects \
    -silent

LIVE_HOSTS=$(wc -l < "${RESULTS_DIR}/httpx.txt")
print_success "Found ${LIVE_HOSTS} live hosts"

# Phase 4: Vulnerability Scanning (optional)
read -p "$(echo -e ${YELLOW}Do you want to run vulnerability scanning with Nuclei? [y/N]: ${NC})" -n 1 -r
echo
if [[ $REPLY =~ ^[Yy]$ ]]; then
    print_status "\nPhase 4: Vulnerability Scanning"
    docker-compose run --rm nuclei \
        -l "/results/httpx.txt" \
        -o "/results/nuclei.txt" \
        -severity low,medium,high,critical \
        -silent
    print_success "Nuclei scan completed"
fi

# Generate summary report
print_status "\nGenerating summary report..."

cat > "${RESULTS_DIR}/summary.txt" << EOF
Subdomain Scan Summary
======================
Domain: ${DOMAIN}
Scan ID: ${SCAN_ID}
Timestamp: $(date)

Results:
--------
Total Subdomains Found: ${TOTAL_SUBDOMAINS}
Verified Subdomains: ${VERIFIED}
Live HTTP/HTTPS Hosts: ${LIVE_HOSTS}

Files Generated:
----------------
- all_subdomains.txt: All discovered subdomains
- verified.txt: DNS verified subdomains
- httpx.txt: Live hosts with HTTP info
- nuclei.txt: Vulnerability scan results (if run)

Top 10 Subdomains:
------------------
$(head -10 "${RESULTS_DIR}/verified.txt")

EOF

print_success "Summary report generated: ${RESULTS_DIR}/summary.txt"

# Display summary
echo -e "\n${BLUE}================================${NC}"
echo -e "${BLUE}  Scan Summary${NC}"
echo -e "${BLUE}================================${NC}"
cat "${RESULTS_DIR}/summary.txt"

echo -e "\n${GREEN}Scan completed successfully!${NC}"
echo -e "${GREEN}Results saved to: ${RESULTS_DIR}${NC}\n"
