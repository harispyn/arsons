#!/bin/bash

# Quick scan script - Fast subdomain discovery
# Usage: ./quick-scan.sh <domain>

DOMAIN=$1
OUTPUT_DIR="./results/${DOMAIN}_quick"

mkdir -p "${OUTPUT_DIR}"

echo "[*] Quick scan for: ${DOMAIN}"

# Run Subfinder only (fastest)
echo "[*] Running Subfinder..."
docker-compose run --rm subfinder \
    -d "${DOMAIN}" \
    -silent \
    -all | tee "${OUTPUT_DIR}/subdomains.txt"

# Count results
COUNT=$(wc -l < "${OUTPUT_DIR}/subdomains.txt")
echo "[+] Found ${COUNT} subdomains"

# Quick DNS check
echo "[*] Verifying with DNSx..."
docker-compose run --rm dnsx \
    -l "${OUTPUT_DIR}/subdomains.txt" \
    -silent | tee "${OUTPUT_DIR}/verified.txt"

VERIFIED=$(wc -l < "${OUTPUT_DIR}/verified.txt")
echo "[+] Verified ${VERIFIED} subdomains"

# Quick HTTP probe
echo "[*] Probing with HTTPx..."
docker-compose run --rm httpx \
    -l "${OUTPUT_DIR}/verified.txt" \
    -silent \
    -status-code | tee "${OUTPUT_DIR}/live.txt"

LIVE=$(wc -l < "${OUTPUT_DIR}/live.txt")
echo "[+] Found ${LIVE} live hosts"

echo "[+] Quick scan completed: ${OUTPUT_DIR}"
