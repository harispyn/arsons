#!/bin/bash

# Mass scan script - scan multiple domains from a file
# Usage: ./mass-scan.sh domains.txt

DOMAINS_FILE=$1

if [ ! -f "$DOMAINS_FILE" ]; then
    echo "Usage: ./mass-scan.sh domains.txt"
    exit 1
fi

echo "Starting mass scan..."
echo "Domains file: $DOMAINS_FILE"
echo ""

# Count domains
TOTAL=$(wc -l < "$DOMAINS_FILE")
CURRENT=0

# Create results directory
TIMESTAMP=$(date +%Y%m%d_%H%M%S)
MASS_RESULTS="./results/mass_scan_${TIMESTAMP}"
mkdir -p "${MASS_RESULTS}"

# Read domains and scan
while IFS= read -r domain; do
    # Skip empty lines and comments
    [[ -z "$domain" || "$domain" =~ ^# ]] && continue
    
    CURRENT=$((CURRENT + 1))
    echo "[$CURRENT/$TOTAL] Scanning: $domain"
    
    # Run quick scan
    ./quick-scan.sh "$domain"
    
    # Copy results
    cp -r "./results/${domain}_quick" "${MASS_RESULTS}/"
    
    echo "Completed: $domain"
    echo "---"
    
done < "$DOMAINS_FILE"

# Generate summary
echo "Generating summary..."
cat > "${MASS_RESULTS}/summary.txt" << EOF
Mass Scan Summary
=================
Timestamp: $(date)
Total Domains: $TOTAL
Results Directory: ${MASS_RESULTS}

Individual Results:
EOF

# Add individual summaries
for dir in "${MASS_RESULTS}"/*_quick; do
    domain=$(basename "$dir" | sed 's/_quick$//')
    subdomains=$(wc -l < "$dir/subdomains.txt" 2>/dev/null || echo 0)
    verified=$(wc -l < "$dir/verified.txt" 2>/dev/null || echo 0)
    live=$(wc -l < "$dir/live.txt" 2>/dev/null || echo 0)
    
    echo "  $domain: $subdomains subdomains, $verified verified, $live live" >> "${MASS_RESULTS}/summary.txt"
done

echo ""
echo "Mass scan completed!"
echo "Results: ${MASS_RESULTS}"
cat "${MASS_RESULTS}/summary.txt"
