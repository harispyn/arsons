#!/bin/bash

# Installation and setup script

echo "================================"
echo "  Subdomain Scanner Setup"
echo "================================"
echo ""

# Check Docker
if ! command -v docker &> /dev/null; then
    echo "❌ Docker is not installed. Please install Docker first."
    exit 1
fi
echo "✅ Docker found"

# Check Docker Compose
if ! command -v docker-compose &> /dev/null; then
    echo "❌ Docker Compose is not installed. Please install Docker Compose first."
    exit 1
fi
echo "✅ Docker Compose found"

# Create directories
echo ""
echo "Creating directories..."
mkdir -p config/{subfinder,amass,chaos,findomain}
mkdir -p results
mkdir -p wordlists
mkdir -p api/static
mkdir -p dockerfiles

# Create .gitkeep files
touch results/.gitkeep
touch config/.gitkeep
touch wordlists/.gitkeep

echo "✅ Directories created"

# Download wordlists (optional)
echo ""
read -p "Download wordlists? (y/n) " -n 1 -r
echo
if [[ $REPLY =~ ^[Yy]$ ]]; then
    echo "Downloading common subdomains wordlist..."
    curl -s https://raw.githubusercontent.com/danielmiessler/SecLists/master/Discovery/DNS/subdomains-top1million-5000.txt \
        -o wordlists/subdomains-top5000.txt
    echo "✅ Wordlist downloaded"
fi

# Download Nuclei templates
echo ""
read -p "Download Nuclei templates? (y/n) " -n 1 -r
echo
if [[ $REPLY =~ ^[Yy]$ ]]; then
    echo "Cloning Nuclei templates..."
    git clone --depth 1 https://github.com/projectdiscovery/nuclei-templates.git nuclei-templates
    echo "✅ Nuclei templates downloaded"
fi

# Build Docker images
echo ""
echo "Building Docker images..."
docker-compose build

if [ $? -eq 0 ]; then
    echo "✅ Docker images built successfully"
else
    echo "❌ Failed to build Docker images"
    exit 1
fi

# Start services
echo ""
read -p "Start services now? (y/n) " -n 1 -r
echo
if [[ $REPLY =~ ^[Yy]$ ]]; then
    echo "Starting services..."
    docker-compose up -d
    
    # Wait for services
    echo "Waiting for services to be ready..."
    sleep 10
    
    # Check health
    echo ""
    echo "Checking service health..."
    
    # Check API
    if curl -s http://localhost:8080/api/health > /dev/null; then
        echo "✅ API is running"
    else
        echo "⚠️  API might not be ready yet"
    fi
    
    # Check database
    if docker-compose exec -T postgres pg_isready -U scanner > /dev/null 2>&1; then
        echo "✅ Database is running"
    else
        echo "⚠️  Database might not be ready yet"
    fi
    
    # Check Redis
    if docker-compose exec -T redis redis-cli ping > /dev/null 2>&1; then
        echo "✅ Redis is running"
    else
        echo "⚠️  Redis might not be ready yet"
    fi
fi

# Make scripts executable
chmod +x scan.sh quick-scan.sh

echo ""
echo "================================"
echo "  Setup Complete!"
echo "================================"
echo ""
echo "📊 Web Dashboard: http://localhost:8080"
echo "🗄️  Adminer (DB): http://localhost:8081"
echo ""
echo "Quick commands:"
echo "  Full scan:  ./scan.sh example.com"
echo "  Quick scan: ./quick-scan.sh example.com"
echo ""
echo "Docker commands:"
echo "  View logs:     docker-compose logs -f"
echo "  Stop services: docker-compose down"
echo "  Restart:       docker-compose restart"
echo ""
echo "⚠️  Important: Add API keys to config/ for better results"
echo "    See README.md for configuration details"
echo ""
