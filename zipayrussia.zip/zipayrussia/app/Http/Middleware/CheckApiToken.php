<?php
namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;

class CheckApiToken
{
    public function handle(Request $request, Closure $next)
    {
        //dd(Session::has('token'));
        // Memeriksa apakah token ada di session
        if (!Session::has('token')) {
            return redirect()->route('login'); // Jika token tidak ada, redirect ke halaman login
        }

        return $next($request);
    }
}
