<?php
namespace App\Http\Middleware;

use Closure;
use Illuminate\Support\Facades\App;
use Illuminate\Support\Facades\Session;

class SetLocale
{
    public function handle($request, Closure $next)
    {
        // Ambil bahasa dari query atau session
        $locale = $request->query('lang') ?? Session::get('locale', config('app.locale'));

        //dd($request->query('lang'), Session::get('locale'), config('app.locale'));


        // Validasi apakah bahasa didukung
        if (in_array($locale, ['en', 'id', 'ru'])) {
            App::setLocale($locale); // Gunakan App::setLocale(), bukan PHP setlocale()
            Session::put('locale', $locale);
        }

        return $next($request);
    }
}
