<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use GuzzleHttp\Client;
use Illuminate\Support\Facades\Crypt;

class ActivationController extends Controller
{
    /**
     * Menampilkan form activation.
     */
    public function index(string $phoneNo = '')
    {
        // Hitung deviceID jika phoneNo tersedia
        $deviceID = $phoneNo ? Crypt::encryptString($phoneNo) : '';

        return view('activation', compact('phoneNo', 'deviceID'));
    }

    /**
     * Menangani proses activation.
     */
    public function activate(Request $request)
    {
        $request->validate([
            'phoneNo' => 'required|string',
        ]);

        try {
            $client = new Client();
            $deviceID = Crypt::encryptString($request->phoneNo); // Generate deviceID dari phoneNo

            $response = $client->post(config('services.multipocket.base_url') . '/api/Multipocket/Activation', [
                'json' => [
                    'mid' => config('services.multipocket.mid'),
                    'merchantToken' => config('services.multipocket.merchant_token'),
                    'phoneNo' => $request->phoneNo,
                    'deviceID' => $request->deviceID,
                ],
                'headers' => [
                    'Accept' => 'application/json',
                    'Content-Type' => 'application/json-patch+json',
                ],
            ]);

            return redirect()->route('otp.show', ['phoneNo' => $request->phoneNo])->with('success', 'Activation successful! Please verify OTP.');
        } catch (\Exception $e) {
            $statusCode = $e->getCode();
            $errorMessage = $e->getMessage();

            return back()->withErrors([
                'activation' => "Activation failed: {$errorMessage}",
                ]);
        }
    }

    /**
     * Menampilkan form verify OTP.
     */
    public function showVerifyForm(string $phoneNo)
    {
        return view('verify-otp', compact('phoneNo'));
    }

    /**
     * Menangani proses verifikasi OTP.
     */
    public function verifyOTP(Request $request)
    {
        // Validasi input
        $request->validate([
            'phoneNo' => 'required|string',    // Pastikan phoneNo dikirim melalui form
            'otp' => 'required|array|size:6', // Harus array dengan 4 elemen
            'otp.*' => 'required|digits:1',  // Setiap elemen harus angka 0-9
        ]);

        $otpCode = implode('', $request->otp); // Gabungkan array menjadi string

        try {
            $client = new Client();

            $response = $client->post(config('services.multipocket.base_url') . '/api/Multipocket/Verify', [
                'json' => [
                    'mid' => config('services.multipocket.mid'),
                    'merchantToken' => config('services.multipocket.merchant_token'),
                    'phoneNo' => $request->phoneNo, // Ambil dari form
                    'otpcode' => (int) $otpCode,
                ],
                'headers' => [
                    'Accept' => 'application/json',
                    'Content-Type' => 'application/json-patch+json',
                ],
            ]);

            return view('verify-success');
            //return redirect()->route('home')->with('success', 'OTP Verified Successfully!');
        } catch (\Exception $e) {
            $statusCode = $e->getCode();
            $errorMessage = $e->getMessage();

            return back()->withErrors([
                'otp' => "Verification failed: {$errorMessage}",
                ]);
        }
    }

    /**
     * Menangani permintaan Resend OTP.
     */
    public function resendOTP(Request $request)
    {
        // Validasi nomor telepon
        $request->validate([
            'phoneNo' => 'required|string',
        ]);

        try {
            $client = new Client();

            $response = $client->post(config('services.multipocket.base_url') . '/api/Multipocket/Resend', [
                'json' => [
                    'mid' => config('services.multipocket.mid'),
                    'merchantToken' => config('services.multipocket.merchant_token'),
                    'phoneNo' => $request->phoneNo,
                ],
                'headers' => [
                    'Accept' => 'application/json',
                    'Content-Type' => 'application/json-patch+json',
                ],
            ]);

            // Redirect ke halaman Verify OTP dengan nomor telepon
            return redirect()->route('otp.show', ['phoneNo' => $request->phoneNo])
            ->with('success', 'OTP has been resent successfully!');
        } catch (\Exception $e) {
            $statusCode = $e->getCode();
            $errorMessage = $e->getMessage();

            return back()->withErrors([
                'resend' => "Failed to resend OTP: {$errorMessage}",
                ]);
        }
    }}
