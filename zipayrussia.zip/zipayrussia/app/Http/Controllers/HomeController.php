<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;
use GuzzleHttp\Client;
use GuzzleHttp\Exception\RequestException;


class HomeController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $data=Session::get('api_response');

        if ($data['isPhoneVerified']=='False')
        {
            return redirect()->route('activation.index', ['phoneNo' => $data['phoneNumber']])
            ->with('success', 'registration successful!');
        }

        $client = new Client();
        // Kirim request ke API
        $response = $client->post(config('services.multipocket.base_url') . '/api/Multipocket/Balance', [
            'json' => [
                'mid' => config('services.multipocket.mid'),
                'merchantToken' => config('services.multipocket.merchant_token'),
                'phoneNo' => $data['phoneNumber'],
                'userToken' => $data['token'],
            ],
            'headers' => [
                'Accept' => 'application/json',
                'Content-Type' => 'application/json-patch+json',
            ],
        ]);

        $dataapi = json_decode($response->getBody()->getContents(), true)['result'];
        return view('home', ['user' => $data['firstName'] .' '.Session::get('api_response')['lastName']
            ,'balance'=>$dataapi['zipayPocket']
        ]);
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        //
    }
}
