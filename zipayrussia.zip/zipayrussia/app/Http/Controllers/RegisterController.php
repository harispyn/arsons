<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use GuzzleHttp\Client;
use GuzzleHttp\Exception\RequestException;


class RegisterController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
        return view('register');
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        // Validasi data input
        $request->validate([
            'firstName' => 'required|string|max:255',
            'lastName' => 'required|string|max:255',
            'email' => 'required|email',
            'phoneNo' => 'required|string',
            'pin' => 'required|min:6',
        ]);

        try {
            // Buat instance Guzzle
            $client = new Client();

            // Kirim request ke API
            $response = $client->post(config('services.multipocket.base_url') . '/api/Multipocket/Register', [
                'json' => [
                    'mid' => config('services.multipocket.mid'),
                    'merchantToken' => config('services.multipocket.merchant_token'),
                    'firstName' => $request->firstName,
                    'lastName' => $request->lastName,
                    'email' => $request->email,
                    'phoneNo' => $request->phoneNo,
                    'pin' => $request->pin,
                ],
                'headers' => [
                    'Accept' => 'application/json',
                    'Content-Type' => 'application/json-patch+json',
                ],
            ]);

            $data = json_decode($response->getBody()->getContents(), true);

            // Berikan feedback ke pengguna jika berhasil
            //return redirect()->route('activation.index')->with('success', 'Account created successfully!');
            return redirect()->route('activation.index', ['phoneNo' => $request->phoneNo])
            ->with('success', 'registration successful!');
        } catch (RequestException $e) {
            // Tangkap status code
            $statusCode = $e->hasResponse() ? $e->getResponse()->getStatusCode() : null;

            // Ambil pesan error dari response body (jika tersedia)
            $errorMessage = $e->hasResponse()? json_decode($e->getResponse()->getBody()->getContents(), true)['message'] ?? 'Unknown error occurred'
                : 'Unable to connect to the API.';
                // Kembalikan error ke view
                return back()->withErrors([
                    'register' => "Error {$statusCode}: {$errorMessage}",
                    ]);
        }
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        //
    }
}
