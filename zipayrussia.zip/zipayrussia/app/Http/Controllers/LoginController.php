<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use GuzzleHttp\Client;
use GuzzleHttp\Exception\RequestException;
use Illuminate\Support\Facades\Session;

class LoginController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index(Request $request)
    {

        // Kirim nilai ke view
        return view('login', ['deviceId' => mt_rand(100000000000000, 999999999999999)]);
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        // Validasi input
        $request->validate([
            'username' => 'required|string',
            'password' => 'required|string',
            'deviceType' => 'required|string',
            'deviceId' => 'required|integer',
        ]);

        try {
            // Guzzle HTTP client
            $client = new Client();
            $url = config('services.multipocket.base_url') . '/api/Auth/Login'; // URL dari konfigurasi .env
            //die($url);
            // Kirimkan POST request ke API
            $response = $client->post($url, [
                'headers' => [
                    'Accept' => 'application/json',
                    'Content-Type' => 'application/json-patch+json',
                ],
                'json' => [
                    'username' => $request->username,
                    'password' => $request->password,
                    'deviceType' => $request->deviceType,
                    'deviceId' => $request->deviceId,
                ],
            ]);
            //dd($response);die;

            // Decode responsenya
            $responseBody = json_decode($response->getBody()->getContents(), true);
            $data=$responseBody['result'];

            if (isset($data['token'])) {
                // Menyimpan data token atau informasi lainnya di session
                Session::put('api_response', $data);  // Menyimpan respons API ke session
                Session::put('token', $data['token']); // Sesuaikan sesuai respons API

                // Redirect atau lakukan sesuatu setelah login berhasil
                return redirect()->route('home');
            }

            return redirect()->route('home')->with('success', 'Login successful!');
        } catch (\GuzzleHttp\Exception\ClientException $e) {
            // Tangani error dari API
            $statusCode = $e->getResponse()->getStatusCode();
            $errorMessage = json_decode($e->getResponse()->getBody()->getContents(), true);

            return back()->withErrors([
                'login' => 'Login failed: ' . ($errorMessage['message'] ?? 'Unknown error') . " (Code: $statusCode)"
            ]);
        } catch (\Exception $e) {
            return back()->withErrors([
                'login' => "Unexpected error: " . $e->getMessage(),
            ]);
        }
    }
    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        //
    }
    /**
     *
     * @param Request $request
     * @return unknown
     */
    public function logout(Request $request)
    {
        // Ambil token dari session
        $token = Session::get('token'); // Ambil token yang disimpan di session

        if (!$token) {
            return redirect()->route('login')->with('error', 'You are not logged in.');
        }

        try {
            // Guzzle HTTP client
            $client = new Client();
            $url = config('services.multipocket.base_url') . '/api/Auth/logout'; // URL dari konfigurasi .env

            // Kirimkan POST request ke API logout dengan token
            $client->post($url, [
                'headers' => [
                    'Accept' => 'application/json',
                    'Authorization' => "Bearer $token", // Sertakan token dari session
                ],
            ]);

            // Hapus semua data yang terkait dengan session login
            Session::forget('api_response'); // Hapus respons API
            Session::forget('token');       // Hapus token

            // Redirect ke halaman login dengan pesan sukses
            return redirect()->route('login')->with('success', 'You have been logged out successfully.');
        } catch (\GuzzleHttp\Exception\ClientException $e) {
            // Tangani error dari API
            $statusCode = $e->getResponse()->getStatusCode();
            $errorMessage = json_decode($e->getResponse()->getBody()->getContents(), true);

            return back()->withErrors([
                'logout' => 'Logout failed: ' . ($errorMessage['message'] ?? 'Unknown error') . " (Code: $statusCode)"
            ]);
        } catch (\Exception $e) {
            // Tangani error umum lainnya
            return back()->withErrors([
                'logout' => "Unexpected error: " . $e->getMessage(),
            ]);
        }
    }

    public function resetPassword(Request $request)
    {
        $request->validate([
            'phoneNo' => 'required|string',
        ]);

        try {
            // Data yang akan dikirim ke API
            $data = [
                'mid' => config('services.multipocket.mid'),
                'merchantToken' => config('services.multipocket.merchant_token'),
                'phoneNo' => $request->phoneNo,
            ];
            //dd($data);

            // Eksekusi request ke API menggunakan Guzzle
            // Guzzle HTTP client
            $client = new Client();
            $url = config('services.multipocket.base_url') . '/api/Merchant/ChangePin'; // URL dari konfigurasi .env
            //die($url);
            // Kirimkan POST request ke API
            $response = $client->post($url, [
                'headers' => [
                    'Accept' => 'application/json',
                    'Content-Type' => 'application/json-patch+json',
                ],
                'json' => $data,
            ]);

            //dd($response);

            // Jika request berhasil
            if ($response->getStatusCode() === 200) {
                return redirect()->route('password.verifyreset', [
                    'phoneNo' => $request->phoneNo,
                ])->with('success', 'Reset instruction sent successfully.');
            }
        } catch (\GuzzleHttp\Exception\ClientException $e) {
            // Tangkap error dari API
            $errorResponse = json_decode($e->getResponse()->getBody()->getContents(), true);
            return back()->withErrors(['phoneNo' => $errorResponse['message'] ?? 'Failed to send reset instruction.']);
        } catch (\Exception $e) {
            // Tangkap error lain
            return back()->withErrors(['phoneNo' => 'An error occurred: ' . $e->getMessage()]);
        }
    }

    /**
     * Menampilkan halaman verifikasi reset password.
     */
    public function verifyReset(Request $request)
    {
        $phoneNo = $request->phoneNo;

        return view('new-password', compact('phoneNo'));
    }

    public function confirmPassword(Request $request)
    {
        $request->validate([
            'phoneNo' => 'required|string',
            'newPin' => 'required|string|min:6|max:20',
            'confirmNewPin' => 'required|string|same:newPin',
            'otp' => 'required|integer',
        ]);

        try {
            // Data yang akan dikirim ke API
            $data = [
                'mid' => config('services.multipocket.mid'),
                'merchantToken' => config('services.multipocket.merchant_token'),
                'phoneNo' => $request->phoneNo,
                'newPin' => $request->newPin,
                'confirmNewPin' => $request->confirmNewPin,
                'otp' => $request->otp,
            ];

            $client = new Client();
            $url = config('services.multipocket.base_url') . '/api/Merchant/VerifyChangePin'; // URL dari konfigurasi .env
            //die($url);
            // Kirimkan POST request ke API
            $response = $client->post($url, [
                'headers' => [
                    'Accept' => 'application/json',
                    'Content-Type' => 'application/json-patch+json',
                ],
                'json' => $data,
            ]);

            // Jika request berhasil
            if ($response->getStatusCode() === 200) {
                return redirect()->route('password.confirmview')
                ->with('success', 'New password has been set successfully.');
            }
        } catch (\GuzzleHttp\Exception\ClientException $e) {
            // Tangkap error dari API
            $errorResponse = json_decode($e->getResponse()->getBody()->getContents(), true);
            return back()->withErrors(['otp' => $errorResponse['message'] ?? 'Failed to verify new password.']);
        } catch (\Exception $e) {
            // Tangkap error lain
            return back()->withErrors(['otp' => 'An error occurred: ' . $e->getMessage()]);
        }
    }

    /**
     * Menampilkan halaman konfirmasi password baru.
     */
    public function confirmPasswordView()
    {
        return view('password-confirm');
    }
}
