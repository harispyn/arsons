namespace App\Http\Controllers;

use Illuminate\Http\Request;
use GuzzleHttp\Client;

class QRController extends Controller
{
    public function process(Request $request)
    {
        $validated = $request->validate([
            'qrCode' => 'required|string',
        ]);

        $client = new Client();
        $response = $client->post('https://apidev.zipay.id/api/Qris/IssuerScan', [
            'headers' => [
                'Accept' => 'application/json',
                'Content-Type' => 'application/json-patch+json',
            ],
            'json' => [
                'qrCode' => $validated['qrCode'],
                'phoneNumber' => auth()->user()->phone_number, // Pastikan ini ada
                'mid' => env('ZIPAY_MID'),
                'merchantToken' => env('ZIPAY_MERCHANT_TOKEN'),
            ],
        ]);

        return response()->json(json_decode($response->getBody()->getContents(), true));
    }
}
