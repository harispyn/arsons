@extends('layouts.app')

@section('title', 'Register')

@section('content')
    <!-- Preload -->
    <div class="preload preload-container">
        <div class="preload-logo">
            <div class="spinner"></div>
        </div>
    </div>
    <!-- /Preload -->

    <!-- Header -->
    <div class="header">
        <div class="tf-container">
            <div class="tf-statusbar br-none d-flex justify-content-center align-items-center">
                <a href="#" class="back-btn"> <i class="icon-left"></i> </a>
            </div>
        </div>
    </div>
    <!-- /Header -->

    <!-- Verify Account Section -->
    <div class="verify-account-section">
        <div class="tf-container">
            <div class="image-box">
                <img src="{{ asset('images/user/register.jpg') }}" alt="images">
            </div>
            <div class="tf-content mt-2">
                <h1 class="mb-2 text-center">You’re verified</h1>
                <p class="text-center fw_4 mb-7">You have been verified your information.
                    Let’s make transactions!</p>
            </div>
            <a href="{{ route('login') }}" class="tf-btn accent large">Done</a>
        </div>
    </div>
@endsection
