@extends('layouts.app')

@section('title', 'Scan QR Code')

@section('content')
<div class="preload preload-container">
    <div class="preload-logo">
        <div class="spinner"></div>
    </div>
</div>

<div class="header">
    <div class="tf-container">
        <div class="tf-statusbar d-flex justify-content-center align-items-center">
            <a href="{{ route('qr-code') }}" class="back-btn"> <i class="icon-left"></i> </a>
            <h3>Scan QR Code</h3>
        </div>
    </div>
</div>

<div class="wrap-scan-camera">
    <div class="tf-container">
        <!-- Tempat untuk menampilkan kamera -->
        <video id="qr-video" style="width: 100%; height: auto; border: 1px solid #ccc;"></video>
        <p id="scan-result" class="text-center mt-3">Point your camera at a QR Code</p>
    </div>
</div>

<script src="{{ asset('javascript/qr-scanner.min.js') }}"></script>
<script>
    document.addEventListener("DOMContentLoaded", () => {
        const video = document.getElementById('qr-video'); // Element video
        const resultText = document.getElementById('scan-result'); // Element untuk hasil scan

        // Inisialisasi QR Scanner
        const qrScanner = new QrScanner(video, result => {
            resultText.innerHTML = `QR Code detected: ${result}`;
            alert(`QR Code: ${result}`);

            // Kirim hasil QR Code ke server
            fetch("{{ route('process-qr') }}", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                    "X-CSRF-TOKEN": "{{ csrf_token() }}"
                },
                body: JSON.stringify({ qrCode: result })
            })
            .then(response => response.json())
            .then(data => {
                alert("QR Code processed successfully!");
                window.location.href = "{{ route('qr-code') }}";
            })
            .catch(err => {
                console.error("Error processing QR Code: ", err);
                alert("Error processing QR Code.");
            });

            // Hentikan scanner setelah membaca QR Code
            qrScanner.stop();
        });

        // Mulai QR Scanner
        qrScanner.start().catch(err => {
            console.error("Error starting QR scanner:", err);
            alert("Error accessing camera. Please check your browser settings.");
        });
    });
</script>
@endsection
