@extends('layouts.app')

@section('title', 'Verify OTP')

@section('content')
    <div class="header">
        <div class="tf-container">
            <div class="tf-statusbar br-none d-flex justify-content-center align-items-center">
                <a href="#" class="back-btn"> <i class="icon-left"></i> </a>
                <h3>Verification OTP</h3>
            </div>
        </div>
    </div>

    <div class="mt-5">
        <div class="tf-container">
            @if (session('success'))
                <div class="alert alert-success">
                    {{ session('success') }}
                </div>
            @endif

            @if ($errors->any())
                <div class="alert alert-danger">
                    <ul>
                        @foreach ($errors->all() as $error)
                            <li>{{ $error }}</li>
                        @endforeach
                    </ul>
                </div>
            @endif

            <form class="tf-form tf-form-verify" action="{{ route('otp.verify') }}" method="POST">
                @csrf
                <!-- Hidden input untuk phoneNo -->
                <input type="hidden" name="phoneNo" value="{{ $phoneNo }}">

                <div class="d-flex group-input-verify">
                    <input type="tel" maxlength="1" pattern="[0-9]" class="input-verify" name="otp[]" required>
                    <input type="tel" maxlength="1" pattern="[0-9]" class="input-verify" name="otp[]" required>
                    <input type="tel" maxlength="1" pattern="[0-9]" class="input-verify" name="otp[]" required>
                    <input type="tel" maxlength="1" pattern="[0-9]" class="input-verify" name="otp[]" required>
                    <input type="tel" maxlength="1" pattern="[0-9]" class="input-verify" name="otp[]" required>
                    <input type="tel" maxlength="1" pattern="[0-9]" class="input-verify" name="otp[]" required>
                </div>

                <div class="text-send-code">
                    <p class="fw_4">A code has been sent to your phone</p>
                    <p class="primary_color fw_7">Resend in&nbsp;<span class="js-countdown" data-timer="60" data-labels=" :  ,  : , : , "></span></p>
                    <p class="primary_color fw_7">Didn’t receive the code? Resend below:</p>
                </div>

                <div class="bottom-navigation-bar bottom-btn-fixed">
                    <button type="submit" class="tf-btn accent large">Verify</button>
                </div>
            </form>

            <form action="{{ route('otp.resend') }}" method="POST" class="mt-3">
                @csrf
                <input type="hidden" name="phoneNo" value="{{ $phoneNo }}">
                <button type="submit" class="tf-btn accent small">Resend OTP</button>
            </form>
        </div>
    </div>
@endsection

@push('scripts')
    <script type="text/javascript" src="{{ asset('javascript/count-down.js') }}"></script>
    <script type="text/javascript" src="{{ asset('javascript/verify-input.js') }}"></script>
@endpush

