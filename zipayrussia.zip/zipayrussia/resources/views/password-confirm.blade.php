@extends('layouts.app')

@section('title', 'Password Confirmed')

@section('content')
    <div class="mt-8 pw-confirm-section">
        <div class="tf-container">
            <div class="image-box">
                <img src="{{ asset('images/user/new-pass.jpg') }}" alt="images">
            </div>
            <div class="tf-content mt-2">
                <h1 class="mb-2 text-center">New Password Confirmed Successfully</h1>
                <p class="text-center fw_4">
                    You have successfully confirmed your new password. Please use your new password when logging in.
                </p>
            </div>
            <a href="{{ route('login') }}" class="tf-btn accent large">Login</a>
        </div>
    </div>
@endsection
