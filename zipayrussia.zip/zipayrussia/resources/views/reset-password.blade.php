@extends('layouts.app')

@section('title', 'Reset Password')

@section('content')
    <!-- Preload -->
    <div class="preload preload-container">
        <div class="preload-logo">
            <div class="spinner"></div>
        </div>
    </div>
    <!-- /Preload -->

    <!-- Header -->
    <div class="header is-fixed">
        <div class="tf-container">
            <div class="tf-statusbar br-none d-flex justify-content-center align-items-center">
                <a href="#" class="back-btn"> <i class="icon-left"></i> </a>
            </div>
        </div>
    </div>

    <!-- Reset Password Section -->
    <div id="app-wrap">
        <div class="reset-pass-section mt-5">
            <div class="tf-container">
                <div class="tf-title">
                    <h1>Reset Password</h1>
                    <p>Enter your registered email below to receive password reset instructions</p>
                </div>
                <div class="image-box">
                    <img src="{{ asset('images/user/forgotpass.jpg') }}" alt="image">
                </div>
                <form method="POST" action="{{ route('password.reset') }}" class="tf-form">
                    @csrf
                    <div class="group-input">
                        <label for="phoneNo">Email/Phone Number</label>
                        <input type="text" id="phoneNo" name="phoneNo" placeholder="Your Email/Phone Number" value="{{ old('phoneNo') }}">
                        @error('phoneNo')
                            <small class="text-danger">{{ $message }}</small>
                        @enderror
                    </div>
                    <button type="submit" class="tf-btn accent large">Next</button>
                </form>
            </div>
        </div>
    </div>
@endsection
