@extends('layouts.app')

@section('title', 'New Password')

@section('content')
    <!-- Preload -->
    <div class="preload preload-container">
        <div class="preload-logo">
            <div class="spinner"></div>
        </div>
    </div>
    <!-- /Preload -->

    <div class="mt-5 newpass-section">
        <div class="tf-container">
            <form method="POST" action="{{ route('password.confirmpassword') }}" class="tf-form">
                @csrf
                <h1>Create New Password</h1>
                <input type="hidden" name="phoneNo" value="{{ $phoneNo }}">
                <div class="group-input">
                    <label>New Password</label>
                    <input type="password" name="newPin" placeholder="6-20 characters">
                    @error('newPin')
                        <small class="text-danger">{{ $message }}</small>
                    @enderror
                </div>
                <div class="group-input last">
                    <label>Confirm Password</label>
                    <input type="password" name="confirmNewPin" placeholder="Confirm new password">
                    @error('confirmNewPin')
                        <small class="text-danger">{{ $message }}</small>
                    @enderror
                </div>
                <div class="group-input">
                    <label>OTP Code</label>
                    <input type="text" name="otp" placeholder="Enter OTP">
                    @error('otp')
                        <small class="text-danger">{{ $message }}</small>
                    @enderror
                </div>
                <button type="submit" class="tf-btn accent large">Reset Password</button>
            </form>
        </div>
    </div>
@endsection
