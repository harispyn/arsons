@extends('layouts.app')

@section('title', __('messages.login_title'))

@section('content')
<div class="container">
    <h1>{{ __('messages.login_title') }}</h1>
    <form method="POST" action="{{ route('login.store') }}">
        @csrf
        <div class="form-group">
            <label for="username">{{ __('messages.login_username') }}</label>
            <input type="text" name="username" id="username" class="form-control" required>
        </div>

        <div class="form-group">
            <label for="password">{{ __('messages.login_password') }}</label>
            <input type="password" name="password" id="password" class="form-control" required>
        </div>

        <div class="form-group">
            <label for="deviceType">{{ __('messages.login_device_type') }}</label>
            <select name="deviceType" id="deviceType" class="form-control" required>
                <option value="android">Android</option>
                <option value="iphone">iPhone</option>
            </select>
        </div>

        <input type="hidden" name="deviceId" value="{{ $deviceId }}">

        <p><strong>Device ID:</strong> {{ $deviceId }}</p>

        <div class="form-group mt-3">
            <button type="submit" class="btn btn-primary">{{ __('messages.login_button') }}</button>
        </div>
    </form>

    <p class="mt-3 text-center">
        <a href="{{ route('reset.password') }}" class="auth-link-fp">{{ __('messages.login_forgot_password') }}</a>
    </p>

    <p class="mb-9 fw-3 text-center">
        {{ __('messages.login_no_account') }} <a href="{{ route('register') }}" class="auth-link-rg">{{ __('messages.login_sign_up') }}</a>
    </p>

    @if ($errors->any())
        <div class="alert alert-danger mt-3">
            <ul>
                @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif
</div>
@endsection
