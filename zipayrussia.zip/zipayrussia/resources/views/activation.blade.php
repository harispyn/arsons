@extends('layouts.app')

@section('title', 'Activation')

@section('content')
    <!-- Preload -->
    <div class="preload preload-container">
        <div class="preload-logo">
            <div class="spinner"></div>
        </div>
    </div>
    <!-- /Preload -->

    <div class="header">
        <div class="tf-container">
            <div class="tf-statusbar br-none d-flex justify-content-center align-items-center">
                <a href="#" class="back-btn"> <i class="icon-left"></i> </a>
            </div>
        </div>
    </div>

    <div class="mt-3 activation-section">
        <div class="tf-container">
            <form class="tf-form" action="{{ route('activation.activate') }}" method="POST">
                @csrf
                <h1>Activation</h1>

                @if (session('success'))
                    <div class="alert alert-success">
                        {{ session('success') }}
                    </div>
                @endif

                @if ($errors->any())
                    <div class="alert alert-danger">
                        <ul>
                            @foreach ($errors->all() as $error)
                                <li>{{ $error }}</li>
                            @endforeach
                        </ul>
                    </div>
                @endif

                <div class="group-input">
                    <label>Phone Number</label>
                    <input type="text" name="phoneNo" placeholder="Enter your phone number" value="{{ old('phoneNo', $phoneNo) }}" required>
                </div>
                <div class="group-input">
                    <label>Device ID</label>
                    <input type="text" name="deviceID" placeholder="Generated Device ID" value="{{ $deviceID }}" readonly>
                </div>
                <button type="submit" class="tf-btn accent large">Activate</button>
            </form>
        </div>
    </div>
@endsection
