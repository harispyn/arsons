@extends('layouts.app')

@section('title', __('messages.register_title'))

@section('content')
<div class="header">
    <div class="tf-container">
        <div class="tf-statusbar br-none d-flex justify-content-center align-items-center">
            <a href="#" class="back-btn"> <i class="icon-left"></i> </a>
        </div>
    </div>
</div>

<div class="mt-3 register-section">
    <div class="tf-container">
        <form class="tf-form" action="{{ route('register.store') }}" method="POST">
            @csrf
            <h1>{{ __('messages.register_title') }}</h1>
            <div class="group-input">
                <label>{{ __('messages.first_name') }}</label>
                <input type="text" name="firstName" placeholder="{{ __('messages.placeholder_first_name') }}" required>
            </div>
            <div class="group-input">
                <label>{{ __('messages.last_name') }}</label>
                <input type="text" name="lastName" placeholder="{{ __('messages.placeholder_last_name') }}" required>
            </div>
            <div class="group-input">
                <label>{{ __('messages.email') }}</label>
                <input type="email" name="email" placeholder="{{ __('messages.placeholder_email') }}" required>
            </div>
            <div class="group-input">
                <label>{{ __('messages.phone_number') }}</label>
                <input type="text" name="phoneNo" placeholder="{{ __('messages.placeholder_phone_number') }}" required>
            </div>
            <div class="group-input">
                <label>{{ __('messages.pin') }}</label>
                <input type="password" name="pin" placeholder="{{ __('messages.placeholder_pin') }}" required>
            </div>
            <button type="submit" class="tf-btn accent large">{{ __('messages.create_account') }}</button>
        </form>
    </div>
    @if ($errors->any())
        <div class="alert alert-danger">
            <ul>
                @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif
</div>
@endsection
