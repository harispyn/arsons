$(function () {
    $('.datepicker').datepicker({
      language: "es",
      autoclose: true,
      todayHighlight:'TRUE',
      format: "dd/mm/yyyy"
    });
  });
  