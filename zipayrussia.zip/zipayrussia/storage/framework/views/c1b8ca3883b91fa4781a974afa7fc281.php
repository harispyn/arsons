<?php $__env->startSection('title', 'Scan QR Code'); ?>

<?php $__env->startSection('content'); ?>
<div class="preload preload-container">
    <div class="preload-logo">
        <div class="spinner"></div>
    </div>
</div>

<div class="header">
    <div class="tf-container">
        <div class="tf-statusbar d-flex justify-content-center align-items-center">
            <a href="<?php echo e(route('qr-code')); ?>" class="back-btn"> <i class="icon-left"></i> </a>
            <h3>Scan QR Code</h3>
        </div>
    </div>
</div>

<div class="wrap-scan-camera">
    <div class="tf-container">
        <!-- Tempat untuk menampilkan kamera -->
        <video id="qr-video" style="width: 100%; height: auto; border: 1px solid #ccc;"></video>
        <p id="scan-result" class="text-center mt-3">Point your camera at a QR Code</p>
    </div>
</div>

<script src="<?php echo e(asset('javascript/qr-scanner.min.js')); ?>"></script>
<script>
    document.addEventListener("DOMContentLoaded", () => {
        const video = document.getElementById('qr-video'); // Element video
        const resultText = document.getElementById('scan-result'); // Element untuk hasil scan

        // Inisialisasi QR Scanner
        const qrScanner = new QrScanner(video, result => {
            resultText.innerHTML = `QR Code detected: ${result}`;
            alert(`QR Code: ${result}`);

            // Kirim hasil QR Code ke server
            fetch("<?php echo e(route('process-qr')); ?>", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                    "X-CSRF-TOKEN": "<?php echo e(csrf_token()); ?>"
                },
                body: JSON.stringify({ qrCode: result })
            })
            .then(response => response.json())
            .then(data => {
                alert("QR Code processed successfully!");
                window.location.href = "<?php echo e(route('qr-code')); ?>";
            })
            .catch(err => {
                console.error("Error processing QR Code: ", err);
                alert("Error processing QR Code.");
            });

            // Hentikan scanner setelah membaca QR Code
            qrScanner.stop();
        });

        // Mulai QR Scanner
        qrScanner.start().catch(err => {
            console.error("Error starting QR scanner:", err);
            alert("Error accessing camera. Please check your browser settings.");
        });
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/awaludinr/Projects/zipayrussia/resources/views/scan-qr.blade.php ENDPATH**/ ?>