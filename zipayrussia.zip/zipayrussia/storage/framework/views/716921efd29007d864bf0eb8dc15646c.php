<?php $__env->startSection('title', 'QR Code'); ?>

<?php $__env->startSection('content'); ?>
<div class="preload preload-container">
    <div class="preload-logo">
        <div class="spinner"></div>
    </div>
</div>

<div class="header">
    <div class="tf-container">
        <div class="tf-statusbar d-flex justify-content-center align-items-center">
            <a href="<?php echo e(route('home')); ?>" class="back-btn"> <i class="icon-left"></i> </a>
            <h3>QR Code</h3>
        </div>
    </div>
</div>

<div class="wrap-qr">
    <div class="tf-container">
        <h2 class="fw_6 text-center">Screen Your QR Code</h2>
        <div class="logo-qr">
            <img src="<?php echo e(asset('images/scan-qr/qrcode1.png')); ?>" alt="QR Code">
        </div>
    </div>
</div>

<div class="bottom-navigation-bar bottom-btn-fixed">
    <div class="tf-container d-flex gap-3">
        <a href="#" class="tf-btn accent medium">Payment QR</a>
        <a href="<?php echo e(route('scan-qr')); ?>" class="tf-btn outline medium">Scan QR</a>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/awaludinr/Projects/zipayrussia/resources/views/qr-code.blade.php ENDPATH**/ ?>