<?php $__env->startSection('title', __('messages.register_title')); ?>

<?php $__env->startSection('content'); ?>
<div class="header">
    <div class="tf-container">
        <div class="tf-statusbar br-none d-flex justify-content-center align-items-center">
            <a href="#" class="back-btn"> <i class="icon-left"></i> </a>
        </div>
    </div>
</div>

<div class="mt-3 register-section">
    <div class="tf-container">
        <form class="tf-form" action="<?php echo e(route('register.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <h1><?php echo e(__('messages.register_title')); ?></h1>
            <div class="group-input">
                <label><?php echo e(__('messages.first_name')); ?></label>
                <input type="text" name="firstName" placeholder="<?php echo e(__('messages.placeholder_first_name')); ?>" required>
            </div>
            <div class="group-input">
                <label><?php echo e(__('messages.last_name')); ?></label>
                <input type="text" name="lastName" placeholder="<?php echo e(__('messages.placeholder_last_name')); ?>" required>
            </div>
            <div class="group-input">
                <label><?php echo e(__('messages.email')); ?></label>
                <input type="email" name="email" placeholder="<?php echo e(__('messages.placeholder_email')); ?>" required>
            </div>
            <div class="group-input">
                <label><?php echo e(__('messages.phone_number')); ?></label>
                <input type="text" name="phoneNo" placeholder="<?php echo e(__('messages.placeholder_phone_number')); ?>" required>
            </div>
            <div class="group-input">
                <label><?php echo e(__('messages.pin')); ?></label>
                <input type="password" name="pin" placeholder="<?php echo e(__('messages.placeholder_pin')); ?>" required>
            </div>
            <button type="submit" class="tf-btn accent large"><?php echo e(__('messages.create_account')); ?></button>
        </form>
    </div>
    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/awaludinr/Projects/zipayrussia/resources/views/register.blade.php ENDPATH**/ ?>