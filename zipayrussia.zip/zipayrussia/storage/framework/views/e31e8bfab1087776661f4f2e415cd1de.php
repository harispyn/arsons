<?php $__env->startSection('title', 'New Password'); ?>

<?php $__env->startSection('content'); ?>
    <!-- Preload -->
    <div class="preload preload-container">
        <div class="preload-logo">
            <div class="spinner"></div>
        </div>
    </div>
    <!-- /Preload -->

    <div class="mt-5 newpass-section">
        <div class="tf-container">
            <form method="POST" action="<?php echo e(route('password.confirmpassword')); ?>" class="tf-form">
                <?php echo csrf_field(); ?>
                <h1>Create New Password</h1>
                <input type="hidden" name="phoneNo" value="<?php echo e($phoneNo); ?>">
                <div class="group-input">
                    <label>New Password</label>
                    <input type="password" name="newPin" placeholder="6-20 characters">
                    <?php $__errorArgs = ['newPin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <small class="text-danger"><?php echo e($message); ?></small>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="group-input last">
                    <label>Confirm Password</label>
                    <input type="password" name="confirmNewPin" placeholder="Confirm new password">
                    <?php $__errorArgs = ['confirmNewPin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <small class="text-danger"><?php echo e($message); ?></small>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="group-input">
                    <label>OTP Code</label>
                    <input type="text" name="otp" placeholder="Enter OTP">
                    <?php $__errorArgs = ['otp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <small class="text-danger"><?php echo e($message); ?></small>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <button type="submit" class="tf-btn accent large">Reset Password</button>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/awaludinr/Projects/zipayrussia/resources/views/new-password.blade.php ENDPATH**/ ?>