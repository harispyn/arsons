<?php $__env->startSection('title', __('messages.login_title')); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1><?php echo e(__('messages.login_title')); ?></h1>
    <form method="POST" action="<?php echo e(route('login.store')); ?>">
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label for="username"><?php echo e(__('messages.login_username')); ?></label>
            <input type="text" name="username" id="username" class="form-control" required>
        </div>

        <div class="form-group">
            <label for="password"><?php echo e(__('messages.login_password')); ?></label>
            <input type="password" name="password" id="password" class="form-control" required>
        </div>

        <div class="form-group">
            <label for="deviceType"><?php echo e(__('messages.login_device_type')); ?></label>
            <select name="deviceType" id="deviceType" class="form-control" required>
                <option value="android">Android</option>
                <option value="iphone">iPhone</option>
            </select>
        </div>

        <input type="hidden" name="deviceId" value="<?php echo e($deviceId); ?>">

        <p><strong>Device ID:</strong> <?php echo e($deviceId); ?></p>

        <div class="form-group mt-3">
            <button type="submit" class="btn btn-primary"><?php echo e(__('messages.login_button')); ?></button>
        </div>
    </form>

    <p class="mt-3 text-center">
        <a href="<?php echo e(route('reset.password')); ?>" class="auth-link-fp"><?php echo e(__('messages.login_forgot_password')); ?></a>
    </p>

    <p class="mb-9 fw-3 text-center">
        <?php echo e(__('messages.login_no_account')); ?> <a href="<?php echo e(route('register')); ?>" class="auth-link-rg"><?php echo e(__('messages.login_sign_up')); ?></a>
    </p>

    <?php if($errors->any()): ?>
        <div class="alert alert-danger mt-3">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/awaludinr/Projects/zipayrussia/resources/views/login.blade.php ENDPATH**/ ?>