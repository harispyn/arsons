<?php $__env->startSection('title', 'Profile'); ?>

<?php $__env->startSection('content'); ?>
<div class="preload preload-container">
    <div class="preload-logo">
        <div class="spinner"></div>
    </div>
</div>

<div class="header mb-1 is-fixed">
    <div class="tf-container">
        <div class="tf-statusbar d-flex justify-content-center align-items-center">
            <a href="<?php echo e(route('home')); ?>" class="back-btn"> <i class="icon-left"></i> </a>
            <h3>Profile</h3>
        </div>
    </div>
</div>

<div id="app-wrap">
    <a class="box-profile mt-1" href="<?php echo e(route('profile.details')); ?>">
        <div class="inner d-flex align-items-center">
            <div class="box-avatar">
                <img src="<?php echo e(asset('images/user/profile1.jpg')); ?>" alt="image">
                <span class="icon-camera-to-take-photos"></span>
            </div>
            <div class="info">
                <h2 class="fw_8"><?php echo e($user); ?></h2>
                <p><?php echo e($phoneNo); ?><i class="icon-copy1"></i></p>
            </div>
        </div>
        <span><i class="icon-right"></i></span>
    </a>
    <a class="list-profile mt-1" href="<?php echo e(route('profile.qr')); ?>">
        <i class="icon-scan-qr-code"></i>
        <p>QR code to receive money</p>
        <span><i class="icon-right"></i></span>
    </a>

    <ul class="mt-1">
        <li>
            <a href="<?php echo e(route('profile.balance')); ?>" class="list-profile outline">
                <i class="icon-wallet"></i>
                <p>Account Balance</p>
                <span>Rp. <?php echo e(number_format((int) $balance, 0, ',', '.')); ?><i class="icon-right"></i></span>
            </a>
        </li>
        <li>
            <a href="<?php echo e(route('profile.rewards')); ?>" class="list-profile">
                <i class="icon-gift"></i>
                <p>My Gift</p>
                <span>21 Gift<i class="icon-right"></i></span>
            </a>
        </li>
    </ul>

    <ul class="box-settings-profile mt-1 mb-8">
        <li>
            <a href="<?php echo e(route('profile.cards')); ?>" class="list-setting-profile">
                <span class="icon icon-wlet"></span>
                <p>Cards/Bank Accounts</p>
                <i class="icon-right"></i>
            </a>
        </li>
        <li>
            <a href="<?php echo e(route('profile.manage')); ?>" class="list-setting-profile">
                <span class="icon icon-user3"></span>
                <p>Manage Group of Friends</p>
                <i class="icon-right"></i>
            </a>
        </li>
        <li>
            <a href="<?php echo e(route('settings')); ?>" class="list-setting-profile">
                <span class="icon icon-setting1"></span>
                <p>Setting</p>
                <i class="icon-right"></i>
            </a>
        </li>
    </ul>
</div>

<div class="bottom-navigation-bar">
    <div class="tf-container">
        <ul class="tf-navigation-bar">
            <li>
                <a class="fw_4 d-flex justify-content-center align-items-center flex-column" href="<?php echo e(route('home')); ?>">
                    <i class="icon-home"></i> Home
                </a>
            </li>
            <li>
                <a class="fw_4 d-flex justify-content-center align-items-center flex-column" href="<?php echo e(route('transactions.history')); ?>">
                    <i class="icon-history"></i> History
                </a>
            </li>
            <li>
                <a class="fw_4 d-flex justify-content-center align-items-center flex-column" href="<?php echo e(route('profile.qr')); ?>">
                    <i class="icon-scan-qr-code"></i>
                </a>
            </li>
            <li>
                <a class="fw_4 d-flex justify-content-center align-items-center flex-column" href="<?php echo e(route('profile.rewards')); ?>">
                    <i class="icon-rewards"></i> Rewards
                </a>
            </li>
            <li class="active">
                <a class="fw_6 d-flex justify-content-center align-items-center flex-column" href="<?php echo e(route('profile')); ?>">
                    <i class="icon-user-fill"></i> Profile
                </a>
            </li>
        </ul>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/awaludinr/Projects/zipayrussia/resources/views/profile.blade.php ENDPATH**/ ?>