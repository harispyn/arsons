<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\UsersController;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\LoginController;
use App\Http\Controllers\RegisterController;
use App\Http\Controllers\ActivationController;
use App\Http\Middleware\CheckApiToken;
use GuzzleHttp\Client;
use App\Http\Middleware\SetLocale;
use App\Http\Controllers\QRController;


// Rute untuk semua pengguna (akses tanpa login)
Route::get('/', function () {
    return view('welcome');
});
Route::get('/tryscan', function () {
    return view('tryscan');
});


Route::get('/', function () {
    return view('welcome');
});
        // Rute untuk pengguna yang belum login
Route::middleware('guest', SetLocale::class)->group(function () {
    Route::get('/register', [RegisterController::class, 'index'])->name('register');
    Route::post('/register', [RegisterController::class, 'store'])->name('register.store');
    Route::get('/activation/{phoneNo?}', [ActivationController::class, 'index'])->name('activation.index');
    Route::post('/activation', [ActivationController::class, 'activate'])->name('activation.activate');
    Route::get('/verify-otp/{phoneNo}', [ActivationController::class, 'showVerifyForm'])->name('otp.show');
    Route::post('/verify-otp', [ActivationController::class, 'verifyOTP'])->name('otp.verify');
    Route::post('/resend-otp', [ActivationController::class, 'resendOTP'])->name('otp.resend');
    Route::get('/login', [LoginController::class, 'index'])->name('login');
    Route::post('/login', [LoginController::class, 'store'])->name('login.store');
    //Route::get('/reset', [LoginController::class, 'edit'])->name('password.reset');

    Route::view('/profile/details', 'profile-details')->name('profile.details');
    Route::view('/reset-password', 'reset-password')->name('reset.password');
    Route::post('/reset-password', [LoginController::class, 'resetPassword'])->name('password.reset');
    Route::get('/verify-reset', [LoginController::class, 'verifyReset'])->name('password.verifyreset');
    Route::get('/verify-reset', [LoginController::class, 'verifyReset'])->name('password.verifyreset');
    Route::post('/confirm-password', [LoginController::class, 'confirmPassword'])->name('password.confirmpassword');
    Route::get('/confirm-password-view', [LoginController::class, 'confirmPasswordView'])->name('password.confirmview');
});

// Rute untuk pengguna yang sudah login
Route::middleware([CheckApiToken::class], SetLocale::class)->group(function () {
    Route::get('/home', [HomeController::class, 'index'])->name('home');
    Route::get('/logout', [LoginController::class, 'logout'])->name('logout');

    Route::get('/profile', function () {
        $data=Session::get('api_response');
        $client = new Client();
        // Kirim request ke API
        $response = $client->post(config('services.multipocket.base_url') . '/api/Multipocket/Balance', [
            'json' => [
                'mid' => config('services.multipocket.mid'),
                'merchantToken' => config('services.multipocket.merchant_token'),
                'phoneNo' => $data['phoneNumber'],
                'userToken' => $data['token'],
            ],
            'headers' => [
                'Accept' => 'application/json',
                'Content-Type' => 'application/json-patch+json',
            ],
        ]);

        $dataapi = json_decode($response->getBody()->getContents(), true)['result'];
        $balance = $dataapi['zipayPocket']; // Ambil data balance dari database atau API
        return view('profile', ['user' => $data['firstName'] .' '.Session::get('api_response')['lastName']
            ,'balance' => $balance,'phoneNo'=>$data['phoneNumber']]);
    })->name('profile');
    Route::view('/profile/details', 'profile-details')->name('profile.details');
    Route::view('/profile/qr', 'profile-qr')->name('profile.qr');
    Route::view('/profile/balance', 'profile-balance')->name('profile.balance');
    Route::view('/profile/rewards', 'profile-rewards')->name('profile.rewards');
    Route::view('/profile/cards', 'profile-cards')->name('profile.cards');
    Route::view('/profile/manage', 'profile-manage')->name('profile.manage');
    Route::view('/profile/transactions', 'profile-manage')->name('transactions.history');

    Route::view('/settings', 'settings')->name('settings');
    Route::view('/settings/change-password', 'change-password')->name('change_password');
    Route::view('/settings/security-center', 'security-center')->name('security_center');
    Route::view('/settings/notifications', 'notifications')->name('notification_settings');
    Route::view('/settings/language', 'language')->name('language');
    Route::view('/settings/auto-lock', 'auto-lock')->name('auto_lock');

    Route::view('/qr-code', 'qr-code')->name('qr-code');
    Route::view('/scan-qr', 'scan-qr')->name('scan-qr');
    Route::post('/process-qr', [QRController::class, 'process'])->name('process-qr');

});

// Rute untuk admin
Route::middleware('admin', SetLocale::class)->group(function () {
    Route::resource('users', UsersController::class);
});
