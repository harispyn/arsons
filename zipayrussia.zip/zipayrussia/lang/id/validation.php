<?php
return [
    'required' => 'Kolom :attribute wajib diisi.',
    'min' => ':attribute harus terdiri dari minimal :min karakter.',
    'max' => ':attribute tidak boleh lebih dari :max karakter.',
];
