<?php
return [
    'required' => 'The :attribute field is required.',
    'min' => 'The :attribute must be at least :min characters.',
    'max' => 'The :attribute may not be greater than :max characters.',
];
