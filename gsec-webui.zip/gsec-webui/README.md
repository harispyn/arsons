# Gsec Web UI

> **PHP 8.0+ Web Interface for [Gsec Web Security Scanner](https://github.com/gotr00t0day/Gsec)**
> Real-time streaming output via Server-Sent Events (SSE)

![PHP](https://img.shields.io/badge/PHP-8.0%2B-777BB4?logo=php)
![License](https://img.shields.io/badge/License-MIT-green)

---

## ✨ Features

- 🎯 **One-click scanning** — Normal, Passive Recon, Ultimate Scan modes
- ⚡ **Real-time output** — Streams Gsec output live via Server-Sent Events (SSE)
- 🎨 **ANSI → HTML** — Full colorama terminal color support
- 📊 **Live statistics** — Vulnerability, warning, info counters
- 🕘 **Scan history** — Browse and reload previous scans
- ⬇️ **Log download** — Export raw scan logs
- 🔍 **Terminal search** — Filter output with `Ctrl+F`
- ⏹ **Stop scan** — Kill running scans instantly
- 🌑 **Dark hacker theme** — Dracula-inspired terminal UI

---

## 📋 Requirements

| Requirement | Version |
|---|---|
| PHP | **8.0+** |
| Python | 3.8+ |
| Gsec | [github.com/gotr00t0day/Gsec](https://github.com/gotr00t0day/Gsec) |
| Web Server | Apache 2.4+ / Nginx |
| PHP Functions | `shell_exec`, `proc_open` enabled |

---

## 🚀 Installation

### 1. Clone both repos

```bash
# Clone Gsec
git clone https://github.com/gotr00t0day/Gsec.git /opt/Gsec
cd /opt/Gsec && pip3 install -r requirements.txt && python3 install.py

# Clone this Web UI
git clone <this-repo> /var/www/html/gsec-webui
```

### 2. Configure paths

Edit `config.php`:

```php
define('GSEC_ROOT',   '/opt/Gsec');           // Path to Gsec directory
define('GSEC_SCRIPT', GSEC_ROOT . '/gsec.py');
define('PYTHON_BIN',  '/usr/bin/python3');
define('NUCLEI_BIN',  '/usr/local/bin/nuclei');
```

### 3. Set permissions

```bash
chmod 755 /var/www/html/gsec-webui
chmod -R 755 /var/www/html/gsec-webui/storage
chown -R www-data:www-data /var/www/html/gsec-webui/storage
```

### 4. Apache / Nginx

**Apache** — uses included `.htaccess` (requires `mod_rewrite`, `AllowOverride All`)

**Nginx** — see `nginx.conf.example`

### 5. PHP configuration (`php.ini`)

```ini
output_buffering = Off        ; Required for SSE streaming
max_execution_time = 0        ; Allow long-running scans
disable_functions =           ; Ensure shell_exec is NOT disabled
```

### 6. Run setup checker

```bash
php install.php
```

### 7. Open in browser

```
http://localhost/gsec-webui/
```

---

## 📁 File Structure

```
gsec-webui/
├── index.php              ← Main Web UI dashboard
├── config.php             ← Configuration (paths, limits)
├── ScanManager.php        ← Scan process management class
├── install.php            ← Setup & requirements checker
├── .htaccess              ← Apache security rules
├── nginx.conf.example     ← Nginx config snippet
├── api/
│   ├── start_scan.php     ← POST: start new scan
│   ├── stop_scan.php      ← POST: stop running scan
│   ├── stream.php         ← GET: SSE real-time stream
│   ├── status.php         ← GET: scan status / list
│   ├── get_log.php        ← GET: fetch log (text/download)
│   └── delete_scan.php    ← POST/DELETE: remove scan
└── storage/               ← Auto-created
    ├── scans/             ← Scan metadata (.json, .pid)
    └── logs/              ← Raw output logs (.log)
```

---

## 🔒 Security Notes

> **This tool is for authorized penetration testing only.**
> Only deploy on trusted networks. Never expose to the public internet without authentication.

- Add HTTP Basic Auth via Apache/Nginx for access control
- Restrict `ALLOWED_IPS` in `config.php` to whitelist specific IPs
- The storage directory is protected from direct web access via `.htaccess`
- All scan IDs are validated with regex before use
- Targets are validated as URLs before scanning

---

## 🖥️ Usage

1. Enter target URL (e.g., `https://example.com`)
2. Select scan type:
   - **Normal** — Full scan (aggressive + passive)
   - **Passive** — OSINT/recon only (DNS, subdomains, Shodan)
   - **Ultimate** — Nuclei high/critical CVE scan
3. Click **Start Scan**
4. Watch real-time output in the terminal panel
5. Download log or view history after completion

---

## 📜 License

MIT — see [Gsec License](https://github.com/gotr00t0day/Gsec)

---

*Built with ❤️ for security researchers*
