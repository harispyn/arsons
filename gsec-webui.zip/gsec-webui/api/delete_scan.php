<?php
// ============================================================
// Gsec Web UI - Delete Scan API
// PHP 8.0+
// ============================================================

declare(strict_types=1);

require_once dirname(__DIR__) . '/config.php';
require_once dirname(__DIR__) . '/ScanManager.php';

header('Content-Type: application/json; charset=UTF-8');

if ($_SERVER['REQUEST_METHOD'] !== 'DELETE' && $_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method not allowed']);
    exit;
}

$body   = json_decode(file_get_contents('php://input'), true);
$scanId = $body['scan_id'] ?? $_POST['scan_id'] ?? $_GET['scan_id'] ?? '';

if (!preg_match('/^scan_[a-zA-Z0-9._]+$/', $scanId)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Invalid scan ID']);
    exit;
}

// Stop first if running
if (ScanManager::isRunning($scanId)) {
    ScanManager::stopScan($scanId);
}

$result = ScanManager::deleteScan($scanId);
echo json_encode(['success' => $result, 'message' => $result ? 'Scan deleted' : 'Failed']);
