<?php
// ============================================================
// Gsec Web UI - Get Scan Log (full or partial)
// PHP 8.0+
// ============================================================

declare(strict_types=1);

require_once dirname(__DIR__) . '/config.php';
require_once dirname(__DIR__) . '/ScanManager.php';

$scanId = $_GET['scan_id'] ?? '';
$format = $_GET['format'] ?? 'text'; // text | download

if (!preg_match('/^scan_[a-zA-Z0-9._]+$/', $scanId)) {
    http_response_code(400);
    echo 'Invalid scan ID';
    exit;
}

$logFile = ScanManager::getLogFile($scanId);
$meta    = ScanManager::getScanMeta($scanId);

if (!$logFile || !$meta) {
    http_response_code(404);
    echo 'Log not found';
    exit;
}

if ($format === 'download') {
    $filename = "gsec_scan_{$meta['target']}_{$meta['started_at']}.log";
    $filename = preg_replace('/[^a-zA-Z0-9_\-.]/', '_', $filename);
    header('Content-Type: application/octet-stream');
    header("Content-Disposition: attachment; filename=\"{$filename}\"");
    header('Content-Length: ' . filesize($logFile));
    readfile($logFile);
    exit;
}

// Return as JSON lines
header('Content-Type: application/json; charset=UTF-8');
$lines = file($logFile, FILE_IGNORE_NEW_LINES) ?: [];
echo json_encode(['success' => true, 'lines' => $lines, 'count' => count($lines), 'meta' => $meta]);
