<?php
// ============================================================
// Gsec Web UI - SSE Stream Endpoint
// PHP 8.0+  — streams scan log in real-time via Server-Sent Events
// ============================================================

declare(strict_types=1);

require_once dirname(__DIR__) . '/config.php';
require_once dirname(__DIR__) . '/ScanManager.php';

// ─── Security ───────────────────────────────────────────────
if (!empty(ALLOWED_IPS) && !in_array($_SERVER['REMOTE_ADDR'] ?? '', ALLOWED_IPS, true)) {
    http_response_code(403);
    exit('Access denied');
}

$scanId = $_GET['scan_id'] ?? '';
if (!preg_match('/^scan_[a-zA-Z0-9._]+$/', $scanId)) {
    http_response_code(400);
    exit('Invalid scan ID');
}

// ─── SSE Headers ────────────────────────────────────────────
header('Content-Type: text/event-stream; charset=UTF-8');
header('Cache-Control: no-cache, no-store');
header('X-Accel-Buffering: no');   // disable nginx buffering
header('Connection: keep-alive');
header('Access-Control-Allow-Origin: *');

// Disable PHP output buffering
while (ob_get_level()) ob_end_clean();

// Helper: send SSE event
function sseEvent(string $event, mixed $data, ?int $id = null): void
{
    if ($id !== null) echo "id: $id\n";
    echo "event: $data\n" ? '' : '';        // trick to flush
    echo "event: $event\n";
    echo "data: " . json_encode($data) . "\n\n";
    flush();
}

// ANSI escape → HTML span converter
function ansiToHtml(string $text): string
{
    // Remove Windows carriage returns
    $text = str_replace("\r", '', $text);

    $ansiColors = [
        '30' => '#1e1e1e', '31' => '#ff5555', '32' => '#50fa7b',
        '33' => '#f1fa8c', '34' => '#6272a4', '35' => '#ff79c6',
        '36' => '#8be9fd', '37' => '#f8f8f2', '90' => '#6272a4',
        '91' => '#ff6e6e', '92' => '#69ff47', '93' => '#ffffa5',
        '94' => '#d6acff', '95' => '#ff92df', '96' => '#a4ffff',
        '97' => '#ffffff',
    ];

    // Strip SGR sequences we handle + any others we don't
    $html = preg_replace_callback(
        '/\x1b\[([0-9;]*)m/',
        function ($m) use ($ansiColors): string {
            $codes = explode(';', $m[1]);
            $spans = '';
            foreach ($codes as $code) {
                $code = ltrim($code, '0') ?: '0';
                if ($code === '0' || $code === '') return '</span><span>';
                if (isset($ansiColors[$code])) {
                    $color = $ansiColors[$code];
                    return "<span style=\"color:{$color}\">";
                }
                if ($code === '1') return '<span style="font-weight:bold">';
            }
            return $spans;
        },
        $text
    );

    // Strip any remaining escape sequences
    $html = preg_replace('/\x1b\[[0-9;]*[a-zA-Z]/', '', $html ?? $text);
    $html = preg_replace('/\x1b[^[]*\[/', '', $html ?? $text);

    return htmlspecialchars_decode(
        str_replace('&amp;', '&', htmlspecialchars($html ?? $text, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'))
    );
}

// ─── Wait for log file ──────────────────────────────────────
$logFile = LOG_DIR . "/{$scanId}.log";
$meta    = ScanManager::getScanMeta($scanId);

if (!$meta) {
    sseEvent('error', ['message' => 'Scan not found']);
    sseEvent('done', ['status' => 'error']);
    exit;
}

// Send initial metadata event
sseEvent('meta', [
    'scan_id' => $scanId,
    'target'  => $meta['target'],
    'type'    => $meta['type'],
    'started' => $meta['started_at'],
]);

// Wait up to 5s for log file to appear
$waited = 0;
while (!file_exists($logFile) && $waited < 50) {
    usleep(100_000); // 0.1s
    $waited++;
}

if (!file_exists($logFile)) {
    sseEvent('error', ['message' => 'Log file not found after 5s']);
    sseEvent('done', ['status' => 'error']);
    exit;
}

// ─── Stream log ─────────────────────────────────────────────
$fp = fopen($logFile, 'r');
if (!$fp) {
    sseEvent('error', ['message' => 'Cannot open log file']);
    sseEvent('done', ['status' => 'error']);
    exit;
}

$lineId     = 0;
$lastCheck  = time();
$maxIdle    = 300; // 5 min idle timeout

// Statistics counters
$stats = [
    'vulns'    => 0,
    'warnings' => 0,
    'info'     => 0,
];

set_time_limit(0);
ignore_user_abort(true);

while (true) {
    // Check client disconnect
    if (connection_aborted()) break;

    $line = fgets($fp);

    if ($line === false) {
        // No new data — check if process still running
        clearstatcache(true, $logFile);
        $isRunning = ScanManager::isRunning($scanId);

        if (!$isRunning) {
            // Process finished
            // Drain any remaining lines
            while (($line = fgets($fp)) !== false) {
                $lineId++;
                $clean = ansiToHtml(rtrim($line, "\n"));
                sseEvent('line', ['id' => $lineId, 'html' => $clean, 'raw' => rtrim($line, "\n")], $lineId);
                updateStats($stats, $line);
            }
            ScanManager::updateMeta($scanId, ['status' => 'completed', 'ended_at' => date('c'), 'stats' => $stats]);
            sseEvent('done', ['status' => 'completed', 'stats' => $stats]);
            break;
        }

        // Idle timeout
        if ((time() - $lastCheck) > $maxIdle) {
            sseEvent('done', ['status' => 'timeout']);
            break;
        }

        // Send heartbeat every 15s
        if ((time() - $lastCheck) % 15 === 0) {
            echo ": heartbeat\n\n";
            flush();
        }

        usleep(150_000); // wait 0.15s before retry
        continue;
    }

    $lastCheck = time();
    $lineId++;
    $clean = ansiToHtml(rtrim($line, "\n"));
    updateStats($stats, $line);
    sseEvent('line', ['id' => $lineId, 'html' => $clean, 'raw' => rtrim($line, "\n")], $lineId);
}

fclose($fp);

// ─── Helper ─────────────────────────────────────────────────
function updateStats(array &$stats, string $line): void
{
    $lower = strtolower($line);
    if (preg_match('/(critical|high|severe|vuln|exploit|found|inject|rce|sqli|xss|lfi|rfi|ssrf|idor|bola)/i', $lower)) {
        $stats['vulns']++;
    } elseif (preg_match('/(warn|possible|medium|misconfigur)/i', $lower)) {
        $stats['warnings']++;
    } elseif (preg_match('/(\[info\]|\[i\]|\[\+\]|info:)/i', $lower)) {
        $stats['info']++;
    }
}
