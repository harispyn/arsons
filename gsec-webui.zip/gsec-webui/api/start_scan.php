<?php
// ============================================================
// Gsec Web UI - Start Scan API
// PHP 8.0+
// ============================================================

declare(strict_types=1);

require_once dirname(__DIR__) . '/config.php';
require_once dirname(__DIR__) . '/ScanManager.php';

header('Content-Type: application/json; charset=UTF-8');
header('X-Content-Type-Options: nosniff');

// Only POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method not allowed']);
    exit;
}

// Security
if (!empty(ALLOWED_IPS) && !in_array($_SERVER['REMOTE_ADDR'] ?? '', ALLOWED_IPS, true)) {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Access denied']);
    exit;
}

// Parse JSON body or form data
$body = json_decode(file_get_contents('php://input'), true);
$target   = trim($body['target']   ?? $_POST['target']   ?? '');
$scanType = trim($body['scan_type'] ?? $_POST['scan_type'] ?? 'normal');

// Validate target
if (empty($target)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Target is required']);
    exit;
}

// Basic URL validation
if (!filter_var($target, FILTER_VALIDATE_URL)) {
    // Try adding https:// prefix
    if (filter_var('https://' . $target, FILTER_VALIDATE_URL)) {
        $target = 'https://' . $target;
    } else {
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => 'Invalid target URL']);
        exit;
    }
}

// Validate scan type
$allowedTypes = ['normal', 'passive', 'ultimate'];
if (!in_array($scanType, $allowedTypes, true)) {
    $scanType = 'normal';
}

// Check concurrent scans limit
if (ScanManager::countActiveScans() >= MAX_CONCURRENT_SCANS) {
    http_response_code(429);
    echo json_encode(['success' => false, 'message' => "Max concurrent scans ({" . MAX_CONCURRENT_SCANS . "}) reached"]);
    exit;
}

// Check Gsec script exists
if (!file_exists(GSEC_SCRIPT)) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Gsec script not found at: ' . GSEC_SCRIPT]);
    exit;
}

try {
    $meta = ScanManager::startScan($target, $scanType);
    echo json_encode([
        'success' => true,
        'scan_id' => $meta['id'],
        'target'  => $meta['target'],
        'type'    => $meta['type'],
        'pid'     => $meta['pid'],
        'message' => 'Scan started successfully',
    ]);
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Failed to start scan: ' . $e->getMessage()]);
}
