<?php
// ============================================================
// Gsec Web UI - Scan Status API
// PHP 8.0+
// ============================================================

declare(strict_types=1);

require_once dirname(__DIR__) . '/config.php';
require_once dirname(__DIR__) . '/ScanManager.php';

header('Content-Type: application/json; charset=UTF-8');
header('Cache-Control: no-cache');

$scanId = $_GET['scan_id'] ?? '';

if ($scanId) {
    if (!preg_match('/^scan_[a-zA-Z0-9._]+$/', $scanId)) {
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => 'Invalid scan ID']);
        exit;
    }
    $meta = ScanManager::getScanMeta($scanId);
    if (!$meta) {
        http_response_code(404);
        echo json_encode(['success' => false, 'message' => 'Scan not found']);
        exit;
    }
    // Auto-update status
    if ($meta['status'] === 'running' && !ScanManager::isRunning($scanId)) {
        ScanManager::updateMeta($scanId, ['status' => 'completed', 'ended_at' => date('c')]);
        $meta['status'] = 'completed';
    }
    echo json_encode(['success' => true, 'scan' => $meta]);
} else {
    // List all scans
    $scans = ScanManager::getAllScans(50);
    echo json_encode(['success' => true, 'scans' => $scans, 'total' => count($scans)]);
}
