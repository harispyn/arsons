<?php
// ============================================================
// Gsec Web UI - Main Dashboard (index.php)
// PHP 8.0+
// ============================================================

declare(strict_types=1);
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/ScanManager.php';

$scans        = ScanManager::getAllScans(20);
$activeScans  = array_filter($scans, fn($s) => $s['status'] === 'running');
$totalScans   = count($scans);
$gsecExists   = file_exists(GSEC_SCRIPT);
$pythonExists = !empty(shell_exec(PYTHON_BIN . ' --version 2>&1'));
?>
<!DOCTYPE html>
<html lang="en" data-theme="dark">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Gsec Web UI – Web Security Scanner</title>
<meta name="description" content="Gsec Web Security Scanner – PHP Web Interface with realtime output">
<link rel="icon" href="data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'><text y='.9em' font-size='90'>🔒</text></svg>">
<style>
/* ============================================================
   GSEC WEB UI — CSS (Dark Hacker Theme)
   ============================================================ */

:root {
  --bg-primary:    #0d1117;
  --bg-secondary:  #161b22;
  --bg-tertiary:   #21262d;
  --bg-card:       #1c2128;
  --border:        #30363d;
  --border-light:  #3d444d;
  --text-primary:  #e6edf3;
  --text-secondary:#8b949e;
  --text-muted:    #6e7681;
  --accent:        #58a6ff;
  --accent-hover:  #79c0ff;
  --green:         #3fb950;
  --green-dark:    #238636;
  --red:           #f85149;
  --yellow:        #d29922;
  --purple:        #bc8cff;
  --cyan:          #39d353;
  --orange:        #e3b341;
  --magenta:       #ff7b72;

  /* Terminal colors (Dracula-ish) */
  --term-bg:       #0a0d12;
  --term-text:     #f8f8f2;
  --term-green:    #50fa7b;
  --term-yellow:   #f1fa8c;
  --term-red:      #ff5555;
  --term-cyan:     #8be9fd;
  --term-magenta:  #ff79c6;
  --term-purple:   #bd93f9;
  --term-comment:  #6272a4;

  --radius:        8px;
  --radius-lg:     12px;
  --shadow:        0 4px 24px rgba(0,0,0,.4);
  --transition:    0.2s ease;
  --font-mono:     'JetBrains Mono', 'Fira Code', 'Cascadia Code', Consolas, monospace;
  --font-sans:     'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
}

*, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

html { font-size: 15px; scroll-behavior: smooth; }

body {
  background: var(--bg-primary);
  color: var(--text-primary);
  font-family: var(--font-sans);
  line-height: 1.6;
  min-height: 100vh;
}

/* ─── Scrollbar ─── */
::-webkit-scrollbar { width: 8px; height: 8px; }
::-webkit-scrollbar-track { background: var(--bg-primary); }
::-webkit-scrollbar-thumb { background: var(--border-light); border-radius: 4px; }
::-webkit-scrollbar-thumb:hover { background: var(--text-muted); }

/* ─── Header ─── */
.header {
  position: sticky; top: 0; z-index: 100;
  background: rgba(13, 17, 23, 0.95);
  backdrop-filter: blur(12px);
  border-bottom: 1px solid var(--border);
  padding: 0 2rem;
  display: flex; align-items: center; justify-content: space-between;
  height: 60px;
}

.logo {
  display: flex; align-items: center; gap: .6rem;
  font-family: var(--font-mono);
  font-size: 1.1rem; font-weight: 700;
  color: var(--term-green);
  text-decoration: none;
  letter-spacing: -0.02em;
}
.logo-icon { font-size: 1.4rem; }
.logo-version {
  font-size: .65rem; color: var(--text-muted);
  background: var(--bg-tertiary);
  padding: 1px 6px; border-radius: 4px; margin-left: 4px;
}

.header-nav { display: flex; align-items: center; gap: .5rem; }
.nav-btn {
  display: flex; align-items: center; gap: .4rem;
  padding: .4rem .8rem; border-radius: var(--radius);
  font-size: .82rem; color: var(--text-secondary);
  background: transparent; border: 1px solid transparent;
  cursor: pointer; transition: var(--transition); text-decoration: none;
}
.nav-btn:hover { background: var(--bg-tertiary); color: var(--text-primary); border-color: var(--border); }
.nav-btn.active { background: var(--bg-tertiary); color: var(--accent); border-color: var(--border); }

.status-indicator {
  display: flex; align-items: center; gap: .4rem;
  font-size: .75rem; color: var(--text-secondary);
  padding: .3rem .7rem;
  background: var(--bg-tertiary); border: 1px solid var(--border);
  border-radius: 20px;
}
.status-dot {
  width: 7px; height: 7px; border-radius: 50%;
  background: var(--red);
  animation: none;
}
.status-dot.online { background: var(--green); animation: pulse 2s infinite; }
@keyframes pulse {
  0%,100% { opacity: 1; } 50% { opacity: .4; }
}

/* ─── Layout ─── */
.app-layout {
  display: grid;
  grid-template-columns: 300px 1fr;
  grid-template-rows: 1fr;
  height: calc(100vh - 60px);
  overflow: hidden;
}

/* ─── Sidebar ─── */
.sidebar {
  background: var(--bg-secondary);
  border-right: 1px solid var(--border);
  display: flex; flex-direction: column;
  overflow-y: auto; overflow-x: hidden;
}

.sidebar-section { padding: 1rem; border-bottom: 1px solid var(--border); }
.sidebar-title {
  font-size: .7rem; font-weight: 600; letter-spacing: .08em;
  text-transform: uppercase; color: var(--text-muted);
  margin-bottom: .75rem;
}

/* ─── Scan Form ─── */
.form-group { margin-bottom: .75rem; }
.form-label {
  display: block; font-size: .78rem; color: var(--text-secondary);
  margin-bottom: .3rem; font-weight: 500;
}
.form-input {
  width: 100%; padding: .5rem .75rem;
  background: var(--bg-tertiary);
  border: 1px solid var(--border);
  border-radius: var(--radius);
  color: var(--text-primary);
  font-family: var(--font-mono); font-size: .82rem;
  transition: var(--transition); outline: none;
}
.form-input:focus { border-color: var(--accent); box-shadow: 0 0 0 3px rgba(88,166,255,.15); }
.form-input::placeholder { color: var(--text-muted); }

.scan-type-grid { display: grid; grid-template-columns: 1fr 1fr 1fr; gap: .4rem; }
.scan-type-btn {
  padding: .45rem .3rem; border-radius: var(--radius);
  background: var(--bg-tertiary); border: 1px solid var(--border);
  color: var(--text-secondary); font-size: .72rem; font-weight: 500;
  cursor: pointer; transition: var(--transition); text-align: center;
  display: flex; flex-direction: column; align-items: center; gap: .2rem;
}
.scan-type-btn:hover { border-color: var(--accent); color: var(--accent); }
.scan-type-btn.selected { background: rgba(88,166,255,.12); border-color: var(--accent); color: var(--accent); }
.scan-type-btn .icon { font-size: 1.1rem; }

.btn-start {
  width: 100%; padding: .6rem;
  background: var(--green-dark); border: 1px solid var(--green);
  border-radius: var(--radius); color: #fff;
  font-size: .85rem; font-weight: 600; letter-spacing: .02em;
  cursor: pointer; transition: var(--transition);
  display: flex; align-items: center; justify-content: center; gap: .4rem;
}
.btn-start:hover { background: #2ea043; }
.btn-start:disabled {
  background: var(--bg-tertiary); border-color: var(--border);
  color: var(--text-muted); cursor: not-allowed;
}
.btn-start.scanning { background: rgba(248,81,73,.15); border-color: var(--red); }

/* ─── Scan History ─── */
.scan-history-list { display: flex; flex-direction: column; gap: .4rem; }
.scan-item {
  padding: .55rem .65rem; border-radius: var(--radius);
  background: var(--bg-tertiary); border: 1px solid var(--border);
  cursor: pointer; transition: var(--transition);
  display: flex; flex-direction: column; gap: .2rem;
  position: relative;
}
.scan-item:hover { border-color: var(--border-light); background: var(--bg-card); }
.scan-item.active { border-color: var(--accent); background: rgba(88,166,255,.06); }
.scan-item-target {
  font-family: var(--font-mono); font-size: .75rem;
  color: var(--text-primary); white-space: nowrap;
  overflow: hidden; text-overflow: ellipsis; max-width: 200px;
}
.scan-item-meta { display: flex; align-items: center; gap: .4rem; font-size: .68rem; }
.badge {
  padding: 1px 6px; border-radius: 3px; font-size: .68rem; font-weight: 600;
  text-transform: uppercase; letter-spacing: .04em;
}
.badge-running { background: rgba(88,166,255,.2); color: var(--accent); }
.badge-completed { background: rgba(63,185,80,.2); color: var(--green); }
.badge-stopped { background: rgba(248,81,73,.2); color: var(--red); }
.badge-error { background: rgba(248,81,73,.2); color: var(--red); }
.badge-normal { background: rgba(139,148,158,.15); color: var(--text-secondary); }
.badge-passive { background: rgba(188,140,255,.2); color: var(--purple); }
.badge-ultimate { background: rgba(227,179,65,.2); color: var(--orange); }

.scan-item-del {
  position: absolute; top: 4px; right: 4px;
  background: none; border: none; color: var(--text-muted);
  cursor: pointer; font-size: .8rem; padding: 2px 4px;
  border-radius: 3px; opacity: 0; transition: var(--transition);
}
.scan-item:hover .scan-item-del { opacity: 1; }
.scan-item-del:hover { background: rgba(248,81,73,.15); color: var(--red); }

/* ─── Main Content ─── */
.main-content {
  display: flex; flex-direction: column;
  overflow: hidden; background: var(--bg-primary);
}

/* ─── Stats Bar ─── */
.stats-bar {
  display: flex; align-items: center; gap: 1px;
  padding: .6rem 1.2rem; border-bottom: 1px solid var(--border);
  background: var(--bg-secondary); flex-shrink: 0;
  overflow-x: auto;
}
.stat-item {
  display: flex; align-items: center; gap: .4rem;
  padding: .25rem .7rem; border-radius: var(--radius);
  font-size: .78rem; white-space: nowrap; flex-shrink: 0;
}
.stat-item .stat-label { color: var(--text-muted); }
.stat-item .stat-value { font-weight: 700; font-family: var(--font-mono); }
.stat-item.vulns .stat-value { color: var(--red); }
.stat-item.warnings .stat-value { color: var(--yellow); }
.stat-item.info .stat-value { color: var(--accent); }
.stat-item.lines .stat-value { color: var(--text-primary); }
.stat-divider { width: 1px; height: 24px; background: var(--border); margin: 0 .3rem; flex-shrink: 0; }

.toolbar {
  display: flex; align-items: center; gap: .5rem;
  padding: .5rem 1rem; border-bottom: 1px solid var(--border);
  background: var(--bg-secondary); flex-shrink: 0; flex-wrap: wrap;
}
.toolbar-left { display: flex; align-items: center; gap: .5rem; flex: 1; }
.toolbar-right { display: flex; align-items: center; gap: .5rem; }

.scan-info-bar {
  display: flex; align-items: center; gap: .6rem;
  font-size: .78rem; color: var(--text-secondary);
  flex: 1; overflow: hidden;
}
.scan-info-target {
  font-family: var(--font-mono); color: var(--accent);
  font-weight: 600;
  white-space: nowrap; overflow: hidden; text-overflow: ellipsis; max-width: 300px;
}
.scan-progress-text { color: var(--text-muted); font-size: .72rem; }

.btn-tool {
  display: flex; align-items: center; gap: .3rem;
  padding: .3rem .65rem; border-radius: var(--radius);
  background: var(--bg-tertiary); border: 1px solid var(--border);
  color: var(--text-secondary); font-size: .78rem; cursor: pointer;
  transition: var(--transition); white-space: nowrap;
}
.btn-tool:hover { background: var(--bg-card); color: var(--text-primary); border-color: var(--border-light); }
.btn-tool.danger:hover { background: rgba(248,81,73,.1); color: var(--red); border-color: var(--red); }
.btn-tool.success { background: rgba(63,185,80,.1); color: var(--green); border-color: var(--green-dark); }

/* ─── Terminal ─── */
.terminal-wrapper { flex: 1; overflow: hidden; position: relative; }
.terminal {
  height: 100%; overflow-y: auto; overflow-x: hidden;
  background: var(--term-bg);
  padding: 1rem 1.2rem;
  font-family: var(--font-mono); font-size: .82rem; line-height: 1.65;
  color: var(--term-text);
  word-break: break-word;
}

/* Welcome screen */
.terminal-welcome {
  display: flex; flex-direction: column;
  align-items: center; justify-content: center;
  height: 100%; gap: 1rem; opacity: .5;
}
.terminal-welcome pre {
  color: var(--term-green); font-size: .75rem; line-height: 1.4;
  text-align: center;
}
.terminal-welcome p { color: var(--text-muted); font-size: .85rem; }

/* Terminal lines */
.term-line { display: block; }
.term-line-num {
  color: var(--term-comment); user-select: none;
  margin-right: .8rem; min-width: 3ch; display: inline-block; text-align: right;
}

/* ANSI Colors */
.a31 { color: var(--term-red); }
.a32 { color: var(--term-green); }
.a33 { color: var(--term-yellow); }
.a34 { color: #6272a4; }
.a35 { color: var(--term-magenta); }
.a36 { color: var(--term-cyan); }
.a37 { color: var(--term-text); }
.a91 { color: #ff6e6e; }
.a92 { color: #69ff47; }
.a93 { color: #ffffa5; }
.a94 { color: var(--term-purple); }
.a95 { color: #ff92df; }
.a96 { color: #a4ffff; }
.a97 { color: #fff; }
.abold { font-weight: bold; }

/* Highlight lines */
.line-vuln { background: rgba(248,81,73,.07); border-left: 2px solid var(--red); padding-left: .5rem; }
.line-warning { background: rgba(210,153,34,.07); border-left: 2px solid var(--yellow); padding-left: .5rem; }
.line-info { background: rgba(88,166,255,.04); border-left: 2px solid var(--accent); padding-left: .5rem; }
.line-success { background: rgba(63,185,80,.04); border-left: 2px solid var(--green); padding-left: .5rem; }
.line-section { color: var(--term-cyan); font-weight: 700; }

/* Cursor blink */
.cursor {
  display: inline-block; width: 8px; height: 14px;
  background: var(--term-green); animation: blink 1s step-end infinite;
  vertical-align: text-bottom; margin-left: 2px;
}
@keyframes blink { 0%,100% { opacity: 1; } 50% { opacity: 0; } }

/* ─── Search overlay ─── */
.search-bar {
  display: none; align-items: center; gap: .5rem;
  padding: .4rem 1rem; border-bottom: 1px solid var(--border);
  background: var(--bg-tertiary);
}
.search-bar.visible { display: flex; }
.search-input {
  flex: 1; background: var(--bg-card); border: 1px solid var(--border);
  border-radius: var(--radius); color: var(--text-primary);
  padding: .35rem .7rem; font-size: .82rem; font-family: var(--font-mono); outline: none;
}
.search-input:focus { border-color: var(--accent); }
.search-count { font-size: .75rem; color: var(--text-muted); white-space: nowrap; }

/* ─── Toast Notifications ─── */
.toast-container {
  position: fixed; bottom: 1.5rem; right: 1.5rem;
  z-index: 9999; display: flex; flex-direction: column; gap: .5rem;
}
.toast {
  padding: .65rem 1rem; border-radius: var(--radius);
  background: var(--bg-tertiary); border: 1px solid var(--border);
  color: var(--text-primary); font-size: .82rem;
  box-shadow: var(--shadow);
  display: flex; align-items: center; gap: .5rem;
  max-width: 350px;
  animation: slideIn .25s ease;
}
.toast.success { border-color: var(--green); background: rgba(63,185,80,.1); }
.toast.error   { border-color: var(--red);   background: rgba(248,81,73,.1); }
.toast.info    { border-color: var(--accent); background: rgba(88,166,255,.1); }
@keyframes slideIn { from { transform: translateX(30px); opacity: 0; } to { transform: none; opacity: 1; } }

/* ─── Loading Spinner ─── */
.spinner {
  width: 14px; height: 14px;
  border: 2px solid var(--border); border-top-color: var(--accent);
  border-radius: 50%; animation: spin .6s linear infinite;
  flex-shrink: 0;
}
@keyframes spin { to { transform: rotate(360deg); } }

/* ─── Empty State ─── */
.empty-state {
  display: flex; flex-direction: column; align-items: center;
  padding: 1.5rem 1rem; gap: .5rem; text-align: center;
}
.empty-state-icon { font-size: 2rem; opacity: .4; }
.empty-state-text { font-size: .78rem; color: var(--text-muted); }

/* ─── Modal ─── */
.modal-overlay {
  display: none; position: fixed; inset: 0; z-index: 1000;
  background: rgba(0,0,0,.7); backdrop-filter: blur(4px);
  align-items: center; justify-content: center;
}
.modal-overlay.open { display: flex; }
.modal {
  background: var(--bg-secondary); border: 1px solid var(--border);
  border-radius: var(--radius-lg); box-shadow: var(--shadow);
  padding: 1.5rem; max-width: 480px; width: 90%;
}
.modal-title { font-size: 1rem; font-weight: 600; margin-bottom: 1rem; }
.modal-footer { display: flex; gap: .5rem; justify-content: flex-end; margin-top: 1rem; }
.modal p { font-size: .85rem; color: var(--text-secondary); line-height: 1.6; }

/* ─── System Check ─── */
.syscheck { display: flex; flex-direction: column; gap: .4rem; }
.syscheck-item {
  display: flex; align-items: center; gap: .5rem;
  font-size: .78rem; padding: .35rem .5rem;
  border-radius: var(--radius); background: var(--bg-tertiary);
  border: 1px solid var(--border);
}
.syscheck-item .icon { font-size: .9rem; }
.syscheck-ok { color: var(--green); }
.syscheck-err { color: var(--red); }
.syscheck-text { flex: 1; color: var(--text-secondary); }

/* ─── Responsive ─── */
@media (max-width: 900px) {
  .app-layout { grid-template-columns: 1fr; }
  .sidebar { display: none; }
  .sidebar.open { display: flex; position: fixed; inset: 60px 0 0 0; z-index: 50; width: 300px; }
}

/* ─── Misc ─── */
.flex { display: flex; }
.gap-1 { gap: .4rem; }
.items-center { align-items: center; }
.text-muted { color: var(--text-muted); font-size: .78rem; }
.font-mono { font-family: var(--font-mono); }
hr.divider { border: none; border-top: 1px solid var(--border); margin: .75rem 0; }

/* Scrollbar for terminal */
.terminal::-webkit-scrollbar { width: 6px; }
.terminal::-webkit-scrollbar-track { background: transparent; }
.terminal::-webkit-scrollbar-thumb { background: #2d333b; border-radius: 3px; }
</style>
</head>
<body>

<!-- ═══════════════════════════════════════════════════════
     HEADER
═══════════════════════════════════════════════════════ -->
<header class="header">
  <a class="logo" href="/">
    <span class="logo-icon">🔒</span>
    <span>Gsec</span>
    <span class="logo-version">v3.8</span>
    <span style="color:var(--text-muted); font-weight:400; font-size:.8rem"> Web UI</span>
  </a>
  <nav class="header-nav">
    <button class="nav-btn active" id="btnDashboard" onclick="showView('dashboard')">📊 Dashboard</button>
    <button class="nav-btn" id="btnHistory" onclick="showView('history')">🕘 History</button>
    <button class="nav-btn" id="btnSettings" onclick="showModal('settingsModal')">⚙️ Settings</button>
    <div class="status-indicator" id="sysStatus">
      <span class="status-dot <?= $gsecExists && $pythonExists ? 'online' : '' ?>" id="sysStatusDot"></span>
      <span id="sysStatusText"><?= $gsecExists && $pythonExists ? 'Ready' : 'Setup required' ?></span>
    </div>
  </nav>
</header>

<!-- ═══════════════════════════════════════════════════════
     MAIN LAYOUT
═══════════════════════════════════════════════════════ -->
<div class="app-layout">

  <!-- ─── SIDEBAR ─── -->
  <aside class="sidebar" id="sidebar">

    <!-- New Scan Form -->
    <div class="sidebar-section">
      <p class="sidebar-title">🎯 New Scan</p>
      <form id="scanForm" onsubmit="return false;">
        <div class="form-group">
          <label class="form-label" for="targetInput">Target URL</label>
          <input
            type="text" id="targetInput" class="form-input"
            placeholder="https://example.com"
            autocomplete="off" spellcheck="false"
            required
          >
        </div>

        <div class="form-group">
          <label class="form-label">Scan Type</label>
          <div class="scan-type-grid">
            <button type="button" class="scan-type-btn selected" data-type="normal" onclick="selectScanType(this)">
              <span class="icon">🔍</span>
              <span>Normal</span>
            </button>
            <button type="button" class="scan-type-btn" data-type="passive" onclick="selectScanType(this)">
              <span class="icon">👁️</span>
              <span>Passive</span>
            </button>
            <button type="button" class="scan-type-btn" data-type="ultimate" onclick="selectScanType(this)">
              <span class="icon">⚡</span>
              <span>Ultimate</span>
            </button>
          </div>
          <input type="hidden" id="scanTypeInput" value="normal">
        </div>

        <button type="button" class="btn-start" id="btnStartScan" onclick="startScan()">
          <span id="btnStartIcon">▶</span>
          <span id="btnStartText">Start Scan</span>
        </button>
      </form>
    </div>

    <!-- System Status -->
    <div class="sidebar-section">
      <p class="sidebar-title">🖥️ System</p>
      <div class="syscheck">
        <div class="syscheck-item">
          <span class="icon"><?= $gsecExists ? '✅' : '❌' ?></span>
          <span class="syscheck-text">Gsec Script</span>
          <span class="<?= $gsecExists ? 'syscheck-ok' : 'syscheck-err' ?>"><?= $gsecExists ? 'Found' : 'Missing' ?></span>
        </div>
        <div class="syscheck-item">
          <span class="icon"><?= $pythonExists ? '✅' : '❌' ?></span>
          <span class="syscheck-text">Python 3</span>
          <span class="<?= $pythonExists ? 'syscheck-ok' : 'syscheck-err' ?>"><?= $pythonExists ? 'Available' : 'Not found' ?></span>
        </div>
        <div class="syscheck-item">
          <span class="icon" id="nucleiIcon"><?= !empty(shell_exec(NUCLEI_BIN . ' -version 2>&1')) ? '✅' : '⚠️' ?></span>
          <span class="syscheck-text">Nuclei</span>
          <span id="nucleiStatus" class="<?= !empty(shell_exec(NUCLEI_BIN . ' -version 2>&1')) ? 'syscheck-ok' : 'syscheck-err' ?>"><?= !empty(shell_exec(NUCLEI_BIN . ' -version 2>&1')) ? 'Available' : 'Optional' ?></span>
        </div>
        <div class="syscheck-item">
          <span class="icon">📊</span>
          <span class="syscheck-text">Active Scans</span>
          <span class="syscheck-ok" id="activeScansCount"><?= count($activeScans) ?> / <?= MAX_CONCURRENT_SCANS ?></span>
        </div>
      </div>
    </div>

    <!-- Recent Scans -->
    <div class="sidebar-section" style="flex:1; overflow:hidden; display:flex; flex-direction:column;">
      <div style="display:flex; align-items:center; justify-content:space-between; margin-bottom:.75rem;">
        <p class="sidebar-title" style="margin-bottom:0">🕘 Recent Scans</p>
        <button class="btn-tool" style="font-size:.68rem; padding:.15rem .45rem;" onclick="loadHistory()">↻</button>
      </div>
      <div id="recentScansList" style="overflow-y:auto; flex:1; display:flex; flex-direction:column; gap:.4rem;">
        <?php if (empty($scans)): ?>
          <div class="empty-state">
            <div class="empty-state-icon">📭</div>
            <p class="empty-state-text">No scans yet. Start your first scan!</p>
          </div>
        <?php else: ?>
          <?php foreach (array_slice($scans, 0, 8) as $scan): ?>
            <div class="scan-item" data-id="<?= htmlspecialchars($scan['id']) ?>" onclick="loadScan('<?= htmlspecialchars($scan['id']) ?>')">
              <button class="scan-item-del" title="Delete" onclick="event.stopPropagation(); deleteScan('<?= htmlspecialchars($scan['id']) ?>')">✕</button>
              <span class="scan-item-target"><?= htmlspecialchars($scan['target']) ?></span>
              <div class="scan-item-meta">
                <span class="badge badge-<?= htmlspecialchars($scan['status']) ?>"><?= htmlspecialchars($scan['status']) ?></span>
                <span class="badge badge-<?= htmlspecialchars($scan['type']) ?>"><?= htmlspecialchars($scan['type']) ?></span>
                <span class="text-muted"><?= date('H:i', strtotime($scan['started_at'])) ?></span>
              </div>
            </div>
          <?php endforeach; ?>
        <?php endif; ?>
      </div>
    </div>

  </aside><!-- /sidebar -->

  <!-- ─── MAIN CONTENT ─── -->
  <div class="main-content" id="mainContent">

    <!-- Stats Bar -->
    <div class="stats-bar" id="statsBar">
      <div class="stat-item vulns">
        <span class="stat-label">Vulnerabilities</span>
        <span class="stat-value" id="statVulns">0</span>
      </div>
      <div class="stat-divider"></div>
      <div class="stat-item warnings">
        <span class="stat-label">Warnings</span>
        <span class="stat-value" id="statWarnings">0</span>
      </div>
      <div class="stat-divider"></div>
      <div class="stat-item info">
        <span class="stat-label">Info</span>
        <span class="stat-value" id="statInfo">0</span>
      </div>
      <div class="stat-divider"></div>
      <div class="stat-item lines">
        <span class="stat-label">Lines</span>
        <span class="stat-value" id="statLines">0</span>
      </div>
      <div class="stat-divider"></div>
      <div class="stat-item" style="margin-left:auto;">
        <span class="stat-label" id="scanTimer" style="font-family:var(--font-mono); color:var(--text-muted);">00:00</span>
      </div>
    </div>

    <!-- Toolbar -->
    <div class="toolbar">
      <div class="toolbar-left">
        <div class="scan-info-bar">
          <span id="scanStatusLabel" class="text-muted">No active scan</span>
          <span class="scan-info-target" id="scanTargetLabel"></span>
          <span class="scan-progress-text" id="scanProgressText"></span>
        </div>
      </div>
      <div class="toolbar-right">
        <button class="btn-tool" onclick="toggleSearch()" title="Search in output [Ctrl+F]">🔍 Search</button>
        <button class="btn-tool" onclick="clearTerminal()" title="Clear terminal">🗑 Clear</button>
        <button class="btn-tool" onclick="toggleAutoScroll()" id="btnAutoScroll" title="Toggle auto-scroll">📌 Auto-scroll: ON</button>
        <button class="btn-tool" onclick="downloadLog()" id="btnDownload" title="Download log" style="display:none">⬇️ Log</button>
        <button class="btn-tool danger" onclick="stopCurrentScan()" id="btnStopScan" style="display:none">⏹ Stop</button>
      </div>
    </div>

    <!-- Search Bar -->
    <div class="search-bar" id="searchBar">
      <input type="text" class="search-input" id="searchInput" placeholder="Search in terminal output..." oninput="searchTerminal(this.value)">
      <span class="search-count" id="searchCount">0 results</span>
      <button class="btn-tool" onclick="toggleSearch()">✕</button>
    </div>

    <!-- Terminal -->
    <div class="terminal-wrapper">
      <div class="terminal" id="terminal">
        <div class="terminal-welcome" id="terminalWelcome">
          <pre>
    .__________________________.
    | .___________________. |==|
    | | ::::::::::::::::  | |  |      Gsec Web UI
    | | :::GSec Ready!::: | |  |
    | | ::::::::::::::::  | |  |      Enter a target and click
    | | ::::::::::::::::  | |  |      "Start Scan" to begin
    | | ::::::::::::::::  | | ,|
    | !___________________! |(c|      Happy Hacking!!!
    !_______________________!__!
   /                            \
  /  [][][][][][][][][][][][][]  \
 /  [][][][][][][][][][][][][][]  \
(  [][][][][____________][][][][]  )
 \ ------------------------------ /
  \______________________________/
          </pre>
          <p>← Configure target in the sidebar panel</p>
        </div>
      </div>
    </div>

  </div><!-- /main-content -->

</div><!-- /app-layout -->

<!-- ═══════════════════════════════════════════════════════
     SETTINGS MODAL
═══════════════════════════════════════════════════════ -->
<div class="modal-overlay" id="settingsModal">
  <div class="modal">
    <h3 class="modal-title">⚙️ Settings & Configuration</h3>
    <div style="display:flex; flex-direction:column; gap:.75rem;">
      <div class="syscheck">
        <div class="syscheck-item">
          <span class="icon">📁</span>
          <span class="syscheck-text">Gsec Path</span>
          <span class="font-mono" style="font-size:.72rem; color:var(--accent);"><?= htmlspecialchars(GSEC_SCRIPT) ?></span>
        </div>
        <div class="syscheck-item">
          <span class="icon">🐍</span>
          <span class="syscheck-text">Python Binary</span>
          <span class="font-mono" style="font-size:.72rem; color:var(--accent);"><?= htmlspecialchars(PYTHON_BIN) ?></span>
        </div>
        <div class="syscheck-item">
          <span class="icon">💾</span>
          <span class="syscheck-text">Storage Path</span>
          <span class="font-mono" style="font-size:.72rem; color:var(--accent);"><?= htmlspecialchars(STORAGE_DIR) ?></span>
        </div>
        <div class="syscheck-item">
          <span class="icon">🔄</span>
          <span class="syscheck-text">Max Concurrent Scans</span>
          <span class="syscheck-ok"><?= MAX_CONCURRENT_SCANS ?></span>
        </div>
      </div>
      <hr class="divider">
      <p class="text-muted">To change paths and settings, edit <span class="font-mono" style="color:var(--accent)">config.php</span></p>
    </div>
    <div class="modal-footer">
      <button class="btn-tool" onclick="closeModal('settingsModal')">Close</button>
    </div>
  </div>
</div>

<!-- ═══════════════════════════════════════════════════════
     TOAST CONTAINER
═══════════════════════════════════════════════════════ -->
<div class="toast-container" id="toastContainer"></div>

<!-- ═══════════════════════════════════════════════════════
     JAVASCRIPT
═══════════════════════════════════════════════════════ -->
<script>
// ─────────────────────────────────────────────────────────
// STATE
// ─────────────────────────────────────────────────────────
const state = {
  currentScanId: null,
  eventSource: null,
  scanType: 'normal',
  autoScroll: true,
  searchVisible: false,
  scanning: false,
  timerInterval: null,
  startTime: null,
  stats: { vulns: 0, warnings: 0, info: 0, lines: 0 },
  history: [],
};

// ─────────────────────────────────────────────────────────
// DOM refs
// ─────────────────────────────────────────────────────────
const $  = id => document.getElementById(id);
const terminal    = $('terminal');
const termWelcome = $('terminalWelcome');

// ─────────────────────────────────────────────────────────
// SCAN TYPE SELECTOR
// ─────────────────────────────────────────────────────────
function selectScanType(btn) {
  document.querySelectorAll('.scan-type-btn').forEach(b => b.classList.remove('selected'));
  btn.classList.add('selected');
  state.scanType = btn.dataset.type;
  $('scanTypeInput').value = state.scanType;
}

// ─────────────────────────────────────────────────────────
// START SCAN
// ─────────────────────────────────────────────────────────
async function startScan() {
  const target = $('targetInput').value.trim();
  if (!target) { toast('Please enter a target URL', 'error'); return; }

  // Validate URL
  let url = target;
  if (!url.startsWith('http://') && !url.startsWith('https://')) url = 'https://' + url;

  // Reset UI
  resetTerminal();
  setBtnScanning(true);
  resetStats();
  startTimer();

  $('scanStatusLabel').textContent = 'Starting scan...';
  $('scanTargetLabel').textContent = url;
  $('scanProgressText').textContent = '';
  $('btnStopScan').style.display = 'flex';
  $('btnDownload').style.display = 'none';

  try {
    const resp = await fetch('api/start_scan.php', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ target: url, scan_type: state.scanType }),
    });
    const data = await resp.json();

    if (!data.success) {
      toast(data.message || 'Failed to start scan', 'error');
      setBtnScanning(false);
      stopTimer();
      return;
    }

    state.currentScanId = data.scan_id;
    toast(`Scan started! PID: ${data.pid}`, 'success');
    $('scanStatusLabel').textContent = '● Scanning';
    $('scanStatusLabel').style.color = 'var(--green)';

    // Start SSE stream
    startStream(data.scan_id);
    loadHistory();

  } catch (err) {
    toast('Error: ' + err.message, 'error');
    setBtnScanning(false);
    stopTimer();
  }
}

// ─────────────────────────────────────────────────────────
// SSE STREAM
// ─────────────────────────────────────────────────────────
function startStream(scanId) {
  if (state.eventSource) {
    state.eventSource.close();
    state.eventSource = null;
  }

  const sse = new EventSource(`api/stream.php?scan_id=${encodeURIComponent(scanId)}`);
  state.eventSource = sse;

  sse.addEventListener('meta', (e) => {
    const d = JSON.parse(e.data);
    $('scanTargetLabel').textContent = d.target;
  });

  sse.addEventListener('line', (e) => {
    const d = JSON.parse(e.data);
    appendLine(d.html, d.raw, d.id);
  });

  sse.addEventListener('done', (e) => {
    const d = JSON.parse(e.data);
    sse.close();
    state.eventSource = null;
    setBtnScanning(false);
    stopTimer();
    $('btnStopScan').style.display = 'none';
    $('btnDownload').style.display = 'flex';

    if (d.status === 'completed') {
      $('scanStatusLabel').textContent = '✅ Scan completed';
      $('scanStatusLabel').style.color = 'var(--green)';
      toast('Scan completed!', 'success');
      if (d.stats) updateStats(d.stats);
    } else if (d.status === 'stopped') {
      $('scanStatusLabel').textContent = '⏹ Scan stopped';
      $('scanStatusLabel').style.color = 'var(--red)';
    } else {
      $('scanStatusLabel').textContent = `⚠️ Scan ${d.status}`;
      $('scanStatusLabel').style.color = 'var(--yellow)';
    }

    // Append cursor end
    appendRawHtml('<span style="color:var(--term-green);margin-left:.5rem">■ Scan Finished</span>');
    loadHistory();
  });

  sse.addEventListener('error', (e) => {
    if (e.data) {
      const d = JSON.parse(e.data);
      toast('Stream error: ' + (d.message || 'Unknown'), 'error');
    }
  });

  sse.onerror = () => {
    // SSE connection error (e.g., server closed)
    if (state.scanning) {
      $('scanStatusLabel').textContent = 'Connection lost';
      $('scanStatusLabel').style.color = 'var(--yellow)';
    }
  };
}

// ─────────────────────────────────────────────────────────
// STOP SCAN
// ─────────────────────────────────────────────────────────
async function stopCurrentScan() {
  if (!state.currentScanId) return;
  if (!confirm('Stop the current scan?')) return;

  if (state.eventSource) { state.eventSource.close(); state.eventSource = null; }

  try {
    await fetch('api/stop_scan.php', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ scan_id: state.currentScanId }),
    });
    toast('Scan stopped', 'info');
  } catch(e) {}

  setBtnScanning(false);
  stopTimer();
  $('btnStopScan').style.display = 'none';
  $('scanStatusLabel').textContent = '⏹ Stopped';
  $('scanStatusLabel').style.color = 'var(--red)';
  loadHistory();
}

// ─────────────────────────────────────────────────────────
// LOAD EXISTING SCAN
// ─────────────────────────────────────────────────────────
async function loadScan(scanId) {
  // Mark active in sidebar
  document.querySelectorAll('.scan-item').forEach(el => el.classList.remove('active'));
  const item = document.querySelector(`.scan-item[data-id="${scanId}"]`);
  if (item) item.classList.add('active');

  state.currentScanId = scanId;
  resetTerminal();
  resetStats();
  $('btnDownload').style.display = 'none';
  $('btnStopScan').style.display = 'none';

  try {
    const resp = await fetch(`api/get_log.php?scan_id=${encodeURIComponent(scanId)}`);
    const data = await resp.json();

    if (!data.success) { toast('Failed to load scan', 'error'); return; }

    const meta = data.meta;
    $('scanTargetLabel').textContent = meta.target;
    $('scanStatusLabel').textContent = meta.status;
    $('scanStatusLabel').style.color = meta.status === 'completed' ? 'var(--green)' :
                                        meta.status === 'running'   ? 'var(--accent)' : 'var(--red)';

    // Render lines
    data.lines.forEach((raw, i) => {
      appendLine(ansiToHtml(raw), raw, i + 1);
    });

    // If still running, connect stream
    if (meta.status === 'running') {
      $('btnStopScan').style.display = 'flex';
      setBtnScanning(true);
      startTimer();
      startStream(scanId);
    } else {
      $('btnDownload').style.display = 'flex';
    }

    toast(`Loaded: ${meta.target}`, 'info');
  } catch(e) {
    toast('Error loading scan: ' + e.message, 'error');
  }
}

// ─────────────────────────────────────────────────────────
// TERMINAL HELPERS
// ─────────────────────────────────────────────────────────
function appendLine(html, raw = '', lineNum = 0) {
  // Hide welcome screen on first line
  if (termWelcome) termWelcome.style.display = 'none';

  const div = document.createElement('div');
  div.className = 'term-line ' + classifyLine(raw);

  const numSpan = document.createElement('span');
  numSpan.className = 'term-line-num';
  numSpan.textContent = lineNum || '';

  const content = document.createElement('span');
  content.innerHTML = html || '&nbsp;';

  div.appendChild(numSpan);
  div.appendChild(content);
  terminal.appendChild(div);

  state.stats.lines++;
  $('statLines').textContent = state.stats.lines;

  // Update stats from raw
  autoClassifyStats(raw);

  if (state.autoScroll) {
    terminal.scrollTop = terminal.scrollHeight;
  }
}

function appendRawHtml(html) {
  const div = document.createElement('div');
  div.className = 'term-line';
  div.innerHTML = html;
  terminal.appendChild(div);
  if (state.autoScroll) terminal.scrollTop = terminal.scrollHeight;
}

function classifyLine(raw) {
  const lower = raw.toLowerCase();
  if (/critical|high|severe|vuln|exploit|inject|rce|sqli|xss|lfi|rfi|ssrf|idor|bola/i.test(lower)) return 'line-vuln';
  if (/warn|possible|medium|misconfigur/i.test(lower)) return 'line-warning';
  if (/\[\+\]|success|open|found/i.test(lower)) return 'line-success';
  if (/\[\*\]|\[i\]|info:|running|scanning|checking/i.test(lower)) return 'line-info';
  if (/={5,}|─{5,}|[A-Z ]{10,}SCAN|GSEC/i.test(raw)) return 'line-section';
  return '';
}

function autoClassifyStats(raw) {
  const lower = raw.toLowerCase();
  if (/critical|high|severe|vuln|exploit|inject|rce|sqli|xss|lfi|rfi|ssrf|idor|bola/i.test(lower)) {
    state.stats.vulns++;
    $('statVulns').textContent = state.stats.vulns;
  } else if (/warn|possible|medium|misconfigur/i.test(lower)) {
    state.stats.warnings++;
    $('statWarnings').textContent = state.stats.warnings;
  } else if (/\[\+\]|\[\*\]|info:/i.test(lower)) {
    state.stats.info++;
    $('statInfo').textContent = state.stats.info;
  }
}

function updateStats(stats) {
  if (stats.vulns !== undefined)   { state.stats.vulns = stats.vulns; $('statVulns').textContent = stats.vulns; }
  if (stats.warnings !== undefined){ state.stats.warnings = stats.warnings; $('statWarnings').textContent = stats.warnings; }
  if (stats.info !== undefined)    { state.stats.info = stats.info; $('statInfo').textContent = stats.info; }
}

function resetStats() {
  state.stats = { vulns: 0, warnings: 0, info: 0, lines: 0 };
  ['statVulns','statWarnings','statInfo','statLines'].forEach(id => $(id).textContent = '0');
}

function resetTerminal() {
  // Remove all term-lines
  const lines = terminal.querySelectorAll('.term-line');
  lines.forEach(l => l.remove());
  if (termWelcome) termWelcome.style.display = '';
}

function clearTerminal() {
  resetTerminal();
  resetStats();
}

// ─────────────────────────────────────────────────────────
// ANSI → HTML (client-side, for loading historical logs)
// ─────────────────────────────────────────────────────────
function ansiToHtml(text) {
  const ansiColors = {
    '30':'#1e1e1e','31':'#ff5555','32':'#50fa7b','33':'#f1fa8c',
    '34':'#6272a4','35':'#ff79c6','36':'#8be9fd','37':'#f8f8f2',
    '90':'#6272a4','91':'#ff6e6e','92':'#69ff47','93':'#ffffa5',
    '94':'#d6acff','95':'#ff92df','96':'#a4ffff','97':'#ffffff',
  };
  let html = text.replace(/\x1b\[([0-9;]*)m/g, (match, codes) => {
    const parts = codes.split(';');
    let out = '';
    for (const code of parts) {
      const c = code.replace(/^0+/, '') || '0';
      if (c === '0' || c === '') { out += '</span>'; continue; }
      if (ansiColors[c]) { out += `<span style="color:${ansiColors[c]}"`; continue; }
      if (c === '1') { out += '<span style="font-weight:bold">'; continue; }
    }
    return out;
  });
  // Strip remaining escape sequences
  html = html.replace(/\x1b\[[0-9;]*[a-zA-Z]/g, '');
  html = html.replace(/\x1b/g, '');
  // Escape HTML but preserve our spans
  const tmp = document.createElement('div');
  tmp.textContent = html;
  return tmp.innerHTML
    .replace(/&lt;span /g,'<span ')
    .replace(/&lt;\/span&gt;/g,'</span>')
    .replace(/style=&quot;/g, 'style="')
    .replace(/&quot;&gt;/g, '">');
}

// ─────────────────────────────────────────────────────────
// SEARCH IN TERMINAL
// ─────────────────────────────────────────────────────────
function toggleSearch() {
  state.searchVisible = !state.searchVisible;
  const bar = $('searchBar');
  bar.classList.toggle('visible', state.searchVisible);
  if (state.searchVisible) $('searchInput').focus();
  else { $('searchInput').value = ''; searchTerminal(''); }
}

function searchTerminal(query) {
  const lines = terminal.querySelectorAll('.term-line');
  let count = 0;
  lines.forEach(line => {
    if (!query) { line.style.opacity = ''; return; }
    const text = line.textContent.toLowerCase();
    const match = text.includes(query.toLowerCase());
    line.style.opacity = match ? '1' : '0.15';
    if (match) count++;
  });
  $('searchCount').textContent = query ? `${count} results` : '';
}

// Keyboard shortcut
document.addEventListener('keydown', (e) => {
  if ((e.ctrlKey || e.metaKey) && e.key === 'f') { e.preventDefault(); toggleSearch(); }
  if (e.key === 'Escape' && state.searchVisible) toggleSearch();
});

// ─────────────────────────────────────────────────────────
// AUTO-SCROLL TOGGLE
// ─────────────────────────────────────────────────────────
function toggleAutoScroll() {
  state.autoScroll = !state.autoScroll;
  $('btnAutoScroll').textContent = `📌 Auto-scroll: ${state.autoScroll ? 'ON' : 'OFF'}`;
  $('btnAutoScroll').style.color = state.autoScroll ? 'var(--green)' : 'var(--text-muted)';
}

// Detect manual scroll to disable auto-scroll
terminal.addEventListener('scroll', () => {
  const atBottom = terminal.scrollHeight - terminal.scrollTop <= terminal.clientHeight + 40;
  if (!atBottom && state.autoScroll) {
    state.autoScroll = false;
    $('btnAutoScroll').textContent = '📌 Auto-scroll: OFF';
    $('btnAutoScroll').style.color = 'var(--text-muted)';
  }
});

// ─────────────────────────────────────────────────────────
// DOWNLOAD LOG
// ─────────────────────────────────────────────────────────
function downloadLog() {
  if (!state.currentScanId) return;
  window.open(`api/get_log.php?scan_id=${encodeURIComponent(state.currentScanId)}&format=download`, '_blank');
}

// ─────────────────────────────────────────────────────────
// DELETE SCAN
// ─────────────────────────────────────────────────────────
async function deleteScan(scanId) {
  if (!confirm('Delete this scan?')) return;
  try {
    await fetch('api/delete_scan.php', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ scan_id: scanId }),
    });
    toast('Scan deleted', 'info');
    loadHistory();
    if (state.currentScanId === scanId) {
      resetTerminal(); resetStats();
      $('scanStatusLabel').textContent = 'No active scan';
      $('scanStatusLabel').style.color = '';
      $('scanTargetLabel').textContent = '';
    }
  } catch(e) {
    toast('Delete failed', 'error');
  }
}

// ─────────────────────────────────────────────────────────
// SCAN HISTORY SIDEBAR
// ─────────────────────────────────────────────────────────
async function loadHistory() {
  try {
    const resp = await fetch('api/status.php');
    const data = await resp.json();
    if (!data.success) return;

    state.history = data.scans;
    $('activeScansCount').textContent = data.scans.filter(s => s.status === 'running').length + ' / <?= MAX_CONCURRENT_SCANS ?>';

    const list = $('recentScansList');
    list.innerHTML = '';

    if (!data.scans.length) {
      list.innerHTML = `<div class="empty-state">
        <div class="empty-state-icon">📭</div>
        <p class="empty-state-text">No scans yet</p>
      </div>`;
      return;
    }

    data.scans.slice(0, 8).forEach(scan => {
      const div = document.createElement('div');
      div.className = 'scan-item' + (scan.id === state.currentScanId ? ' active' : '');
      div.dataset.id = scan.id;
      div.onclick = () => loadScan(scan.id);
      div.innerHTML = `
        <button class="scan-item-del" title="Delete" onclick="event.stopPropagation();deleteScan('${escHtml(scan.id)}')">✕</button>
        <span class="scan-item-target">${escHtml(scan.target)}</span>
        <div class="scan-item-meta">
          <span class="badge badge-${escHtml(scan.status)}">${escHtml(scan.status)}</span>
          <span class="badge badge-${escHtml(scan.type)}">${escHtml(scan.type)}</span>
          <span class="text-muted">${new Date(scan.started_at).toLocaleTimeString([], {hour:'2-digit',minute:'2-digit'})}</span>
        </div>`;
      list.appendChild(div);
    });
  } catch(e) {}
}

// ─────────────────────────────────────────────────────────
// TIMER
// ─────────────────────────────────────────────────────────
function startTimer() {
  stopTimer();
  state.startTime = Date.now();
  state.timerInterval = setInterval(() => {
    const elapsed = Math.floor((Date.now() - state.startTime) / 1000);
    const m = String(Math.floor(elapsed / 60)).padStart(2, '0');
    const s = String(elapsed % 60).padStart(2, '0');
    $('scanTimer').textContent = `${m}:${s}`;
  }, 1000);
}

function stopTimer() {
  if (state.timerInterval) { clearInterval(state.timerInterval); state.timerInterval = null; }
}

// ─────────────────────────────────────────────────────────
// BUTTON STATE
// ─────────────────────────────────────────────────────────
function setBtnScanning(scanning) {
  state.scanning = scanning;
  const btn = $('btnStartScan');
  const icon = $('btnStartIcon');
  const text = $('btnStartText');

  if (scanning) {
    btn.disabled = true;
    btn.classList.add('scanning');
    icon.innerHTML = '<span class="spinner" style="width:12px;height:12px;border-width:2px;"></span>';
    text.textContent = 'Scanning...';
  } else {
    btn.disabled = false;
    btn.classList.remove('scanning');
    icon.textContent = '▶';
    text.textContent = 'Start Scan';
  }
}

// ─────────────────────────────────────────────────────────
// MODAL
// ─────────────────────────────────────────────────────────
function showModal(id) { $(id).classList.add('open'); }
function closeModal(id) { $(id).classList.remove('open'); }

document.querySelectorAll('.modal-overlay').forEach(m => {
  m.addEventListener('click', e => { if (e.target === m) m.classList.remove('open'); });
});

// ─────────────────────────────────────────────────────────
// TOAST
// ─────────────────────────────────────────────────────────
function toast(message, type = 'info') {
  const icons = { success: '✅', error: '❌', info: 'ℹ️' };
  const div = document.createElement('div');
  div.className = `toast ${type}`;
  div.innerHTML = `<span>${icons[type] || '•'}</span><span>${escHtml(message)}</span>`;
  $('toastContainer').appendChild(div);
  setTimeout(() => { div.style.opacity = '0'; div.style.transform = 'translateX(30px)'; div.style.transition = '.3s'; setTimeout(() => div.remove(), 300); }, 3000);
}

// ─────────────────────────────────────────────────────────
// VIEW TOGGLE
// ─────────────────────────────────────────────────────────
function showView(view) {
  ['btnDashboard','btnHistory','btnSettings'].forEach(id => $(id)?.classList.remove('active'));
  if (view === 'dashboard') $('btnDashboard').classList.add('active');
  if (view === 'history')   $('btnHistory').classList.add('active');
}

// ─────────────────────────────────────────────────────────
// UTILS
// ─────────────────────────────────────────────────────────
function escHtml(str) {
  return String(str).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

// ─────────────────────────────────────────────────────────
// INIT
// ─────────────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', () => {
  // Auto-reload history every 10s
  setInterval(loadHistory, 10_000);
});
</script>
</body>
</html>
