<?php
// ============================================================
// Gsec Web UI - Scan Manager Helper
// PHP 8.0+
// ============================================================

declare(strict_types=1);

require_once __DIR__ . '/config.php';

class ScanManager
{
    /**
     * Generate unique scan ID
     */
    public static function generateScanId(): string
    {
        return 'scan_' . uniqid('', true) . '_' . bin2hex(random_bytes(4));
    }

    /**
     * Build command for gsec.py
     */
    public static function buildCommand(string $target, string $scanType, array $options = []): string
    {
        $target = escapeshellarg($target);
        $script = escapeshellarg(GSEC_SCRIPT);
        $python = PYTHON_BIN;

        $cmd = match($scanType) {
            'passive'  => "$python $script -t $target --passive_recon",
            'ultimate' => "$python $script --ultimatescan $target",
            default    => "$python $script -t $target",  // normal
        };

        return $cmd;
    }

    /**
     * Start a new scan process
     * Returns scan metadata array
     */
    public static function startScan(string $target, string $scanType): array
    {
        $scanId   = self::generateScanId();
        $cmd      = self::buildCommand($target, $scanType);
        $logFile  = LOG_DIR . "/{$scanId}.log";
        $pidFile  = SCAN_DIR . "/{$scanId}.pid";
        $metaFile = SCAN_DIR . "/{$scanId}.json";

        // Build env - change to gsec directory so relative imports work
        $gsecDir = GSEC_ROOT;

        // Start process in background, redirect stdout+stderr to log
        $fullCmd = "cd " . escapeshellarg($gsecDir) . " && PYTHONUNBUFFERED=1 FORCE_COLOR=1 TERM=xterm-256color $cmd > " . escapeshellarg($logFile) . " 2>&1 & echo $!";

        $pid = trim((string)shell_exec($fullCmd));

        // Save PID
        file_put_contents($pidFile, $pid);

        // Save scan metadata
        $meta = [
            'id'         => $scanId,
            'target'     => $target,
            'type'       => $scanType,
            'command'    => $cmd,
            'pid'        => (int)$pid,
            'status'     => 'running',
            'started_at' => date('c'),
            'ended_at'   => null,
            'log_file'   => $logFile,
        ];
        file_put_contents($metaFile, json_encode($meta, JSON_PRETTY_PRINT));

        return $meta;
    }

    /**
     * Stop a running scan
     */
    public static function stopScan(string $scanId): bool
    {
        $meta = self::getScanMeta($scanId);
        if (!$meta) return false;

        $pid = $meta['pid'] ?? 0;
        if ($pid > 0) {
            // Kill process group
            @shell_exec("kill -TERM -$pid 2>/dev/null || kill -TERM $pid 2>/dev/null");
            sleep(1);
            @shell_exec("kill -9 $pid 2>/dev/null");
        }

        self::updateMeta($scanId, ['status' => 'stopped', 'ended_at' => date('c')]);
        return true;
    }

    /**
     * Check if a scan process is still running
     */
    public static function isRunning(string $scanId): bool
    {
        $meta = self::getScanMeta($scanId);
        if (!$meta || $meta['status'] !== 'running') return false;

        $pid = $meta['pid'] ?? 0;
        if ($pid <= 0) return false;

        $running = trim((string)shell_exec("ps -p $pid -o pid= 2>/dev/null"));
        return $running === (string)$pid;
    }

    /**
     * Get scan metadata
     */
    public static function getScanMeta(string $scanId): ?array
    {
        $metaFile = SCAN_DIR . "/{$scanId}.json";
        if (!file_exists($metaFile)) return null;

        $data = json_decode(file_get_contents($metaFile), true);
        return is_array($data) ? $data : null;
    }

    /**
     * Update scan metadata
     */
    public static function updateMeta(string $scanId, array $data): void
    {
        $meta = self::getScanMeta($scanId);
        if ($meta) {
            $meta = array_merge($meta, $data);
            file_put_contents(SCAN_DIR . "/{$scanId}.json", json_encode($meta, JSON_PRETTY_PRINT));
        }
    }

    /**
     * Get log file path
     */
    public static function getLogFile(string $scanId): ?string
    {
        $logFile = LOG_DIR . "/{$scanId}.log";
        return file_exists($logFile) ? $logFile : null;
    }

    /**
     * Get all scans (most recent first)
     */
    public static function getAllScans(int $limit = 50): array
    {
        $files = glob(SCAN_DIR . '/scan_*.json');
        if (!$files) return [];

        $scans = [];
        foreach ($files as $file) {
            $data = json_decode(file_get_contents($file), true);
            if (is_array($data)) {
                // Auto-update status if process finished
                if ($data['status'] === 'running') {
                    $pid = $data['pid'] ?? 0;
                    $running = $pid > 0 && trim((string)shell_exec("ps -p $pid -o pid= 2>/dev/null")) === (string)$pid;
                    if (!$running) {
                        $data['status'] = 'completed';
                        $data['ended_at'] = $data['ended_at'] ?? date('c');
                        file_put_contents($file, json_encode($data, JSON_PRETTY_PRINT));
                    }
                }
                $scans[] = $data;
            }
        }

        // Sort by started_at DESC
        usort($scans, fn($a, $b) => strcmp($b['started_at'] ?? '', $a['started_at'] ?? ''));

        return array_slice($scans, 0, $limit);
    }

    /**
     * Count active scans
     */
    public static function countActiveScans(): int
    {
        $scans = self::getAllScans();
        return count(array_filter($scans, fn($s) => $s['status'] === 'running'));
    }

    /**
     * Delete scan and its files
     */
    public static function deleteScan(string $scanId): bool
    {
        $scanId = preg_replace('/[^a-zA-Z0-9_.]/', '', $scanId); // Sanitize
        $files = [
            SCAN_DIR . "/{$scanId}.json",
            SCAN_DIR . "/{$scanId}.pid",
            LOG_DIR  . "/{$scanId}.log",
        ];
        foreach ($files as $f) {
            if (file_exists($f)) @unlink($f);
        }
        return true;
    }
}
