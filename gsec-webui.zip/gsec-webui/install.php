#!/usr/bin/env php
<?php
// ============================================================
// Gsec Web UI — Installation & Setup Checker
// Run: php install.php
// PHP 8.0+
// ============================================================

declare(strict_types=1);

const RESET  = "\033[0m";
const BOLD   = "\033[1m";
const RED    = "\033[31m";
const GREEN  = "\033[32m";
const YELLOW = "\033[33m";
const CYAN   = "\033[36m";
const MAGENTA = "\033[35m";

function ok(string $msg): void  { echo GREEN  . "  ✓  " . RESET . $msg . "\n"; }
function err(string $msg): void { echo RED    . "  ✗  " . RESET . $msg . "\n"; }
function warn(string $msg): void{ echo YELLOW . "  ⚠  " . RESET . $msg . "\n"; }
function info(string $msg): void{ echo CYAN   . "  ℹ  " . RESET . $msg . "\n"; }
function head(string $msg): void{ echo "\n" . BOLD . MAGENTA . $msg . RESET . "\n" . str_repeat("─", 50) . "\n"; }

echo BOLD . CYAN . "
╔════════════════════════════════════════════════╗
║         Gsec Web UI — Setup Checker           ║
║                 PHP 8.0+                      ║
╚════════════════════════════════════════════════╝
" . RESET;

$errors = 0;
$warnings = 0;

// ─── PHP Version ───────────────────────────────
head("1. PHP Requirements");

$phpVersion = phpversion();
if (version_compare($phpVersion, '8.0.0', '>=')) {
    ok("PHP version: $phpVersion");
} else {
    err("PHP 8.0+ required! Current: $phpVersion");
    $errors++;
}

// Required extensions
$required = ['json', 'pcre', 'session', 'filter'];
foreach ($required as $ext) {
    if (extension_loaded($ext)) ok("Extension: $ext");
    else { err("Missing extension: $ext"); $errors++; }
}

// Useful functions
$funcs = ['proc_open', 'shell_exec', 'exec', 'popen'];
foreach ($funcs as $func) {
    $disabled = in_array($func, array_map('trim', explode(',', ini_get('disable_functions'))));
    if (!$disabled) ok("Function available: $func");
    else { err("Function disabled: $func (required for process execution)"); $errors++; }
}

// ─── Directory Permissions ─────────────────────
head("2. Directory Permissions");

$baseDir = __DIR__;
$dirs = [
    $baseDir . '/storage'         => 'Storage root',
    $baseDir . '/storage/scans'   => 'Scan metadata',
    $baseDir . '/storage/logs'    => 'Scan logs',
    $baseDir . '/storage/outputs' => 'Scan outputs',
];

foreach ($dirs as $dir => $label) {
    if (!is_dir($dir)) {
        if (mkdir($dir, 0755, true)) ok("Created: $label ($dir)");
        else { err("Cannot create: $dir"); $errors++; }
    } else {
        ok("Exists: $label");
    }

    if (is_writable($dir)) ok("Writable: $label");
    else { err("Not writable: $dir — run: chmod 755 $dir"); $errors++; }
}

// ─── Config File ───────────────────────────────
head("3. Configuration");

$configFile = $baseDir . '/config.php';
if (file_exists($configFile)) {
    ok("config.php found");
    require_once $configFile;

    // Check Gsec
    if (defined('GSEC_SCRIPT')) {
        if (file_exists(GSEC_SCRIPT)) ok("Gsec script found: " . GSEC_SCRIPT);
        else { err("Gsec script NOT found: " . GSEC_SCRIPT . "\n     → Update GSEC_ROOT in config.php"); $errors++; }
    }

    // Check Python
    if (defined('PYTHON_BIN')) {
        $pyVer = trim((string)shell_exec(PYTHON_BIN . ' --version 2>&1'));
        if (!empty($pyVer)) ok("Python found: $pyVer (at " . PYTHON_BIN . ")");
        else { err("Python NOT found at: " . PYTHON_BIN . "\n     → Update PYTHON_BIN in config.php"); $errors++; }
    }

    // Check Nuclei (optional)
    if (defined('NUCLEI_BIN')) {
        $nVer = trim((string)shell_exec(NUCLEI_BIN . ' -version 2>&1'));
        if (!empty($nVer)) ok("Nuclei found: " . explode("\n", $nVer)[0]);
        else warn("Nuclei NOT found (optional — some scans use it)\n     → Install: go install -v github.com/projectdiscovery/nuclei/v3/cmd/nuclei@latest");
    }
} else {
    err("config.php not found!");
    $errors++;
}

// ─── Web Server ────────────────────────────────
head("4. Web Server");

if (php_sapi_name() !== 'cli') {
    ok("Running under web server: " . ($_SERVER['SERVER_SOFTWARE'] ?? 'Unknown'));
} else {
    info("Running from CLI — web server not checked");
    info("Ensure Apache/Nginx is configured with PHP 8+");
    info("For SSE (realtime), ensure output buffering is disabled");
    info("See nginx.conf.example for Nginx configuration");
}

// php.ini recommendations
$settings = [
    'output_buffering' => ['expected' => '0', 'label' => 'Output buffering disabled (for SSE)'],
    'max_execution_time' => ['expected' => '0', 'label' => 'Max execution time (0 = unlimited for long scans)'],
];

foreach ($settings as $key => $cfg) {
    $val = ini_get($key);
    if ($val === $cfg['expected'] || ($key === 'max_execution_time' && (int)$val >= 300)) {
        ok($cfg['label'] . " = $val");
    } else {
        warn($cfg['label'] . " = $val (recommended: {$cfg['expected']} in php.ini)");
        $warnings++;
    }
}

// ─── Summary ───────────────────────────────────
head("5. Summary");

if ($errors === 0 && $warnings === 0) {
    echo GREEN . BOLD . "\n  ✅ All checks passed! Gsec Web UI is ready.\n\n" . RESET;
} elseif ($errors === 0) {
    echo YELLOW . BOLD . "\n  ⚠  Setup complete with $warnings warning(s). Check above.\n\n" . RESET;
} else {
    echo RED . BOLD . "\n  ✗  Found $errors error(s) and $warnings warning(s). Fix them before running.\n\n" . RESET;
}

echo CYAN . "  Usage:\n" . RESET;
echo "    1. Edit " . BOLD . "config.php" . RESET . " — set GSEC_ROOT to your Gsec directory\n";
echo "    2. Place this directory in your web root\n";
echo "    3. Open in browser: " . BOLD . "http://localhost/gsec-webui/\n" . RESET;
echo "    4. Enter target URL and click 'Start Scan'\n\n";
