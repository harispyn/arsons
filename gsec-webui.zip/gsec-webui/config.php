<?php
// ============================================================
// Gsec Web UI - Configuration
// PHP 8.0+
// ============================================================

declare(strict_types=1);

define('GSEC_VERSION', '1.0.0');
define('GSEC_ROOT', dirname(__DIR__) . '/Gsec');           // Path to Gsec project root
define('GSEC_SCRIPT', GSEC_ROOT . '/gsec.py');             // Path to gsec.py
define('PYTHON_BIN', '/usr/bin/python3');                  // Python binary
define('NUCLEI_BIN', '/usr/local/bin/nuclei');             // Nuclei binary (optional)

define('STORAGE_DIR', __DIR__ . '/storage');               // Storage directory
define('SCAN_DIR', STORAGE_DIR . '/scans');                // Scan data directory
define('LOG_DIR', STORAGE_DIR . '/logs');                  // Log directory
define('OUTPUT_DIR', STORAGE_DIR . '/outputs');            // Output directory

// Security - restrict to local or whitelisted IPs (empty = all allowed)
define('ALLOWED_IPS', []);

// Max concurrent scans
define('MAX_CONCURRENT_SCANS', 3);

// Scan timeout in seconds (0 = unlimited)
define('SCAN_TIMEOUT', 0);

// App name
define('APP_NAME', 'Gsec Web UI');

// Session lifetime (seconds)
define('SESSION_LIFETIME', 3600);

// Initialize directories
$dirs = [STORAGE_DIR, SCAN_DIR, LOG_DIR, OUTPUT_DIR];
foreach ($dirs as $dir) {
    if (!is_dir($dir)) {
        mkdir($dir, 0755, true);
    }
}

// Initialize session
if (session_status() === PHP_SESSION_NONE) {
    session_set_cookie_params(['lifetime' => SESSION_LIFETIME, 'httponly' => true, 'samesite' => 'Strict']);
    session_start();
}
