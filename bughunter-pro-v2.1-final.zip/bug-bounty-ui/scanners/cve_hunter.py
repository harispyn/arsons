#!/usr/bin/env python3
"""CVE Hunter"""
from scanners.oauth_tester import CVEHunter
