#!/usr/bin/env python3
"""
Recon Engine - Subdomain enumeration, DNS, HTTP probing
For authorized testing only.
"""

import subprocess
import requests
import socket
import json
import time
import dns.resolver
from urllib.parse import urlparse
from concurrent.futures import ThreadPoolExecutor, as_completed

class ReconEngine:
    def __init__(self, target, scan_id, socketio, log_fn, finding_fn):
        self.target = target
        self.scan_id = scan_id
        self.socketio = socketio
        self.log = log_fn
        self.add_finding = finding_fn
        
        # Normalize target
        if target.startswith('http'):
            parsed = urlparse(target)
            self.domain = parsed.netloc
            self.base_url = target.rstrip('/')
        else:
            self.domain = target
            self.base_url = f"https://{target}"
        
        self.subdomains = []
        self.live_hosts = []
        self.endpoints = []

    def run(self, depth='medium'):
        self.log(self.scan_id, f"🌐 Target domain: {self.domain}", 'info', 'recon')
        
        # 1. DNS Lookup
        self._dns_recon()
        
        # 2. Subdomain Enumeration
        self._subdomain_enum(depth)
        
        # 3. HTTP Probe
        self._http_probe()
        
        # 4. Technology Detection
        self._tech_detect()
        
        # 5. Directory/Path discovery
        self._path_discovery()
        
        return {
            'domain': self.domain,
            'subdomains': self.subdomains,
            'live_hosts': self.live_hosts,
            'endpoints': self.endpoints
        }

    def _dns_recon(self):
        self.log(self.scan_id, "🔎 Running DNS reconnaissance...", 'info', 'dnsx')
        record_types = ['A', 'AAAA', 'MX', 'NS', 'TXT', 'CNAME']
        
        for rtype in record_types:
            try:
                resolver = dns.resolver.Resolver()
                resolver.timeout = 3
                resolver.lifetime = 3
                answers = resolver.resolve(self.domain, rtype)
                for rdata in answers:
                    self.log(self.scan_id, f"  [{rtype}] {self.domain} → {rdata}", 'data', 'dns')
                    
                    # Check for interesting TXT records
                    if rtype == 'TXT':
                        txt_val = str(rdata)
                        if any(k in txt_val.lower() for k in ['key', 'token', 'secret', 'api']):
                            self.add_finding(self.scan_id, {
                                'type': 'Sensitive DNS TXT Record',
                                'severity': 'medium',
                                'target': self.domain,
                                'description': f'Potentially sensitive TXT record: {txt_val}',
                                'evidence': txt_val,
                                'cvss': 4.3,
                                'remediation': 'Review and remove sensitive data from DNS TXT records'
                            })
            except Exception:
                pass
        
        # Reverse DNS
        try:
            ip = socket.gethostbyname(self.domain)
            self.log(self.scan_id, f"  [IP] {self.domain} → {ip}", 'data', 'dns')
            hostname, _, _ = socket.gethostbyaddr(ip)
            self.log(self.scan_id, f"  [PTR] {ip} → {hostname}", 'data', 'dns')
        except Exception:
            pass

    def _subdomain_enum(self, depth):
        self.log(self.scan_id, "🔍 Enumerating subdomains...", 'info', 'subfinder')
        
        # Common subdomains wordlist
        common_subs = [
            'www', 'api', 'app', 'admin', 'dev', 'staging', 'test', 'beta',
            'mail', 'smtp', 'ftp', 'ssh', 'vpn', 'portal', 'dashboard',
            'auth', 'login', 'secure', 'cdn', 'static', 'assets',
            'blog', 'shop', 'store', 'pay', 'payment', 'checkout',
            'api-v1', 'api-v2', 'api2', 'v1', 'v2', 'v3',
            'internal', 'intranet', 'corp', 'enterprise',
            'jenkins', 'jira', 'confluence', 'gitlab', 'github',
            'grafana', 'prometheus', 'kibana', 'elastic', 'solr',
            'dev1', 'dev2', 'uat', 'qa', 'prod', 'production',
            'backup', 'old', 'new', 'legacy', 'deprecated',
            'mobile', 'ios', 'android', 'm', 'wap',
            'files', 'download', 'upload', 'media', 'img', 'images',
            'support', 'help', 'docs', 'wiki', 'forum',
            'status', 'monitor', 'health', 'ping',
            'ws', 'socket', 'websocket', 'grpc'
        ]
        
        if depth == 'deep':
            common_subs.extend([
                'local', 'private', 'sandbox', 'canary', 'preview',
                'feature', 'release', 'rc', 'alpha', 'demo',
                'db', 'database', 'mysql', 'postgres', 'redis', 'mongo',
                'k8s', 'kubernetes', 'docker', 'registry', 'harbor',
                'ldap', 'sso', 'oauth', 'identity',
                'error', 'log', 'logs', 'debug', 'trace',
                'metrics', 'telemetry', 'observability',
                'aws', 'gcp', 'azure', 'cloud'
            ])
        
        found = []
        
        def check_subdomain(sub):
            fqdn = f"{sub}.{self.domain}"
            try:
                ip = socket.gethostbyname(fqdn)
                return fqdn, ip
            except:
                return None, None
        
        with ThreadPoolExecutor(max_workers=50) as executor:
            futures = {executor.submit(check_subdomain, sub): sub for sub in common_subs}
            for future in as_completed(futures):
                fqdn, ip = future.result()
                if fqdn and ip:
                    found.append({'subdomain': fqdn, 'ip': ip})
                    self.subdomains.append(fqdn)
                    self.log(self.scan_id, f"  ✓ Found: {fqdn} [{ip}]", 'success', 'subfinder')
        
        # Try crt.sh for certificate transparency
        try:
            resp = requests.get(
                f"https://crt.sh/?q=%.{self.domain}&output=json",
                timeout=10, verify=False
            )
            if resp.status_code == 200:
                certs = resp.json()
                ct_subs = set()
                for cert in certs[:50]:
                    name = cert.get('name_value', '')
                    for sub in name.split('\n'):
                        sub = sub.strip().lstrip('*.')
                        if sub.endswith(f'.{self.domain}') and sub not in ct_subs:
                            ct_subs.add(sub)
                            if sub not in self.subdomains:
                                self.subdomains.append(sub)
                                self.log(self.scan_id, f"  🔏 [CT] Found: {sub}", 'data', 'crt.sh')
        except:
            pass

        self.log(self.scan_id, f"  📊 Total subdomains found: {len(self.subdomains)}", 'info', 'subfinder')

    def _http_probe(self):
        self.log(self.scan_id, "🌐 Probing live HTTP hosts...", 'info', 'httpx')
        
        targets_to_probe = [self.base_url] + [
            f"https://{sub}" for sub in self.subdomains[:20]
        ]
        
        def probe(url):
            try:
                r = requests.get(url, timeout=5, verify=False,
                                 allow_redirects=True,
                                 headers={'User-Agent': 'Mozilla/5.0 BugHunterPro/2.0'})
                return {
                    'url': url,
                    'status': r.status_code,
                    'title': self._extract_title(r.text),
                    'server': r.headers.get('Server', ''),
                    'content_length': len(r.content),
                    'technologies': self._detect_tech_from_response(r)
                }
            except:
                return None
        
        with ThreadPoolExecutor(max_workers=20) as executor:
            futures = {executor.submit(probe, url): url for url in targets_to_probe}
            for future in as_completed(futures):
                result = future.result()
                if result:
                    self.live_hosts.append(result)
                    status_icon = '✅' if result['status'] == 200 else '⚠️'
                    self.log(
                        self.scan_id,
                        f"  {status_icon} [{result['status']}] {result['url']} "
                        f"- {result.get('title', 'No Title')} [{result.get('server','')}]",
                        'data', 'httpx'
                    )
                    
                    # Check for interesting headers
                    self._check_security_headers(result)

    def _check_security_headers(self, host_info):
        url = host_info['url']
        try:
            r = requests.get(url, timeout=5, verify=False,
                             headers={'User-Agent': 'Mozilla/5.0'})
            headers = {k.lower(): v for k, v in r.headers.items()}
            
            missing = []
            if 'x-frame-options' not in headers:
                missing.append('X-Frame-Options')
            if 'x-content-type-options' not in headers:
                missing.append('X-Content-Type-Options')
            if 'strict-transport-security' not in headers and url.startswith('https'):
                missing.append('HSTS')
            if 'content-security-policy' not in headers:
                missing.append('Content-Security-Policy')
            
            if len(missing) >= 2:
                self.add_finding(self.scan_id, {
                    'type': 'Missing Security Headers',
                    'severity': 'low',
                    'target': url,
                    'description': f'Missing security headers: {", ".join(missing)}',
                    'evidence': '\n'.join([f'Missing: {h}' for h in missing]),
                    'cvss': 3.1,
                    'remediation': f'Add headers: {", ".join(missing)}'
                })
            
            # Check for sensitive info in headers
            if 'x-powered-by' in headers:
                self.log(self.scan_id, 
                    f"  ⚠️ X-Powered-By disclosed: {headers['x-powered-by']}", 
                    'warning', 'httpx')
                self.add_finding(self.scan_id, {
                    'type': 'Technology Disclosure',
                    'severity': 'info',
                    'target': url,
                    'description': f'X-Powered-By header discloses technology: {headers["x-powered-by"]}',
                    'evidence': f'X-Powered-By: {headers["x-powered-by"]}',
                    'cvss': 2.0,
                    'remediation': 'Remove X-Powered-By header from server responses'
                })
        except:
            pass

    def _tech_detect(self):
        self.log(self.scan_id, "🔬 Detecting technologies...", 'info', 'wappalyzer')
        
        try:
            r = requests.get(self.base_url, timeout=8, verify=False,
                             headers={'User-Agent': 'Mozilla/5.0 BugHunterPro/2.0'})
            techs = self._detect_tech_from_response(r)
            
            if techs:
                self.log(self.scan_id, f"  🛠️ Detected: {', '.join(techs)}", 'data', 'tech-detect')
        except:
            pass

    def _detect_tech_from_response(self, response):
        techs = []
        headers = {k.lower(): v for k, v in response.headers.items()}
        body = response.text.lower()
        
        # Server tech
        server = headers.get('server', '')
        if 'nginx' in server: techs.append('Nginx')
        if 'apache' in server: techs.append('Apache')
        if 'iis' in server: techs.append('IIS')
        
        # X-Powered-By
        xpb = headers.get('x-powered-by', '')
        if 'php' in xpb.lower(): techs.append('PHP')
        if 'asp.net' in xpb.lower(): techs.append('ASP.NET')
        if 'express' in xpb.lower(): techs.append('Express.js')
        
        # Framework detection from body
        if 'react' in body or '__react' in body: techs.append('React')
        if 'angular' in body or 'ng-version' in body: techs.append('Angular')
        if 'vue.js' in body or '__vue' in body: techs.append('Vue.js')
        if 'next.js' in body or '__next' in body: techs.append('Next.js')
        if 'wordpress' in body or 'wp-content' in body: techs.append('WordPress')
        if 'drupal' in body: techs.append('Drupal')
        if 'laravel' in body or 'laravel_session' in str(response.cookies): techs.append('Laravel')
        if 'django' in body or 'csrftoken' in str(response.cookies): techs.append('Django')
        if 'graphql' in body: techs.append('GraphQL')
        if 'swagger' in body or 'openapi' in body: techs.append('OpenAPI/Swagger')
        
        return list(set(techs))

    def _path_discovery(self):
        self.log(self.scan_id, "📂 Discovering paths and endpoints...", 'info', 'katana')
        
        common_paths = [
            '/api', '/api/v1', '/api/v2', '/api/v3',
            '/graphql', '/graphiql', '/playground',
            '/admin', '/administrator', '/wp-admin', '/dashboard',
            '/login', '/signin', '/auth', '/oauth',
            '/swagger', '/swagger-ui', '/api-docs', '/openapi.json',
            '/robots.txt', '/sitemap.xml', '/.git/HEAD', '/.env',
            '/config', '/configuration', '/settings',
            '/health', '/status', '/ping', '/version', '/info',
            '/debug', '/trace', '/actuator', '/actuator/env',
            '/metrics', '/prometheus', '/_admin',
            '/phpmyadmin', '/phpinfo.php',
            '/uploads', '/files', '/backup',
            '/server-status', '/server-info',
        ]
        
        def check_path(path):
            url = self.base_url + path
            try:
                r = requests.get(url, timeout=4, verify=False,
                                 allow_redirects=False,
                                 headers={'User-Agent': 'Mozilla/5.0 BugHunterPro/2.0'})
                return url, r.status_code, len(r.content)
            except:
                return url, 0, 0
        
        with ThreadPoolExecutor(max_workers=30) as executor:
            futures = {executor.submit(check_path, path): path for path in common_paths}
            for future in as_completed(futures):
                url, status, size = future.result()
                if status in [200, 301, 302, 403]:
                    self.endpoints.append({'url': url, 'status': status, 'size': size})
                    icon = '✅' if status == 200 else '⚠️'
                    self.log(self.scan_id, 
                        f"  {icon} [{status}] {url} ({size} bytes)", 
                        'data', 'katana')
                    
                    # Flag sensitive endpoints
                    for sensitive in ['.env', '.git', 'actuator', 'phpinfo', 'server-status']:
                        if sensitive in url and status == 200:
                            self.add_finding(self.scan_id, {
                                'type': 'Sensitive File Exposed',
                                'severity': 'high',
                                'target': url,
                                'description': f'Sensitive endpoint accessible: {url}',
                                'evidence': f'HTTP {status} - {size} bytes returned',
                                'cvss': 7.5,
                                'remediation': f'Restrict access to {url} via Nginx/server config'
                            })

    def _extract_title(self, html):
        import re
        match = re.search(r'<title[^>]*>(.*?)</title>', html, re.IGNORECASE | re.DOTALL)
        return match.group(1).strip()[:80] if match else 'No Title'
