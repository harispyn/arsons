#!/usr/bin/env python3
"""IDOR Scanner - Object & Field level IDOR detection"""
import requests
import time
from concurrent.futures import ThreadPoolExecutor, as_completed

class IDORScanner:
    def __init__(self, target, scan_id, socketio, log_fn, finding_fn):
        self.target = target.rstrip('/')
        self.scan_id = scan_id
        self.log = log_fn
        self.add_finding = finding_fn
        self.session = requests.Session()
        self.session.verify = False
        self.session.headers.update({'User-Agent': 'Mozilla/5.0 BugHunterPro/2.0'})

    def run(self):
        self.log(self.scan_id, "🔐 Testing IDOR vulnerabilities...", 'info', 'idor')
        
        # Test common IDOR endpoints
        api_patterns = [
            '/api/user/{id}',
            '/api/users/{id}',
            '/api/v1/user/{id}',
            '/api/v1/users/{id}',
            '/api/account/{id}',
            '/api/profile/{id}',
            '/api/orders/{id}',
            '/api/invoices/{id}',
            '/api/documents/{id}',
            '/api/files/{id}',
            '/api/messages/{id}',
            '/user/{id}',
            '/profile/{id}',
            '/account/{id}',
        ]
        
        test_ids = [1, 2, 3, 0, -1, 9999, 'admin', '../admin', '1 OR 1=1']
        
        for pattern in api_patterns:
            for test_id in test_ids[:5]:
                url = self.target + pattern.replace('{id}', str(test_id))
                try:
                    r = self.session.get(url, timeout=5)
                    if r.status_code == 200 and len(r.content) > 50:
                        # Check if sensitive data returned
                        body = r.text.lower()
                        sensitive_keys = ['email', 'username', 'password', 'token', 'phone', 'address', 'ssn']
                        found_keys = [k for k in sensitive_keys if k in body]
                        
                        if found_keys:
                            self.log(self.scan_id,
                                f"  🚨 Potential IDOR: {url} returns {found_keys}", 'warning', 'idor')
                            self.add_finding(self.scan_id, {
                                'type': 'IDOR',
                                'severity': 'high',
                                'target': url,
                                'description': f'Potential IDOR vulnerability - endpoint returns sensitive data with ID: {test_id}',
                                'evidence': f'URL: {url}\nStatus: {r.status_code}\nSensitive fields: {found_keys}\nResponse preview: {r.text[:300]}',
                                'cvss': 7.5,
                                'poc': f'curl -s "{url}" | jq .',
                                'remediation': 'Implement proper object-level authorization. Verify user owns the resource before returning data.',
                                'cwe': 'CWE-639'
                            })
                except:
                    pass
        
        # Test UUID enumeration
        self._test_uuid_idor()
        
        # Test parameter pollution
        self._test_param_pollution()
        
        self.log(self.scan_id, "  ✅ IDOR scan complete", 'info', 'idor')

    def _test_uuid_idor(self):
        import re
        self.log(self.scan_id, "  🔢 Testing UUID-based IDOR...", 'info', 'idor')
        
        # Try to get any UUID-based endpoint
        test_uuids = [
            '00000000-0000-0000-0000-000000000001',
            '00000000-0000-0000-0000-000000000002',
        ]
        
        uuid_endpoints = ['/api/v1/resource/{uuid}', '/data/{uuid}']
        for endpoint in uuid_endpoints:
            for uuid in test_uuids:
                url = self.target + endpoint.replace('{uuid}', uuid)
                try:
                    r = self.session.get(url, timeout=4)
                    if r.status_code in [200, 403]:
                        self.log(self.scan_id, f"  [{r.status_code}] UUID endpoint exists: {url}", 'data', 'idor')
                except:
                    pass

    def _test_param_pollution(self):
        self.log(self.scan_id, "  ⚡ Testing parameter pollution IDOR...", 'info', 'idor')
        
        test_cases = [
            f"{self.target}/api/user?id=1&id=2",
            f"{self.target}/api/user?user_id=1;user_id=2",
        ]
        
        for url in test_cases:
            try:
                r = self.session.get(url, timeout=4)
                if r.status_code == 200:
                    self.log(self.scan_id, f"  [INFO] Endpoint accepts: {url}", 'data', 'idor')
            except:
                pass
