#!/usr/bin/env python3
"""Report Generator"""
from scanners.poc_generator import ReportGenerator
