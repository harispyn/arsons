#!/usr/bin/env python3
"""
BugHunter Pro v2.1 - Full Integration Test Suite
"""
import json, sys, time, threading
import requests
requests.packages.urllib3.disable_warnings()

BASE = "http://127.0.0.1:5010"
PASS = 0; FAIL = 0

def ok(label):
    global PASS; PASS += 1
    print(f"  [PASS] {label}")

def fail(label, reason=""):
    global FAIL; FAIL += 1
    print(f"  [FAIL] {label}  →  {reason}")

def test(label, condition, reason=""):
    if condition:
        ok(label)
    else:
        fail(label, reason)

# ──────────────────────────
# 1. Import tests
# ──────────────────────────
print("\n=== 1. Import Tests ===")
try:
    from scanners.poc_generator import PoCGenerator, ReportGenerator
    from scanners.recon_engine import ReconEngine
    from scanners.idor_scanner import IDORScanner
    from scanners.xss_scanner import XSSScanner
    from scanners.ssrf_scanner import SSRFScanner
    from scanners.sqli_scanner import SQLiScanner
    from scanners.oauth_tester import OAuthTester, RaceConditionScanner, CVEHunter
    from scanners.race_condition import RaceConditionScanner as RCS
    from scanners.cve_hunter import CVEHunter as CH
    from scanners.report_generator import ReportGenerator as RG
    ok("All scanner imports")
except Exception as e:
    fail("Scanner imports", str(e)); sys.exit(1)

# ──────────────────────────
# 2. PoC Generator unit tests
# ──────────────────────────
print("\n=== 2. PoC Generator ===")
poc_types = ['xss','sqli','ssrf','idor','lfi','rce','xxe','ssti',
             'csrf','jwt_none','log4shell','open_redirect']

for vtype in poc_types:
    r = PoCGenerator.generate(vtype, "https://example.com", {})
    test(f"PoC {vtype}", 'error' not in r, r.get('error',''))

# Edge cases
test("PoC None type",    PoCGenerator.generate(None, "https://ex.com")['error'] == 'vuln_type is required')
test("PoC empty string", 'error' in PoCGenerator.generate('', 'https://ex.com'))
test("PoC unknown type", 'error' in PoCGenerator.generate('xyzzy', 'https://ex.com'))
test("PoC no target",    'error' not in PoCGenerator.generate('xss', None, {}))

# ──────────────────────────
# 3. Report Generator
# ──────────────────────────
print("\n=== 3. Report Generator ===")
sample_findings = [
    {'type': 'XSS', 'severity': 'high', 'target': 'https://ex.com', 'description': 'XSS test',
     'evidence': 'payload reflected', 'cvss': 7.4, 'cwe': 'CWE-79',
     'remediation': ['Use output encoding', 'Set CSP']},
    {'type': 'SQLi', 'severity': 'critical', 'target': 'https://ex.com/api',
     'description': 'SQL error', 'evidence': "You have an error in SQL", 'cvss': 9.8,
     'cwe': 'CWE-89', 'remediation': 'Use parameterized queries'},
]

for fmt in ['hackerone', 'bugcrowd', 'markdown', 'json']:
    r = ReportGenerator.generate("test123", sample_findings, {'target':'https://ex.com'}, fmt)
    test(f"Report {fmt}", 'error' not in r, r.get('error',''))

test("Report unknown fmt", 'error' in ReportGenerator.generate("x", [], {}, 'invalid'))
test("Report empty findings", 'error' not in ReportGenerator.generate("x", [], {'target':'t'}, 'json'))
test("Report None findings",  'error' not in ReportGenerator.generate("x", None, {}, 'json'))

# ──────────────────────────
# 4. Flask API tests
# ──────────────────────────
print("\n=== 4. Flask API Tests ===")

# Start server
import subprocess, os, signal
srv = subprocess.Popen(
    ["python3", "app.py"],
    env={**os.environ, "PORT": "5010", "HOST": "127.0.0.1"},
    stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL
)
time.sleep(2)

try:
    def get(path, **kw):
        return requests.get(BASE+path, timeout=5, **kw)
    def post(path, data=None, **kw):
        return requests.post(BASE+path, json=data, timeout=5, **kw)

    # Health
    r = get("/health")
    test("/health status 200", r.status_code == 200)
    test("/health version 2.1.0", r.json().get('version') == '2.1.0')

    # Stats
    r = get("/api/stats")
    test("/api/stats 200", r.status_code == 200)
    test("/api/stats has total_scans", 'total_scans' in r.json())

    # Scan list (empty)
    r = get("/api/scan/list")
    test("/api/scan/list 200", r.status_code == 200)
    test("/api/scan/list is list", isinstance(r.json(), list))

    # Findings all (empty)
    r = get("/api/findings/all")
    test("/api/findings/all 200", r.status_code == 200)
    test("/api/findings/all is list", isinstance(r.json(), list))

    # Static route vs dynamic collision
    r = get("/api/findings/all")
    test("/api/findings/all not 404", r.status_code != 404)

    # Start scan - no body
    r = requests.post(BASE+"/api/scan/start", timeout=5)
    test("Start scan - no body returns 400", r.status_code == 400)

    # Start scan - no target
    r = post("/api/scan/start", {})
    test("Start scan - no target returns 400", r.status_code == 400)

    # Start scan - invalid target
    r = post("/api/scan/start", {"target": "notaurl"})
    test("Start scan - invalid target 400", r.status_code == 400)

    # Start scan - valid
    r = post("/api/scan/start", {"target": "https://example.com", "scan_types": ["recon"]})
    test("Start scan - valid 200", r.status_code == 200)
    data = r.json()
    test("Start scan returns scan_id", 'scan_id' in data)
    scan_id = data.get('scan_id', 'x')

    # Scan status
    r = get(f"/api/scan/status/{scan_id}")
    test("Scan status 200", r.status_code == 200)

    # Stop scan
    r = post(f"/api/scan/stop/{scan_id}")
    test("Stop scan 200", r.status_code == 200)

    # Stop non-existent
    r = post("/api/scan/stop/XXXXXXXX")
    test("Stop nonexistent scan 404", r.status_code == 404)

    # Findings for scan
    r = get(f"/api/findings/{scan_id}")
    test("Get findings 200", r.status_code in [200, 404])

    # Findings not found
    r = get("/api/findings/XXXXXXXX")
    test("Findings nonexistent 404", r.status_code == 404)

    # PoC generate
    r = post("/api/poc/generate", {"type": "xss", "target": "https://example.com"})
    test("PoC generate XSS 200", r.status_code == 200)
    test("PoC generate XSS has payloads", 'payloads' in r.json())

    r = post("/api/poc/generate", {"type": "sqli", "target": "https://example.com"})
    test("PoC generate SQLi 200", r.status_code == 200)

    # PoC generate - no type
    r = post("/api/poc/generate", {"target": "https://example.com"})
    test("PoC generate - no type 400", r.status_code == 400)

    # PoC generate - unknown type
    r = post("/api/poc/generate", {"type": "unknownxyz"})
    test("PoC generate - unknown type 400", r.status_code == 400)

    # PoC generate - no body
    r = requests.post(BASE+"/api/poc/generate", timeout=5)
    test("PoC generate - no body 400", r.status_code == 400)

    # PoC types
    r = get("/api/poc/types")
    test("PoC types 200", r.status_code == 200)
    test("PoC types is list with 12", len(r.json()) == 12)

    # Report generate
    r = post("/api/report/generate", {"scan_id": scan_id, "format": "json"})
    test("Report generate 200", r.status_code == 200)

    r = post("/api/report/generate", {"scan_id": scan_id, "format": "markdown"})
    test("Report markdown 200", r.status_code == 200)

    r = post("/api/report/generate", {})
    test("Report - no scan_id 400", r.status_code == 400)

    r = post("/api/report/generate", {"scan_id": "XXXXXXXX"})
    test("Report - nonexistent scan 404", r.status_code == 404)

    # Payloads
    r = get("/api/payloads")
    test("Payloads 200", r.status_code == 200)
    test("Payloads has xss", 'xss' in r.json())

    r = get("/api/payloads/xss")
    test("Payloads/xss 200", r.status_code == 200)

    r = get("/api/payloads/xxxxxxxxx")
    test("Payloads/unknown 404", r.status_code == 404)

    # Targets
    r = get("/api/targets")
    test("Targets list 200", r.status_code == 200)
    test("Targets is list", isinstance(r.json(), list))

    r = post("/api/targets", {"target": "https://example.com", "label": "Test Target"})
    test("Add target 201", r.status_code == 201)
    tid = r.json().get('id', '')

    r = get("/api/targets")
    test("Targets list not empty after add", len(r.json()) > 0)

    r = requests.delete(BASE+f"/api/targets/{tid}", timeout=5)
    test("Delete target 200", r.status_code == 200)

    r = requests.delete(BASE+f"/api/targets/XXXXXXXX", timeout=5)
    test("Delete nonexistent target 404", r.status_code == 404)

    r = post("/api/targets", {})
    test("Add target - no target field 400", r.status_code == 400)

    # Main UI
    r = get("/")
    test("Main UI 200", r.status_code == 200)
    test("Main UI HTML", 'text/html' in r.headers.get('Content-Type', ''))

finally:
    srv.terminate()
    try:
        srv.wait(timeout=3)
    except Exception:
        srv.kill()

# ──────────────────────────
# Summary
# ──────────────────────────
total = PASS + FAIL
print(f"\n{'='*50}")
print(f"  Results: {PASS}/{total} passed, {FAIL} failed")
print(f"{'='*50}\n")
sys.exit(0 if FAIL == 0 else 1)
