#!/bin/bash
# ═══════════════════════════════════════════════════════════
# BugHunter Pro - Automated Installation Script
# ═══════════════════════════════════════════════════════════
# For authorized security testing only.
# Run as: chmod +x install.sh && sudo ./install.sh

set -e

RED='\033[0;31m'
GREEN='\033[0;32m'
CYAN='\033[0;36m'
YELLOW='\033[1;33m'
NC='\033[0m'

INSTALL_DIR="/opt/bughunter-pro"
SERVICE_USER="bughunter"
NGINX_CONF="/etc/nginx/sites-available/bughunter"

echo -e "${CYAN}"
cat << 'EOF'
  ╔══════════════════════════════════════════════╗
  ║   BugHunter Pro - Installation Script       ║
  ║   Professional Bug Bounty Platform v2.0     ║
  ║   ⚠ Authorized testing only!               ║
  ╚══════════════════════════════════════════════╝
EOF
echo -e "${NC}"

# Check root
if [[ $EUID -ne 0 ]]; then
   echo -e "${RED}[✗] This script must be run as root${NC}"
   exit 1
fi

echo -e "${GREEN}[+]${NC} Detected OS: $(uname -s) $(uname -r)"

# ─────────────────────────────────────────────
# 1. Install System Dependencies
# ─────────────────────────────────────────────
echo -e "\n${CYAN}[1/8] Installing system dependencies...${NC}"

if command -v apt-get &> /dev/null; then
    apt-get update -qq
    apt-get install -y -qq \
        python3 python3-pip python3-venv \
        nginx curl wget git jq \
        golang-go nodejs npm \
        nmap dnsutils whois \
        libssl-dev build-essential
elif command -v yum &> /dev/null; then
    yum install -y -q \
        python3 python3-pip nginx curl wget git jq golang nodejs npm \
        nmap bind-utils openssl-devel
fi

echo -e "${GREEN}[✓]${NC} System dependencies installed"

# ─────────────────────────────────────────────
# 2. Create User and Directory
# ─────────────────────────────────────────────
echo -e "\n${CYAN}[2/8] Setting up user and directories...${NC}"

useradd -r -s /bin/false $SERVICE_USER 2>/dev/null || true
mkdir -p $INSTALL_DIR
cp -r ./* $INSTALL_DIR/
chown -R $SERVICE_USER:$SERVICE_USER $INSTALL_DIR

mkdir -p $INSTALL_DIR/{findings,reports,recon,wordlists,logs}
chmod 750 $INSTALL_DIR
echo -e "${GREEN}[✓]${NC} Directory: $INSTALL_DIR"

# ─────────────────────────────────────────────
# 3. Python Virtual Environment
# ─────────────────────────────────────────────
echo -e "\n${CYAN}[3/8] Setting up Python environment...${NC}"

cd $INSTALL_DIR
python3 -m venv venv
source venv/bin/activate
pip install --quiet --upgrade pip
pip install --quiet -r requirements.txt

echo -e "${GREEN}[✓]${NC} Python venv ready"

# ─────────────────────────────────────────────
# 4. Install Go Security Tools
# ─────────────────────────────────────────────
echo -e "\n${CYAN}[4/8] Installing security tools...${NC}"

export GOPATH=$HOME/go
export PATH=$PATH:$GOPATH/bin

GO_TOOLS=(
    "github.com/projectdiscovery/subfinder/v2/cmd/subfinder@latest"
    "github.com/projectdiscovery/httpx/cmd/httpx@latest"
    "github.com/projectdiscovery/dnsx/cmd/dnsx@latest"
    "github.com/projectdiscovery/nuclei/v3/cmd/nuclei@latest"
    "github.com/projectdiscovery/katana/cmd/katana@latest"
    "github.com/tomnomnom/waybackurls@latest"
    "github.com/lc/gau/v2/cmd/gau@latest"
    "github.com/tomnomnom/anew@latest"
    "github.com/hahwul/dalfox/v2@latest"
    "github.com/ffuf/ffuf/v2@latest"
    "github.com/tomnomnom/assetfinder@latest"
)

for tool in "${GO_TOOLS[@]}"; do
    tool_name=$(echo $tool | rev | cut -d/ -f1 | rev | cut -d@ -f1)
    echo -ne "  Installing $tool_name..."
    if go install $tool 2>/dev/null; then
        echo -e " ${GREEN}✓${NC}"
    else
        echo -e " ${YELLOW}⚠ skipped${NC}"
    fi
done

# Update nuclei templates
if command -v nuclei &> /dev/null; then
    nuclei -update-templates 2>/dev/null || true
    echo -e "${GREEN}[✓]${NC} Nuclei templates updated"
fi

# ─────────────────────────────────────────────
# 5. Generate SSL Certificates
# ─────────────────────────────────────────────
echo -e "\n${CYAN}[5/8] Generating SSL certificates...${NC}"

mkdir -p /etc/ssl/bughunter
if [ ! -f /etc/ssl/bughunter/cert.pem ]; then
    openssl req -x509 -nodes -days 365 -newkey rsa:2048 \
        -keyout /etc/ssl/bughunter/key.pem \
        -out /etc/ssl/bughunter/cert.pem \
        -subj "/C=US/ST=Security/L=BugBounty/O=BugHunterPro/CN=bughunter.local" 2>/dev/null

    openssl dhparam -out /etc/ssl/bughunter/dhparam.pem 2048 2>/dev/null
    chmod 600 /etc/ssl/bughunter/*.pem
    echo -e "${GREEN}[✓]${NC} Self-signed SSL certificates generated"
fi

# ─────────────────────────────────────────────
# 6. Configure Nginx
# ─────────────────────────────────────────────
echo -e "\n${CYAN}[6/8] Configuring Nginx...${NC}"

cp $INSTALL_DIR/nginx.conf $NGINX_CONF
ln -sf $NGINX_CONF /etc/nginx/sites-enabled/bughunter 2>/dev/null || true

# Remove default site if exists
rm -f /etc/nginx/sites-enabled/default

# Test nginx config
if nginx -t 2>/dev/null; then
    systemctl restart nginx
    echo -e "${GREEN}[✓]${NC} Nginx configured and restarted"
else
    echo -e "${YELLOW}[⚠]${NC} Nginx config test failed. Check manually: nginx -t"
fi

# ─────────────────────────────────────────────
# 7. Create Systemd Service
# ─────────────────────────────────────────────
echo -e "\n${CYAN}[7/8] Creating systemd service...${NC}"

cat > /etc/systemd/system/bughunter-pro.service << EOF
[Unit]
Description=BugHunter Pro - Bug Bounty Platform
After=network.target
Requires=network.target

[Service]
Type=simple
User=$SERVICE_USER
Group=$SERVICE_USER
WorkingDirectory=$INSTALL_DIR
ExecStart=$INSTALL_DIR/venv/bin/python $INSTALL_DIR/app.py
Restart=always
RestartSec=5
StandardOutput=append:$INSTALL_DIR/logs/app.log
StandardError=append:$INSTALL_DIR/logs/error.log

# Security hardening
NoNewPrivileges=yes
PrivateTmp=yes
ProtectSystem=strict
ReadWritePaths=$INSTALL_DIR
ProtectHome=yes

# Environment
Environment="PYTHONPATH=$INSTALL_DIR"
Environment="FLASK_ENV=production"

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
systemctl enable bughunter-pro
systemctl start bughunter-pro

echo -e "${GREEN}[✓]${NC} Service installed and started"

# ─────────────────────────────────────────────
# 8. Firewall Rules
# ─────────────────────────────────────────────
echo -e "\n${CYAN}[8/8] Configuring firewall...${NC}"

if command -v ufw &> /dev/null; then
    ufw allow 80/tcp comment "BugHunter HTTP" 2>/dev/null || true
    ufw allow 443/tcp comment "BugHunter HTTPS" 2>/dev/null || true
    ufw --force enable 2>/dev/null || true
    echo -e "${GREEN}[✓]${NC} UFW rules applied"
elif command -v firewall-cmd &> /dev/null; then
    firewall-cmd --permanent --add-service=http 2>/dev/null || true
    firewall-cmd --permanent --add-service=https 2>/dev/null || true
    firewall-cmd --reload 2>/dev/null || true
    echo -e "${GREEN}[✓]${NC} Firewalld rules applied"
fi

# ─────────────────────────────────────────────
# Done!
# ─────────────────────────────────────────────
echo -e "\n${GREEN}"
cat << 'EOF'
  ════════════════════════════════════════════════
  ✅  BugHunter Pro Installation Complete!
  ════════════════════════════════════════════════
EOF
echo -e "${NC}"

LOCAL_IP=$(hostname -I | awk '{print $1}')
echo -e "  ${CYAN}Web UI:${NC}    https://$LOCAL_IP"
echo -e "  ${CYAN}Local:${NC}     https://localhost"
echo -e "  ${CYAN}HTTP:${NC}      http://$LOCAL_IP (redirects to HTTPS)"
echo -e ""
echo -e "  ${CYAN}Service:${NC}   systemctl status bughunter-pro"
echo -e "  ${CYAN}Logs:${NC}      $INSTALL_DIR/logs/app.log"
echo -e "  ${CYAN}Nginx:${NC}     /var/log/nginx/bughunter_access.log"
echo -e ""
echo -e "  ${YELLOW}⚠  FOR AUTHORIZED SECURITY TESTING ONLY${NC}"
echo -e "  ${YELLOW}⚠  Accept SSL warning in browser (self-signed)${NC}"
echo ""
