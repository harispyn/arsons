#!/bin/bash

# ============================================
# Environment Setup and Checker
# Penetration Testing Framework
# ============================================

echo "╔══════════════════════════════════════════════════════════════╗"
echo "║        PENETRATION TESTING FRAMEWORK                         ║"
echo "║           Environment Setup & Checker                        ║"
echo "╚══════════════════════════════════════════════════════════════╝"
echo ""

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Check functions
check_command() {
    if command -v $1 &> /dev/null; then
        echo -e "${GREEN}✓${NC} $1 is installed"
        return 0
    else
        echo -e "${RED}✗${NC} $1 is NOT installed"
        return 1
    fi
}

check_python_module() {
    if python3 -c "import $1" 2>/dev/null; then
        echo -e "${GREEN}✓${NC} Python module '$1' is installed"
        return 0
    else
        echo -e "${RED}✗${NC} Python module '$1' is NOT installed"
        return 1
    fi
}

# Main check
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "Checking Required Dependencies..."
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""

MISSING_DEPS=0

# Check Python
if check_command python3; then
    PYTHON_VERSION=$(python3 --version | cut -d' ' -f2)
    echo "  Version: $PYTHON_VERSION"
else
    MISSING_DEPS=$((MISSING_DEPS + 1))
fi
echo ""

# Check pip
if check_command pip3; then
    PIP_VERSION=$(pip3 --version | cut -d' ' -f2)
    echo "  Version: $PIP_VERSION"
else
    MISSING_DEPS=$((MISSING_DEPS + 1))
fi
echo ""

# Check Python modules
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "Checking Python Modules..."
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""

check_python_module requests || MISSING_DEPS=$((MISSING_DEPS + 1))
check_python_module bs4 || MISSING_DEPS=$((MISSING_DEPS + 1))
check_python_module urllib3 || MISSING_DEPS=$((MISSING_DEPS + 1))
echo ""

# Check optional tools
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "Checking Optional Security Tools..."
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""

check_command curl
check_command wget
check_command nmap
check_command nikto
check_command sqlmap
echo ""

# Check scripts
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "Checking Framework Scripts..."
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""

SCRIPTS=(
    "pentest_comprehensive.py"
    "advanced_sqli_test.py"
    "advanced_xss_scanner.py"
    "csrf_tester.py"
    "api_security_test.py"
    "run_pentest.sh"
)

for script in "${SCRIPTS[@]}"; do
    if [ -f "$script" ]; then
        if [ -x "$script" ]; then
            echo -e "${GREEN}✓${NC} $script (executable)"
        else
            echo -e "${YELLOW}⚠${NC} $script (not executable)"
            chmod +x "$script" 2>/dev/null && echo -e "  ${GREEN}→${NC} Made executable"
        fi
    else
        echo -e "${RED}✗${NC} $script (missing)"
        MISSING_DEPS=$((MISSING_DEPS + 1))
    fi
done
echo ""

# Summary and actions
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "Summary"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""

if [ $MISSING_DEPS -eq 0 ]; then
    echo -e "${GREEN}✓ All required dependencies are installed!${NC}"
    echo ""
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    echo "Ready to test!"
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    echo ""
    echo "Quick Start:"
    echo "  ./run_pentest.sh http://localhost:8080"
    echo ""
    echo "Individual Tools:"
    echo "  python3 pentest_comprehensive.py http://target"
    echo "  python3 advanced_sqli_test.py 'http://target/page.php?id=1'"
    echo "  python3 advanced_xss_scanner.py http://target"
    echo "  python3 csrf_tester.py http://target"
    echo "  python3 api_security_test.py http://target:8080"
    echo ""
    echo "Documentation:"
    echo "  cat README.md"
    echo "  cat TESTING_GUIDE.md"
    echo ""
else
    echo -e "${RED}✗ Missing $MISSING_DEPS dependencies${NC}"
    echo ""
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    echo "Installation Instructions"
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    echo ""
    echo "1. Install Python dependencies:"
    echo -e "   ${BLUE}pip3 install requests beautifulsoup4 urllib3${NC}"
    echo ""
    echo "2. Install optional tools (Ubuntu/Debian):"
    echo -e "   ${BLUE}sudo apt update${NC}"
    echo -e "   ${BLUE}sudo apt install -y curl wget nmap nikto sqlmap${NC}"
    echo ""
    echo "3. Re-run this checker:"
    echo -e "   ${BLUE}./setup_check.sh${NC}"
    echo ""
    
    # Offer automatic installation
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    read -p "Install missing Python dependencies automatically? (yes/no): " AUTO_INSTALL
    
    if [ "$AUTO_INSTALL" = "yes" ]; then
        echo ""
        echo "Installing Python dependencies..."
        pip3 install requests beautifulsoup4 urllib3
        
        echo ""
        echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
        echo "Installation complete!"
        echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
        echo ""
        echo "Run this checker again to verify:"
        echo "  ./setup_check.sh"
    fi
fi

echo ""

# Test connectivity
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "Network Connectivity Test"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""

if ping -c 1 8.8.8.8 &> /dev/null; then
    echo -e "${GREEN}✓${NC} Internet connectivity: OK"
else
    echo -e "${RED}✗${NC} Internet connectivity: Failed"
    echo "  Note: Some tests may not work without internet"
fi

echo ""

# Disk space check
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "Disk Space Check"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""

DISK_SPACE=$(df -h . | awk 'NR==2 {print $4}')
echo "Available disk space: $DISK_SPACE"

if [ $(df . | awk 'NR==2 {print $4}') -lt 1000000 ]; then
    echo -e "${YELLOW}⚠${NC} Warning: Low disk space (< 1GB)"
    echo "  Results may require significant space"
fi

echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "Setup check complete!"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
