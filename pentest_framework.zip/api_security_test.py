#!/usr/bin/env python3
"""
API Security Testing Tool
Tests: Authentication, Authorization, Rate Limiting, Input Validation
"""

import requests
import json
import time
import urllib3
from urllib.parse import urljoin

urllib3.disable_warnings()

class APISecurityTester:
    def __init__(self, base_url, api_key=None):
        self.base_url = base_url.rstrip('/')
        self.api_key = api_key
        self.session = requests.Session()
        self.session.verify = False
        
        if api_key:
            self.session.headers.update({
                'Authorization': f'Bearer {api_key}',
                'X-API-Key': api_key
            })
    
    def test_authentication_bypass(self):
        """Test authentication bypass vulnerabilities"""
        print("\n[*] Testing Authentication Bypass...")
        
        # Common API endpoints
        endpoints = [
            '/api/users',
            '/api/v1/users',
            '/api/v2/users',
            '/api/admin/users',
            '/api/user/profile',
            '/api/admin/settings',
            '/api/config',
            '/api/logs',
        ]
        
        vulnerabilities = []
        
        for endpoint in endpoints:
            url = urljoin(self.base_url, endpoint)
            
            # Test without authentication
            headers_no_auth = {'User-Agent': 'API-Tester'}
            
            try:
                response = self.session.get(url, headers=headers_no_auth, timeout=10)
                
                if response.status_code == 200:
                    print(f"[!] VULNERABLE: {url}")
                    print(f"    Status: {response.status_code}")
                    print(f"    Accessible without authentication!")
                    
                    vulnerabilities.append({
                        'endpoint': url,
                        'issue': 'No authentication required',
                        'severity': 'CRITICAL'
                    })
                    
                    # Try to parse response
                    try:
                        data = response.json()
                        print(f"    Data exposed: {len(json.dumps(data))} chars")
                    except:
                        pass
            
            except Exception as e:
                continue
        
        return vulnerabilities
    
    def test_authorization_bypass(self):
        """Test authorization bypass (IDOR)"""
        print("\n[*] Testing Authorization Bypass (IDOR)...")
        
        # Test user enumeration
        user_endpoints = [
            '/api/user/1',
            '/api/user/2',
            '/api/users/1',
            '/api/users/2',
            '/api/v1/user/1',
            '/api/v1/user/2',
        ]
        
        vulnerabilities = []
        
        for endpoint in user_endpoints:
            url = urljoin(self.base_url, endpoint)
            
            try:
                response = self.session.get(url, timeout=10)
                
                if response.status_code == 200:
                    print(f"[!] Potential IDOR: {url}")
                    print(f"    Status: {response.status_code}")
                    
                    try:
                        data = response.json()
                        print(f"    Data returned: {list(data.keys())}")
                        
                        vulnerabilities.append({
                            'endpoint': url,
                            'issue': 'Potential IDOR - user data accessible',
                            'severity': 'HIGH'
                        })
                    except:
                        pass
            
            except Exception as e:
                continue
        
        return vulnerabilities
    
    def test_rate_limiting(self):
        """Test rate limiting"""
        print("\n[*] Testing Rate Limiting...")
        
        test_url = urljoin(self.base_url, '/api/login')
        
        # Send multiple requests
        num_requests = 100
        successful_requests = 0
        
        print(f"    Sending {num_requests} requests...")
        
        start_time = time.time()
        
        for i in range(num_requests):
            try:
                response = self.session.post(
                    test_url,
                    json={'username': 'test', 'password': 'test'},
                    timeout=5
                )
                
                if response.status_code != 429:  # 429 = Too Many Requests
                    successful_requests += 1
            except:
                pass
        
        elapsed_time = time.time() - start_time
        
        print(f"    Completed {successful_requests}/{num_requests} requests")
        print(f"    Time: {elapsed_time:.2f}s")
        print(f"    Rate: {successful_requests/elapsed_time:.2f} req/s")
        
        if successful_requests == num_requests:
            print(f"[!] VULNERABLE: No rate limiting detected!")
            return {
                'vulnerable': True,
                'severity': 'HIGH',
                'details': f'{num_requests} requests succeeded without rate limiting'
            }
        elif successful_requests > num_requests * 0.8:
            print(f"[!] WEAK: Rate limiting is insufficient")
            return {
                'vulnerable': True,
                'severity': 'MEDIUM',
                'details': f'{successful_requests}/{num_requests} requests succeeded'
            }
        else:
            print(f"[+] Rate limiting appears to be in place")
            return {
                'vulnerable': False,
                'severity': 'INFO'
            }
    
    def test_http_methods(self):
        """Test HTTP method tampering"""
        print("\n[*] Testing HTTP Methods...")
        
        test_url = urljoin(self.base_url, '/api/users/1')
        methods = ['GET', 'POST', 'PUT', 'DELETE', 'PATCH', 'HEAD', 'OPTIONS']
        
        allowed_methods = []
        vulnerabilities = []
        
        for method in methods:
            try:
                response = self.session.request(method, test_url, timeout=10)
                
                if response.status_code not in [404, 405, 501]:
                    allowed_methods.append(method)
                    print(f"    {method}: {response.status_code}")
                    
                    # Check if destructive methods are allowed
                    if method in ['DELETE', 'PUT', 'PATCH'] and response.status_code in [200, 204]:
                        vulnerabilities.append({
                            'method': method,
                            'endpoint': test_url,
                            'issue': f'{method} method allowed without proper authorization',
                            'severity': 'HIGH'
                        })
            except:
                pass
        
        print(f"\n    Allowed methods: {allowed_methods}")
        
        return vulnerabilities
    
    def test_mass_assignment(self):
        """Test mass assignment vulnerability"""
        print("\n[*] Testing Mass Assignment...")
        
        test_url = urljoin(self.base_url, '/api/user/profile')
        
        # Attempt to modify privileged fields
        payloads = [
            {'role': 'admin'},
            {'is_admin': True},
            {'admin': True},
            {'role': 'administrator'},
            {'privileges': ['admin']},
            {'user_role': 'admin'},
        ]
        
        vulnerabilities = []
        
        for payload in payloads:
            try:
                response = self.session.put(test_url, json=payload, timeout=10)
                
                if response.status_code in [200, 204]:
                    print(f"[!] Potential Mass Assignment!")
                    print(f"    Payload: {payload}")
                    print(f"    Status: {response.status_code}")
                    
                    vulnerabilities.append({
                        'endpoint': test_url,
                        'payload': payload,
                        'issue': 'Privileged field modification possible',
                        'severity': 'CRITICAL'
                    })
            except:
                pass
        
        return vulnerabilities
    
    def test_injection_in_api(self):
        """Test injection vulnerabilities in API"""
        print("\n[*] Testing Injection Vulnerabilities...")
        
        endpoints = [
            '/api/search?q=',
            '/api/users?name=',
            '/api/products?id=',
        ]
        
        # Injection payloads
        payloads = {
            'SQL Injection': ["' OR '1'='1", "1' UNION SELECT NULL--"],
            'NoSQL Injection': ['{"$ne": null}', '{"$gt": ""}'],
            'Command Injection': ['; ls -la', '| whoami'],
            'LDAP Injection': ['*)(uid=*))(|(uid=*', '*'],
        }
        
        vulnerabilities = []
        
        for endpoint in endpoints:
            for injection_type, injection_payloads in payloads.items():
                for payload in injection_payloads:
                    test_url = urljoin(self.base_url, endpoint + payload)
                    
                    try:
                        response = self.session.get(test_url, timeout=10)
                        
                        # Check for errors
                        error_keywords = ['error', 'syntax', 'exception', 'stack trace']
                        
                        if any(keyword in response.text.lower() for keyword in error_keywords):
                            print(f"[!] Potential {injection_type}")
                            print(f"    URL: {test_url}")
                            
                            vulnerabilities.append({
                                'type': injection_type,
                                'endpoint': endpoint,
                                'payload': payload,
                                'severity': 'CRITICAL'
                            })
                    except:
                        pass
        
        return vulnerabilities
    
    def test_api_versioning(self):
        """Test API versioning security"""
        print("\n[*] Testing API Versioning...")
        
        versions = ['v1', 'v2', 'v3', 'v1.0', 'v2.0', '1', '2', '3']
        endpoint = '/api/{version}/users'
        
        accessible_versions = []
        
        for version in versions:
            test_url = urljoin(self.base_url, endpoint.format(version=version))
            
            try:
                response = self.session.get(test_url, timeout=10)
                
                if response.status_code == 200:
                    accessible_versions.append(version)
                    print(f"    Version {version}: Accessible")
            except:
                pass
        
        if len(accessible_versions) > 1:
            print(f"[!] Multiple API versions accessible: {accessible_versions}")
            print(f"    Old versions may contain known vulnerabilities")
            return {
                'versions': accessible_versions,
                'issue': 'Multiple API versions accessible',
                'severity': 'MEDIUM'
            }
        
        return None
    
    def test_api_documentation_exposure(self):
        """Test for exposed API documentation"""
        print("\n[*] Testing API Documentation Exposure...")
        
        doc_endpoints = [
            '/api/docs',
            '/api/swagger',
            '/swagger',
            '/swagger-ui',
            '/api/swagger-ui',
            '/swagger.json',
            '/api/swagger.json',
            '/api-docs',
            '/documentation',
            '/graphql',
            '/graphiql',
        ]
        
        exposed_docs = []
        
        for endpoint in doc_endpoints:
            test_url = urljoin(self.base_url, endpoint)
            
            try:
                response = self.session.get(test_url, timeout=10)
                
                if response.status_code == 200:
                    print(f"[!] Documentation exposed: {test_url}")
                    exposed_docs.append(test_url)
            except:
                pass
        
        if exposed_docs:
            return {
                'endpoints': exposed_docs,
                'issue': 'API documentation publicly accessible',
                'severity': 'LOW'
            }
        
        return None
    
    def run_all_tests(self):
        """Run all API security tests"""
        print(f"\n{'='*60}")
        print(f"API SECURITY TESTING")
        print(f"Target: {self.base_url}")
        print(f"{'='*60}")
        
        results = {
            'authentication_bypass': [],
            'authorization_bypass': [],
            'rate_limiting': {},
            'http_methods': [],
            'mass_assignment': [],
            'injection': [],
            'versioning': None,
            'documentation': None
        }
        
        # Run tests
        results['authentication_bypass'] = self.test_authentication_bypass()
        results['authorization_bypass'] = self.test_authorization_bypass()
        results['rate_limiting'] = self.test_rate_limiting()
        results['http_methods'] = self.test_http_methods()
        results['mass_assignment'] = self.test_mass_assignment()
        results['injection'] = self.test_injection_in_api()
        results['versioning'] = self.test_api_versioning()
        results['documentation'] = self.test_api_documentation_exposure()
        
        # Summary
        print(f"\n{'='*60}")
        print("SUMMARY")
        print(f"{'='*60}")
        
        total_issues = 0
        
        for key, value in results.items():
            if isinstance(value, list):
                count = len(value)
                if count > 0:
                    print(f"{key}: {count} issue(s) found")
                    total_issues += count
            elif isinstance(value, dict) and value:
                if value.get('vulnerable') or value.get('issue'):
                    print(f"{key}: Issue found")
                    total_issues += 1
        
        print(f"\nTotal issues: {total_issues}")
        
        return results


if __name__ == "__main__":
    import sys
    
    if len(sys.argv) < 2:
        print("Usage: python3 api_security_test.py <base_url> [api_key]")
        print("\nExamples:")
        print("  python3 api_security_test.py http://localhost:8080")
        print("  python3 api_security_test.py http://localhost:8080 your_api_key_here")
        sys.exit(1)
    
    base_url = sys.argv[1]
    api_key = sys.argv[2] if len(sys.argv) > 2 else None
    
    tester = APISecurityTester(base_url, api_key)
    tester.run_all_tests()
