#!/bin/bash

# ============================================
# ZIPAY ADMIN PENETRATION TESTING GUIDE
# Khusus untuk admin.zipay.id
# ============================================

echo "╔══════════════════════════════════════════════════════════════╗"
echo "║         ZIPAY ADMIN SECURITY TESTING GUIDE                   ║"
echo "╚══════════════════════════════════════════════════════════════╝"
echo ""

# Target
TARGET_BASE="https://admin.zipay.id"

echo "⚠️  IMPORTANT NOTICES:"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""
echo "1. ⚠️  Ini adalah PRODUCTION system dengan data real"
echo "2. ⚠️  Backup database sebelum testing"
echo "3. ⚠️  Test di OFF-PEAK hours (malam/weekend)"
echo "4. ⚠️  Inform tim development sebelum testing"
echo "5. ⚠️  Siapkan rollback plan jika ada masalah"
echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""

read -p "Apakah sudah backup dan ready untuk test? (yes/no): " READY

if [ "$READY" != "yes" ]; then
    echo "❌ Testing dibatalkan. Silakan backup dulu!"
    exit 1
fi

echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "PHASE 1: RECONNAISSANCE (Passive - Aman)"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""

# 1. Check security headers (safe)
echo "[*] Checking Security Headers..."
curl -I "$TARGET_BASE" 2>/dev/null | grep -E "(X-Frame-Options|X-Content-Type-Options|Strict-Transport-Security|Content-Security-Policy)"
echo ""

# 2. Check robots.txt (safe)
echo "[*] Checking robots.txt..."
curl -s "$TARGET_BASE/robots.txt" 2>/dev/null | head -20
echo ""

# 3. Check common endpoints (safe)
echo "[*] Checking common endpoints..."
for endpoint in "/api" "/api/v1" "/api/docs" "/swagger" "/graphql"; do
    STATUS=$(curl -s -o /dev/null -w "%{http_code}" "$TARGET_BASE$endpoint")
    echo "  $endpoint: HTTP $STATUS"
done
echo ""

echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "PHASE 2: AUTHENTICATED TESTING (Perlu login)"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""
echo "ℹ️  Untuk testing lebih dalam, jalankan tools dengan session cookie:"
echo ""
echo "1. Login ke admin.zipay.id di browser"
echo "2. Buka Developer Tools (F12)"
echo "3. Copy session cookie/token"
echo "4. Run tools dengan authentication"
echo ""

# Create testing script with authentication
cat > test_authenticated.sh << 'EOF'
#!/bin/bash

# Set your session cookie here
SESSION_COOKIE="your_session_cookie_here"
API_TOKEN="your_api_token_here"

TARGET="https://admin.zipay.id"

# Test API dengan authentication
echo "[*] Testing authenticated endpoints..."

# Example: Test user profile endpoint
curl -H "Cookie: $SESSION_COOKIE" \
     -H "Authorization: Bearer $API_TOKEN" \
     "$TARGET/api/user/profile"

echo ""
echo "[*] Testing CSRF protection..."

# Check if forms have CSRF tokens
curl -H "Cookie: $SESSION_COOKIE" "$TARGET/app/dashboard" | grep -i "csrf"

echo ""
echo "[*] Testing authorization (IDOR)..."

# Test if you can access other users' data
curl -H "Cookie: $SESSION_COOKIE" "$TARGET/api/user/1"
curl -H "Cookie: $SESSION_COOKIE" "$TARGET/api/user/2"

EOF

chmod +x test_authenticated.sh
echo "✅ Created: test_authenticated.sh"
echo ""

echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "PHASE 3: SAFE AUTOMATED TESTING"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""

cat > safe_zipay_test.py << 'PYTHON_EOF'
#!/usr/bin/env python3
"""
Safe ZipAY Security Testing
Only performs READ-ONLY checks
"""

import requests
import json
from urllib.parse import urljoin

class SafeZipayTester:
    def __init__(self, base_url, session_cookie=None):
        self.base_url = base_url
        self.session = requests.Session()
        
        if session_cookie:
            self.session.headers.update({
                'Cookie': session_cookie
            })
    
    def test_security_headers(self):
        """Check security headers"""
        print("\n[*] Testing Security Headers...")
        
        try:
            response = self.session.get(self.base_url, timeout=10)
            
            headers_to_check = [
                'X-Frame-Options',
                'X-Content-Type-Options',
                'Strict-Transport-Security',
                'Content-Security-Policy',
                'X-XSS-Protection'
            ]
            
            for header in headers_to_check:
                value = response.headers.get(header)
                if value:
                    print(f"  ✓ {header}: {value}")
                else:
                    print(f"  ✗ {header}: MISSING")
        
        except Exception as e:
            print(f"  Error: {e}")
    
    def test_ssl_configuration(self):
        """Check SSL/TLS configuration"""
        print("\n[*] Testing SSL Configuration...")
        
        try:
            response = self.session.get(self.base_url, timeout=10)
            
            # Check HTTPS redirect
            if response.url.startswith('https://'):
                print("  ✓ HTTPS enabled")
            else:
                print("  ✗ Not using HTTPS")
            
            # Check HSTS
            hsts = response.headers.get('Strict-Transport-Security')
            if hsts:
                print(f"  ✓ HSTS enabled: {hsts}")
            else:
                print("  ✗ HSTS not configured")
        
        except Exception as e:
            print(f"  Error: {e}")
    
    def test_information_disclosure(self):
        """Check for information disclosure"""
        print("\n[*] Testing Information Disclosure...")
        
        # Safe endpoints to check
        safe_endpoints = [
            '/robots.txt',
            '/.well-known/security.txt',
            '/sitemap.xml',
        ]
        
        for endpoint in safe_endpoints:
            try:
                url = urljoin(self.base_url, endpoint)
                response = self.session.get(url, timeout=5)
                
                if response.status_code == 200:
                    print(f"  ℹ️  {endpoint}: Accessible ({len(response.text)} bytes)")
                else:
                    print(f"  ✓ {endpoint}: Not accessible")
            except:
                continue
    
    def test_cookie_security(self):
        """Check cookie security attributes"""
        print("\n[*] Testing Cookie Security...")
        
        try:
            response = self.session.get(self.base_url, timeout=10)
            
            for cookie in self.session.cookies:
                print(f"\n  Cookie: {cookie.name}")
                print(f"    Secure: {cookie.secure}")
                print(f"    HttpOnly: {cookie.has_nonstandard_attr('HttpOnly')}")
                print(f"    SameSite: {cookie.get_nonstandard_attr('SameSite', 'Not set')}")
                
                issues = []
                if not cookie.secure:
                    issues.append("Missing Secure flag")
                if not cookie.has_nonstandard_attr('HttpOnly'):
                    issues.append("Missing HttpOnly flag")
                if not cookie.has_nonstandard_attr('SameSite'):
                    issues.append("Missing SameSite attribute")
                
                if issues:
                    print(f"    ⚠️  Issues: {', '.join(issues)}")
                else:
                    print(f"    ✓ Properly configured")
        
        except Exception as e:
            print(f"  Error: {e}")
    
    def run_safe_tests(self):
        """Run all safe (read-only) tests"""
        print(f"\n{'='*60}")
        print(f"ZIPAY SECURITY TESTING - SAFE MODE")
        print(f"Target: {self.base_url}")
        print(f"{'='*60}")
        
        self.test_security_headers()
        self.test_ssl_configuration()
        self.test_information_disclosure()
        self.test_cookie_security()
        
        print(f"\n{'='*60}")
        print("SAFE TESTING COMPLETE")
        print(f"{'='*60}")
        print("\nNote: These tests are READ-ONLY and safe to run on production.")
        print("For deeper testing, use the full framework in staging environment.")


if __name__ == "__main__":
    import sys
    
    if len(sys.argv) < 2:
        print("Usage: python3 safe_zipay_test.py <url> [session_cookie]")
        print("\nExample:")
        print("  python3 safe_zipay_test.py https://admin.zipay.id")
        print("  python3 safe_zipay_test.py https://admin.zipay.id 'session=abc123...'")
        sys.exit(1)
    
    url = sys.argv[1]
    cookie = sys.argv[2] if len(sys.argv) > 2 else None
    
    tester = SafeZipayTester(url, cookie)
    tester.run_safe_tests()

PYTHON_EOF

chmod +x safe_zipay_test.py
echo "✅ Created: safe_zipay_test.py"
echo ""

echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "RECOMMENDED TESTING SEQUENCE:"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""
echo "1. Run safe tests (READ-ONLY):"
echo "   python3 safe_zipay_test.py $TARGET_BASE"
echo ""
echo "2. Setup staging environment:"
echo "   (Clone production to staging.admin.zipay.id)"
echo ""
echo "3. Run full testing on STAGING:"
echo "   ./run_pentest.sh https://staging.admin.zipay.id"
echo ""
echo "4. Fix vulnerabilities in development"
echo ""
echo "5. Re-test on staging"
echo ""
echo "6. Deploy to production with monitoring"
echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""
echo "📞 EMERGENCY CONTACTS:"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""
echo "Jika testing menyebabkan masalah:"
echo "1. Stop semua testing immediately"
echo "2. Contact tim development"
echo "3. Check monitoring/logs"
echo "4. Rollback jika diperlukan"
echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
