# 🔒 Comprehensive Penetration Testing Framework

**Professional Security Testing Suite for Web Applications**

---

## 📦 Package Contents

### Core Testing Tools

| Tool | Description | Target |
|------|-------------|--------|
| `pentest_comprehensive.py` | All-in-one comprehensive scanner | Full web app |
| `advanced_sqli_test.py` | Deep SQL injection testing | URLs with parameters |
| `advanced_xss_scanner.py` | XSS vulnerability scanner | All pages |
| `csrf_tester.py` | CSRF detection + PoC generator | Forms |
| `api_security_test.py` | API security assessment | REST APIs |

### Quick Start

| File | Purpose |
|------|---------|
| `run_pentest.sh` | **Automated testing script** - Run all tests at once |
| `TESTING_GUIDE.md` | Complete documentation and remediation guide |
| `README.md` | This file |

---

## 🚀 Quick Start (3 Steps)

### 1. Install Dependencies

```bash
# Update system
sudo apt update

# Install Python packages
pip3 install requests beautifulsoup4 urllib3
```

### 2. Run Automated Test

```bash
# Run all tests automatically
./run_pentest.sh http://localhost:8080

# Or test your local admin panel
./run_pentest.sh http://192.168.1.100/admin
```

### 3. Review Results

```bash
# Open HTML report in browser
firefox pentest_results_*/pentest_report.html

# Or view JSON report
cat pentest_results_*/pentest_report.json | python3 -m json.tool
```

---

## 🎯 Individual Tool Usage

### 1️⃣ Comprehensive Scanner

**Best for:** Initial security assessment, complete overview

```bash
python3 pentest_comprehensive.py http://localhost:8080
```

**Output:**
- `pentest_report.json` - Detailed JSON report
- `pentest_report.html` - Visual HTML report

**Tests:**
- ✅ SQL Injection
- ✅ XSS (Reflected, Stored, DOM)
- ✅ CSRF
- ✅ File Upload Security
- ✅ API Security
- ✅ Authentication Bypass
- ✅ Business Logic Flaws
- ✅ Information Disclosure
- ✅ Security Headers

---

### 2️⃣ SQL Injection Tester

**Best for:** Deep SQL injection analysis

```bash
# Test specific URL with parameters
python3 advanced_sqli_test.py 'http://localhost/user.php?id=1'

# Test search functionality
python3 advanced_sqli_test.py 'http://localhost/search.php?q=test&cat=1'
```

**Tests:**
- Error-based SQLi
- Boolean-based Blind SQLi
- Time-based Blind SQLi
- Union-based SQLi

**Supports:** MySQL, PostgreSQL, MSSQL, Oracle

---

### 3️⃣ XSS Scanner

**Best for:** Finding XSS vulnerabilities with bypass techniques

```bash
# Test specific page
python3 advanced_xss_scanner.py 'http://localhost/search.php?q=test'

# Test without parameters (finds forms)
python3 advanced_xss_scanner.py 'http://localhost/comments.php'
```

**Features:**
- 50+ XSS payloads
- WAF bypass techniques
- DOM-based XSS detection
- CSP analysis
- Context-aware testing

---

### 4️⃣ CSRF Tester

**Best for:** CSRF detection and PoC generation

```bash
python3 csrf_tester.py http://localhost/admin/profile.php
```

**Output:**
- `csrf_poc_form_1.html` - HTML PoC
- `csrf_poc_ajax_form_1.html` - AJAX PoC

**Tests:**
- CSRF token validation
- SameSite cookie attribute
- Sensitive operations protection

---

### 5️⃣ API Security Tester

**Best for:** REST API security assessment

```bash
# Test without authentication
python3 api_security_test.py http://localhost:8080

# Test with API key
python3 api_security_test.py http://localhost:8080 your_api_key_here
```

**Tests:**
- Authentication bypass
- Authorization bypass (IDOR)
- Rate limiting
- HTTP method tampering
- Mass assignment
- Injection vulnerabilities
- API versioning issues
- Documentation exposure

---

## 📊 Understanding Results

### Severity Levels

```
🔴 CRITICAL  - Immediate fix required (e.g., SQL injection with data access)
🟠 HIGH      - Urgent fix needed (e.g., XSS in admin panel)
🟡 MEDIUM    - Fix soon (e.g., missing security headers)
🟢 LOW       - Fix when possible (e.g., info disclosure in errors)
🔵 INFO      - Informational (e.g., endpoint detected)
```

### Sample Vulnerability

```json
{
  "type": "SQL Injection - Error Based",
  "severity": "CRITICAL",
  "url": "http://localhost/user.php?id=1",
  "payload": "' OR '1'='1",
  "proof": "MySQL syntax error detected"
}
```

**What this means:**
- 💀 Database can be compromised
- 🎯 Parameter `id` is vulnerable
- 🛠️ Fix: Use prepared statements

---

## 🛡️ Remediation Quick Reference

### SQL Injection Fix

```php
// ❌ VULNERABLE
$query = "SELECT * FROM users WHERE id = $_GET[id]";

// ✅ SECURE
$stmt = $conn->prepare("SELECT * FROM users WHERE id = ?");
$stmt->bind_param("i", $_GET['id']);
```

### XSS Fix

```php
// ❌ VULNERABLE
echo $_GET['search'];

// ✅ SECURE
echo htmlspecialchars($_GET['search'], ENT_QUOTES, 'UTF-8');
```

### CSRF Fix

```php
// ✅ Add CSRF token
$_SESSION['csrf_token'] = bin2hex(random_bytes(32));

// In form
<input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">

// Validate
if ($_POST['csrf_token'] !== $_SESSION['csrf_token']) {
    die('CSRF validation failed');
}
```

---

## 📁 Directory Structure After Testing

```
your_project/
├── pentest_results_20240115_143022/
│   ├── pentest_report.html          ← Open this first
│   ├── pentest_report.json
│   ├── comprehensive_scan.log
│   ├── sqli_test.log
│   ├── xss_test.log
│   ├── csrf_test.log
│   ├── csrf_poc_form_1.html         ← Test CSRF PoCs
│   ├── csrf_poc_ajax_form_1.html
│   └── SUMMARY.txt                  ← Quick overview
└── scripts/
    ├── pentest_comprehensive.py
    ├── advanced_sqli_test.py
    ├── advanced_xss_scanner.py
    ├── csrf_tester.py
    ├── api_security_test.py
    ├── run_pentest.sh               ← Main script
    ├── TESTING_GUIDE.md             ← Full documentation
    └── README.md                    ← This file
```

---

## 🔧 Advanced Usage

### Custom Scan with Specific Tools

```bash
# Only test SQL injection on multiple endpoints
python3 advanced_sqli_test.py 'http://localhost/page1.php?id=1'
python3 advanced_sqli_test.py 'http://localhost/page2.php?user=5'

# Only test CSRF on admin panel
python3 csrf_tester.py http://localhost/admin/settings.php
python3 csrf_tester.py http://localhost/admin/users.php
```

### API Testing with Authentication

```bash
# Test authenticated endpoints
python3 api_security_test.py http://localhost:8080 "Bearer abc123..."

# Test specific API version
python3 api_security_test.py http://localhost:8080/api/v1
```

### Batch Testing Multiple Targets

```bash
# Create target list
cat > targets.txt << EOF
http://localhost:8080
http://192.168.1.100/admin
http://192.168.1.101/api
EOF

# Test all targets
while read target; do
    echo "Testing: $target"
    ./run_pentest.sh "$target"
done < targets.txt
```

---

## ⚠️ Important Warnings

### Legal Requirements

```
⚠️  LEGAL NOTICE:
   - Only test systems you OWN or have WRITTEN PERMISSION to test
   - Unauthorized testing is ILLEGAL
   - Violating this can result in criminal charges
```

### Best Practices

1. **Test Environment First**
   - ✅ Test on staging/development
   - ❌ Never test production without approval

2. **Backup Before Testing**
   - ✅ Backup database and files
   - ✅ Have rollback plan ready

3. **Rate Limiting**
   - ✅ Don't overwhelm the server
   - ✅ Test during low-traffic periods

4. **Documentation**
   - ✅ Document all findings
   - ✅ Include reproduction steps
   - ✅ Provide fix recommendations

---

## 🆘 Troubleshooting

### Common Issues

**1. "No module named 'requests'"**
```bash
pip3 install requests beautifulsoup4 urllib3
```

**2. "Permission denied"**
```bash
chmod +x *.py *.sh
```

**3. "Connection timeout"**
```bash
# Check if target is accessible
curl -I http://localhost:8080

# Check firewall
sudo ufw status
```

**4. "SSL Certificate Error"**
```bash
# Scripts already disable SSL verification for testing
# If needed, add to /etc/hosts:
# 192.168.1.100 admin.local
```

---

## 📚 Additional Resources

### Learning Materials

- **OWASP Top 10:** https://owasp.org/www-project-top-ten/
- **Web Security Academy:** https://portswigger.net/web-security
- **HackTheBox:** https://www.hackthebox.com/
- **TryHackMe:** https://tryhackme.com/

### Tools

- **Burp Suite:** https://portswigger.net/burp
- **OWASP ZAP:** https://www.zaproxy.org/
- **SQLMap:** https://sqlmap.org/
- **Nikto:** https://github.com/sullo/nikto

### Standards

- **OWASP Testing Guide:** https://owasp.org/www-project-web-security-testing-guide/
- **PTES:** http://www.pentest-standard.org/

---

## 🎓 Testing Workflow

```
1. RECONNAISSANCE (10 min)
   └─ Run: ./run_pentest.sh http://target

2. ANALYSIS (30 min)
   └─ Review: pentest_report.html
   └─ Identify: CRITICAL and HIGH severity issues

3. VERIFICATION (1-2 hours)
   └─ Manually test each finding
   └─ Document reproduction steps
   └─ Assess actual impact

4. REPORTING (1 hour)
   └─ Create executive summary
   └─ Detail technical findings
   └─ Provide remediation steps

5. REMEDIATION (varies)
   └─ Fix vulnerabilities
   └─ Re-test to verify fixes
   └─ Update documentation
```

---

## ✅ Pre-Deployment Checklist

Before deploying fixes:

- [ ] All CRITICAL vulnerabilities fixed
- [ ] HIGH severity issues addressed
- [ ] MEDIUM issues planned for fix
- [ ] Security headers implemented
- [ ] Input validation added
- [ ] CSRF protection enabled
- [ ] SQL queries parameterized
- [ ] XSS output encoding applied
- [ ] File upload restrictions in place
- [ ] Error messages sanitized
- [ ] Authentication strengthened
- [ ] Rate limiting implemented
- [ ] Re-testing completed
- [ ] Documentation updated
- [ ] Team trained on secure coding

---

## 📞 Support

For questions or issues:

1. Check `TESTING_GUIDE.md` for detailed documentation
2. Review tool-specific help: `python3 tool_name.py --help`
3. Consult OWASP resources for vulnerability details

---

## 📄 License

This framework is for **educational and authorized security testing only**.

**Disclaimer:** The authors are not responsible for misuse of these tools.
Always obtain proper authorization before testing any system.

---

## 🏆 Credits

**Testing Framework Components:**
- Comprehensive Scanner
- SQL Injection Tester  
- XSS Scanner
- CSRF Tester
- API Security Tester

**Based on:**
- OWASP Testing Guide
- OWASP Top 10
- Security Best Practices

---

**Version:** 1.0  
**Last Updated:** 2024  
**Status:** Production Ready  

---

**🔒 Stay Secure! Happy Testing!**
